"""Inline memory extraction - zero extra latency.

Instead of making a separate LLM call to extract memories,
we modify the system prompt so the LLM outputs memories
as part of its response. This is the Letta/MemGPT approach.

Benefits:
- Zero extra latency (memory is part of response)
- Zero extra API cost (already paying for response tokens)
- Higher quality (LLM has full context)
- Intelligent filtering (LLM decides what's relevant)
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


# Memory extraction instruction to append to system prompt
MEMORY_INSTRUCTION = """

## Memory Instructions
After your response, if there are facts worth remembering about the user/entity for future conversations, output them in a <memory> block:

<memory>
{"memories": [{"content": "fact to remember"}]}
</memory>

What to remember:
- User preferences (likes, dislikes, preferred tools/languages/styles)
- User facts (identity, role, job, location, constraints)
- Context (current goals, ongoing tasks, recent events)

Only output memories for significant, reusable information. Skip for:
- Greetings, thanks, small talk
- One-time questions
- Information already known

If nothing worth remembering: <memory>{"memories": []}</memory>
"""

# Shorter version for token efficiency
MEMORY_INSTRUCTION_SHORT = """

After responding, output facts to remember: <memory>{"memories": [{"content": "..."}]}</memory>
Skip for greetings/small talk. If nothing: <memory>{"memories": []}</memory>"""


@dataclass
class ParsedResponse:
    """Response with extracted memories."""

    content: str | None  # The actual response (without memory block); None for tool-call turns
    memories: list[dict[str, Any]]  # Extracted memories
    raw: str | None  # Original full response


def _append_instruction(content: Any, instruction: str) -> Any:
    """Append the memory instruction to a system prompt's content.

    ``content`` may be a plain string or a list of content-part dicts (OpenAI
    allows ``content`` as a list; Anthropic system prompts are commonly a list of
    ``{"type": "text", ...}`` blocks). Concatenating a str onto a list raises
    ``TypeError``, so a list gets the instruction appended as a trailing text
    part instead. Any other shape falls back to a string join.
    """
    if isinstance(content, list):
        return [*content, {"type": "text", "text": instruction}]
    if isinstance(content, str):
        return content + instruction
    return f"{content}{instruction}" if content else instruction


def inject_memory_instruction(
    messages: list[dict[str, Any]],
    short: bool = True,
) -> list[dict[str, Any]]:
    """Inject memory extraction instruction into system prompt.

    Args:
        messages: Original messages list
        short: Use short instruction (fewer tokens)

    Returns:
        Modified messages with memory instruction
    """
    instruction = MEMORY_INSTRUCTION_SHORT if short else MEMORY_INSTRUCTION
    messages = [m.copy() for m in messages]  # Don't modify original

    # Find or create system message
    has_system = False
    for i, msg in enumerate(messages):
        if msg.get("role") == "system":
            messages[i] = {
                **msg,
                "content": _append_instruction(msg.get("content", ""), instruction),
            }
            has_system = True
            break

    if not has_system:
        # Prepend system message
        messages.insert(
            0,
            {
                "role": "system",
                "content": "You are a helpful assistant." + instruction,
            },
        )

    return messages


def parse_response_with_memory(response_text: str | None) -> ParsedResponse:
    """Parse LLM response to extract memories.

    Args:
        response_text: Raw LLM response. May be ``None`` when the model answered
            with tool/function calls instead of text.

    Returns:
        ParsedResponse with content and memories separated
    """
    memories: list[dict[str, Any]] = []
    content = response_text

    # A chat completion's ``message.content`` is ``None`` whenever the model
    # answers with tool/function calls instead of text, so the two call sites
    # here forward ``None`` (and any non-str payload) straight in. ``re.search``
    # on a non-str raises ``TypeError``, which crashed the whole request. Return
    # the payload untouched — preserving ``None`` so a tool-call response is not
    # coerced to text — with no memories to extract.
    if not isinstance(response_text, str):
        return ParsedResponse(content=response_text, memories=memories, raw=response_text)

    # Extract <memory> block
    memory_pattern = r"<memory>\s*(.*?)\s*</memory>"
    match = re.search(memory_pattern, response_text, re.DOTALL | re.IGNORECASE)

    if match:
        memory_json = match.group(1).strip()

        # Remove the memory block from content
        content = re.sub(memory_pattern, "", response_text, flags=re.DOTALL | re.IGNORECASE).strip()

        # Parse the JSON
        try:
            data = json.loads(memory_json)
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse memory JSON: {e}")
        else:
            # The model controls the block content. A valid-JSON non-object
            # (e.g. a bare array) would make `.get` raise AttributeError, which
            # the JSONDecodeError guard above does not catch; likewise a
            # non-list `memories` would break downstream iteration.
            if isinstance(data, dict):
                extracted = data.get("memories", [])
                if isinstance(extracted, list):
                    memories = extracted
                else:
                    logger.warning("Memory JSON 'memories' field is not a list; ignoring")
            else:
                logger.warning("Memory JSON is not an object; ignoring")

    return ParsedResponse(
        content=content,
        memories=memories,
        raw=response_text,
    )
