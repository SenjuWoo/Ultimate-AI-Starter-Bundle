"""`headroom doctor` — diagnose whether the local Headroom setup is working.

Headroom's failure mode is silent: when a client is not routed through the
proxy (or the proxy runs stale code), everything still works — you just
stop saving tokens. This command correlates the state nothing else
reconciles: the proxy process, per-client wrap configs, the current shell
environment, savings flow, and budget configuration.

Exit codes: 0 = all checks pass, 1 = warnings only, 2 = any failure.
"""

from __future__ import annotations

import json
import os
import re
import sys
from collections.abc import Callable, Mapping, Sequence
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

import click

from headroom._version import format_version_label, normalize_release_version
from headroom.install.health import probe_json
from headroom.install.models import DeploymentManifest
from headroom.install.paths import (
    claude_settings_path,
    codex_config_path,
    codex_project_config_path,
)
from headroom.install.state import list_manifests
from headroom.paths import savings_path
from headroom.providers.claude import (
    REMOTE_CONTROL_BASE_URL_ENV,
    REMOTE_CONTROL_SIBLING_GATE_NOTE,
    claude_auth_conflict_message,
    claude_auth_conflict_sources,
    detect_claude_code_version,
    is_custom_anthropic_base_url,
    remote_control_applies_to_auth,
    remote_control_gate_active,
    remote_control_gate_message,
)

from .main import get_version, main
from .port_discovery import find_live_proxy_elsewhere, is_headroom_livez, loopback_port
from .wrap import _read_wrap_marker, _wrap_marker_is_stale

PASS = "pass"
WARN = "warn"
FAIL = "fail"
SKIP = "skip"

DEFAULT_PROXY_PORT = 8787

# The loopback host forms a proxy URL can take: IPv4, the ``localhost`` alias,
# and the IPv6 literal ``::1`` (``urlsplit`` strips the ``[...]`` brackets and
# lowercases the host, so ``HTTP://Localhost`` and ``http://[::1]`` normalize
# into this set).
_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "::1", "localhost"})

# Codex TOML routes via a quoted ``base_url``. Capture the quoted value only and
# classify it with the shared URL parser below — a prefix/regex match on the URL
# would accept userinfo and hostname-suffix lookalikes such as
# ``http://localhost:8787@evil.example`` as loopback. Anchored to a line start so
# an indented key is matched consistently, and paired with the active
# ``model_provider`` so only the routed provider's block is inspected.
_CODEX_BASE_URL_RE = re.compile(r'(?m)^[ \t]*base_url\s*=\s*"([^"\r\n]+)"')
_CODEX_MODEL_PROVIDER_RE = re.compile(r'(?m)^[ \t]*model_provider\s*=\s*"([^"\r\n]+)"')
_CODEX_OPENAI_BASE_URL_RE = re.compile(r'(?m)^[ \t]*openai_base_url\s*=\s*"([^"\r\n]+)"')


def _loopback_route_port(url: str) -> int | None:
    """Return the port if ``url`` is a well-formed loopback proxy route.

    Classifies by parsing the URL rather than prefix-matching it: the scheme
    must be http(s), there must be no userinfo, the host must be *exactly* a
    loopback literal, and the port must be present and valid. This is what makes
    ``doctor`` a URL classifier rather than a string matcher, so lookalikes that
    a prefix match accepts are correctly rejected:

    * userinfo — ``http://localhost:8787@evil.example/v1`` parses to host
      ``evil.example`` (the ``localhost:8787`` is credentials), and any URL
      carrying userinfo is refused outright;
    * hostname suffix — ``http://localhost.evil.example:8787`` and
      ``http://127.0.0.1.evil.example:8787`` are not exact loopback hosts.

    A correctly-routed loopback URL (including ``[::1]`` and an upper-cased
    scheme/host) still classifies, preserving the #3205 / #3213 fix.
    """
    try:
        parts = urlsplit(url.strip())
    except ValueError:
        return None
    if parts.scheme.lower() not in ("http", "https"):
        return None
    # Reject any credentials in the authority: a real Headroom route never
    # carries userinfo, and userinfo is the vector that masks the true host.
    if parts.username is not None or parts.password is not None:
        return None
    try:
        host = parts.hostname  # lowercased, brackets stripped
        port = parts.port  # raises ValueError on an out-of-range port
    except ValueError:
        return None
    if host is None or host not in _LOOPBACK_HOSTS or port is None:
        return None
    return port


# Ollama's fixed default port. `ollama launch claude` writes
# ``ANTHROPIC_BASE_URL=http://127.0.0.1:11434`` into the launched Claude Code
# child, which outranks the persistent-install env block and silently bypasses
# the Headroom proxy (issue #2199). Recognized so the routing diagnostic names
# the collision instead of telling the user to re-probe port 11434.
_OLLAMA_DEFAULT_PORT = 11434


@dataclass
class CheckResult:
    """One diagnostic outcome."""

    name: str
    status: str  # pass | warn | fail | skip
    summary: str
    hint: str | None = None


def _format_uptime(seconds: float) -> str:
    total = int(seconds)
    days, rem = divmod(total, 86400)
    hours, rem = divmod(rem, 3600)
    minutes = rem // 60
    if days:
        return f"{days}d {hours}h"
    if hours:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


def _format_since(iso_ts: str) -> str | None:
    try:
        then = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None
    delta = datetime.now(then.tzinfo) - then
    seconds = max(0, int(delta.total_seconds()))
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        return f"{seconds // 60}m ago"
    if seconds < 86400:
        return f"{seconds // 3600}h ago"
    return f"{seconds // 86400}d ago"


def check_proxy_liveness(livez: dict[str, Any] | None, base_url: str) -> CheckResult:
    """Is the proxy process up and answering /livez?"""
    if livez is None:
        return CheckResult(
            name="proxy",
            status=FAIL,
            summary=f"not reachable at {base_url}",
            hint="start it with: headroom proxy",
        )
    version = livez.get("version", "unknown")
    uptime = livez.get("uptime_seconds")
    uptime_text = f"up {_format_uptime(uptime)}" if isinstance(uptime, int | float) else "up"
    return CheckResult(
        name="proxy",
        status=PASS,
        summary=f"running at {base_url} ({uptime_text}, {format_version_label(version)})",
    )


def note_live_proxy_elsewhere(check: CheckResult, live_port: int | None) -> CheckResult:
    """Point an unreachable-proxy row at a live Headroom proxy on another port."""
    if live_port is None or check.status == PASS:
        return check
    check.summary += f"; a Headroom proxy IS running on port {live_port}"
    check.hint = (
        f"re-run with: headroom doctor --port {live_port} "
        f"(or export HEADROOM_PORT={live_port}); to use port {live_port} from agents, "
        f"re-run `headroom wrap <agent> --port {live_port}` / `headroom init --port {live_port} "
        "<agent>`"
    )
    return check


def check_proxy_readiness(
    livez: dict[str, Any] | None, readyz: dict[str, Any] | None, base_url: str
) -> CheckResult:
    """Is the live proxy also *ready* (``/readyz``: upstream reachable, warmed up)?

    ``/livez`` only proves the event loop answers. ``/readyz`` answers 503 --
    which the probe reports as ``None`` -- while the upstream check fails or
    startup work is pending, so a live-but-unready proxy is a WARN, not a FAIL.
    """
    name = "readiness"
    if livez is None:
        return CheckResult(name=name, status=SKIP, summary="proxy not reachable")
    if readyz is not None and (readyz.get("ready") or readyz.get("status") == "healthy"):
        return CheckResult(name=name, status=PASS, summary="/readyz reports ready")
    return CheckResult(
        name=name,
        status=WARN,
        summary="proxy is live but /readyz is not ready (upstream unreachable or still starting)",
        hint=f"inspect component state: curl {base_url}/health",
    )


_HOOK_MARKERS = {"claude": "headroom-init-claude", "codex": "headroom-init-codex"}


def _hook_commands(payload: Any) -> list[str]:
    """Every ``command`` string under a Claude/Codex-style ``hooks`` mapping."""
    commands: list[str] = []
    hooks = payload.get("hooks") if isinstance(payload, dict) else None
    if not isinstance(hooks, dict):
        return commands
    for entries in hooks.values():
        if not isinstance(entries, list):
            continue
        for entry in entries:
            items = entry.get("hooks") if isinstance(entry, dict) else None
            if isinstance(items, list):
                for item in items:
                    if isinstance(item, dict) and item.get("command"):
                        commands.append(str(item["command"]))
            elif isinstance(entry, dict) and entry.get("command"):
                commands.append(str(entry["command"]))
    return commands


def _missing_hook_executable(command: str) -> str | None:
    """The hook command's program when it no longer resolves, else None."""
    import shlex
    import shutil

    try:
        tokens = shlex.split(command, posix=os.name != "nt")
    except ValueError:
        return None
    if not tokens:
        return None
    program = tokens[0].strip('"')
    if Path(program).exists() or shutil.which(program):
        return None
    return program


def check_installed_hooks(expected: Sequence[tuple[str, str, Path, str]]) -> CheckResult:
    """Are the hooks ``headroom init`` installed still present and runnable?

    ``expected`` holds ``(agent, scope_label, hooks_file, init_command)`` for
    each agent an init deployment manifest says was configured. A missing
    hook means the proxy is never auto-started for new sessions; a hook whose
    program vanished (uninstalled venv, moved checkout) fails silently.
    """
    name = "hooks"
    if not expected:
        return CheckResult(name=name, status=SKIP, summary="no `headroom init` hooks expected")
    problems: list[str] = []
    fixes: list[str] = []
    installed: list[str] = []
    for agent, scope, path, fix in expected:
        marker = _HOOK_MARKERS.get(agent, f"headroom-init-{agent}")
        try:
            payload = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        except (OSError, ValueError):
            problems.append(f"{agent} ({scope}): could not parse {path}")
            fixes.append(fix)
            continue
        commands = [cmd for cmd in _hook_commands(payload) if marker in cmd]
        if not commands:
            problems.append(f"{agent} ({scope}): no Headroom hook in {path}")
            fixes.append(fix)
            continue
        missing = {prog for cmd in commands if (prog := _missing_hook_executable(cmd))}
        if missing:
            problems.append(
                f"{agent} ({scope}): hook program not found: {', '.join(sorted(missing))}"
            )
            fixes.append(fix)
            continue
        installed.append(f"{agent} ({scope})")
    if problems:
        return CheckResult(
            name=name,
            status=WARN,
            summary="; ".join(problems),
            hint="re-install with: " + " && ".join(dict.fromkeys(fixes)),
        )
    return CheckResult(name=name, status=PASS, summary="installed for " + ", ".join(installed))


def expected_init_hooks(
    manifests: Sequence[Any], cwd: Path | None = None
) -> list[tuple[str, str, Path, str]]:
    """Hook files ``headroom init`` should have written, from its deployment manifests."""
    from headroom.install.paths import codex_hooks_path

    from .init import _GLOBAL_PROFILE, _local_profile

    root = cwd or Path.cwd()
    try:
        local_profile = _local_profile(root)
    except Exception:  # noqa: BLE001 - odd cwd names must not crash doctor
        local_profile = None
    expected: list[tuple[str, str, Path, str]] = []
    for manifest in manifests:
        profile = getattr(manifest, "profile", "")
        if profile == _GLOBAL_PROFILE:
            scope, flag = "user", " -g"
        elif local_profile is not None and profile == local_profile:
            scope, flag = "project", ""
        else:
            continue
        port = getattr(manifest, "port", 8787)
        port_flag = f" --port {port}" if port != 8787 else ""
        for agent in getattr(manifest, "targets", []) or []:
            if agent == "claude":
                path = (
                    claude_settings_path()
                    if scope == "user"
                    else root / ".claude" / "settings.local.json"
                )
            elif agent == "codex":
                path = codex_hooks_path() if scope == "user" else root / ".codex" / "hooks.json"
            else:
                continue
            expected.append((agent, scope, path, f"headroom init{flag}{port_flag} {agent}"))
    return expected


def check_version_drift(livez: dict[str, Any] | None, installed: str) -> CheckResult:
    """Does the running proxy match the installed package version?"""
    if livez is None:
        return CheckResult(name="version", status=SKIP, summary="proxy not reachable")
    running = str(livez.get("version") or "unknown")
    if "unknown" in (running, installed):
        return CheckResult(
            name="version",
            status=WARN,
            summary=f"cannot compare versions (proxy {running}, installed {installed})",
        )
    running_release = normalize_release_version(running)
    installed_release = normalize_release_version(installed)
    if running_release is None or installed_release is None:
        return CheckResult(
            name="version",
            status=SKIP,
            summary=f"source/non-release version label (proxy {running}, installed {installed})",
        )
    if running_release != installed_release:
        return CheckResult(
            name="version",
            status=WARN,
            summary=f"version drift: proxy {running}, installed {installed}",
            hint="restart the proxy to pick up new code: headroom proxy",
        )
    return CheckResult(
        name="version",
        status=PASS,
        summary=f"proxy matches installed {format_version_label(installed)}",
    )


def _claude_base_url_in(path: Path) -> tuple[str, CheckResult | None]:
    """Read the active Claude routing URL from one settings file.

    Returns ``(base_url, error)``. A parse problem comes back as a WARN so the
    caller surfaces it verbatim instead of skipping the file and reporting the
    misleading "not routed".
    """
    name = "claude"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return "", CheckResult(name=name, status=WARN, summary=f"could not parse {path}: {exc}")
    # `json.loads` succeeds on valid non-object JSON (e.g. `[]`, `null`, `42`),
    # which a hand-edited or reset settings file can contain. `.get` on a
    # non-dict raises AttributeError, and it is not one of the caught parse
    # errors above, so it would crash the very command run to diagnose the
    # broken config. Treat a non-object like an unparseable file.
    if not isinstance(payload, dict):
        return "", CheckResult(
            name=name,
            status=WARN,
            summary=f"could not parse {path}: not a JSON object",
        )
    env_block = payload.get("env")
    if isinstance(env_block, dict):
        base_url = str(env_block.get("ANTHROPIC_BASE_URL", "") or "")
        if not base_url and str(env_block.get("CLAUDE_CODE_USE_FOUNDRY", "") or ""):
            base_url = str(env_block.get("ANTHROPIC_FOUNDRY_BASE_URL", "") or "")
        return base_url, None
    return "", None


def check_claude_routing(
    settings_path: Path,
    port: int,
    project_settings_paths: Sequence[Path] | None = None,
) -> CheckResult:
    """Is Claude Code configured to route through the proxy?

    Claude Code layers project settings over user settings, and `headroom init
    claude` without --global writes the project-scoped
    ``.claude/settings.local.json``. Reading only ``~/.claude/settings.json``
    reported "not routed" for sessions that demonstrably were -- confirmed by
    `ps eww` on the live process and by active compression on it (#3205).
    Candidates are consulted in Claude's own precedence order, and the summary
    names the file that supplied the routing so the scope is never ambiguous.
    """
    name = "claude"
    candidates = [*(project_settings_paths or []), settings_path]
    existing = [path for path in candidates if path.exists()]
    if not existing:
        return CheckResult(
            name=name,
            status=WARN,
            summary="not routed (no ~/.claude/settings.json)",
            hint="wrap it: headroom wrap claude",
        )
    first_error: CheckResult | None = None
    for candidate in existing:
        base_url, error = _claude_base_url_in(candidate)
        if error is not None:
            first_error = first_error or error
            continue
        if base_url:
            return _classify_routing_url(name, base_url, port, source=str(candidate))
    if first_error is not None:
        return first_error
    return CheckResult(
        name=name,
        status=WARN,
        summary="not routed (no ANTHROPIC_BASE_URL in settings env)",
        hint="wrap it: headroom wrap claude",
    )


def check_claude_auth_conflict(
    settings_path: Path,
    project_settings_path: Path,
    project_local_settings_path: Path,
    environ: Mapping[str, str],
) -> CheckResult | None:
    """Report contradictory effective Claude credentials without their values."""

    def settings_env(path: Path) -> dict[str, object]:
        if not path.exists():
            return {}
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        env = payload.get("env") if isinstance(payload, dict) else None
        return dict(env) if isinstance(env, dict) else {}

    conflict = claude_auth_conflict_sources(
        (str(settings_path), settings_env(settings_path)),
        (str(project_settings_path), settings_env(project_settings_path)),
        (str(project_local_settings_path), settings_env(project_local_settings_path)),
        ("shell environment", environ),
    )
    if conflict is None:
        return None
    return CheckResult(
        name="claude auth",
        status=FAIL,
        summary=claude_auth_conflict_message(conflict),
    )


def claude_desktop_config_dir() -> Path:
    """Return Claude Desktop's per-user config directory for this platform.

    Claude Desktop (``com.anthropic.claudefordesktop``) stores its config here,
    distinct from Claude Code CLI's ``~/.claude``. Directory existence is used as
    a proxy for "Desktop is installed / has been run" (#2925).
    """
    home = Path.home()
    if sys.platform == "darwin":
        return home / "Library" / "Application Support" / "Claude"
    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        base = Path(appdata) if appdata else home / "AppData" / "Roaming"
        return base / "Claude"
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else home / ".config"
    return base / "Claude"


def check_claude_desktop(config_dir: Path) -> CheckResult | None:
    """Surface that Claude Desktop agent sessions bypass the proxy (#2925 / #869).

    Claude Desktop unconditionally overwrites ``ANTHROPIC_BASE_URL`` when it
    spawns agent sessions, so a correctly-wrapped ``~/.claude/settings.json``
    (which the ``claude`` check verifies for the terminal CLI) does not route
    Desktop traffic. Without this, ``doctor`` passes on the settings value alone
    and never hints that Desktop sessions are unrouted.

    Reported as its own per-surface row -- like ``wrap_marker`` and ``shell env``
    -- and only when Desktop is detected, so it never contradicts a genuinely
    routed CLI. Returns ``None`` when Desktop is absent (no row).
    """
    if not config_dir.exists():
        return None
    return CheckResult(
        name="claude desktop",
        status=WARN,
        summary="agent sessions bypass the proxy (Desktop overwrites ANTHROPIC_BASE_URL)",
        hint=(
            "Desktop routing is not supported yet (see #869); use the terminal "
            "Claude Code CLI for proxy-routed sessions."
        ),
    )


def check_claude_remote_control_gate(
    settings_path: Path,
    environ: Mapping[str, str],
    *,
    version: tuple[int, int, int] | None = None,
    version_resolver: Callable[[], tuple[int, int, int] | None] | None = None,
) -> CheckResult | None:
    """Warn once when Claude custom-base routing hides Remote Control (issue #1779).

    Fires only for a session that could ever have had Remote Control — a
    subscription auth mode (not API-key/cloud IAM) on a Claude Code build at/after
    the gate version, or an unknown version. Auth signals are read from the shell
    ``environ`` overlaid on the settings-file ``env`` block, so an API key
    configured in either place suppresses the warning.

    ``version`` is the detected Claude Code version (``None`` = unknown); tests
    pass it directly so the check stays pure. ``version_resolver`` lets the
    ``doctor`` entrypoint defer the ``claude --version`` subprocess until the
    cheap gates (custom base URL + subscription auth) have passed — most doctor
    runs never pay it. An explicit ``version`` wins over the resolver; the
    resolver is called at most once.
    """
    name = "claude remote control"
    settings_env: dict[str, object] = {}
    settings_base_url = ""
    if settings_path.exists():
        try:
            payload = json.loads(settings_path.read_text(encoding="utf-8"))
            # Valid non-object JSON (`[]`, `null`, ...) parses fine but has no
            # `.get`, and AttributeError is not caught below; guard for dict-ness
            # so a malformed settings file can't crash the gate check.
            env_block = payload.get("env") if isinstance(payload, dict) else None
            if isinstance(env_block, dict):
                settings_env = env_block
                settings_base_url = str(env_block.get("ANTHROPIC_BASE_URL", "") or "")
        except (OSError, ValueError):
            settings_env = {}
            settings_base_url = ""

    # Shell env wins over settings env, matching Claude Code's own precedence.
    effective_env: dict[str, object] = {**settings_env, **dict(environ)}
    env_base_url = environ.get("ANTHROPIC_BASE_URL", "")

    resolved_version = version
    version_resolved = version is not None or version_resolver is None

    for base_url, source in (
        (settings_base_url, "from settings"),
        (env_base_url, "in shell"),
    ):
        # Cheap gates first so the version subprocess only runs when a warning
        # is actually plausible for this environment.
        if not is_custom_anthropic_base_url(base_url):
            continue
        if not remote_control_applies_to_auth(effective_env):
            return None
        if not version_resolved and version_resolver is not None:
            resolved_version = version_resolver()
            version_resolved = True
        if remote_control_gate_active(base_url, effective_env, resolved_version):
            remote_message = remote_control_gate_message(
                f"{REMOTE_CONTROL_BASE_URL_ENV} {source}", version=resolved_version
            )
            return CheckResult(
                name=name,
                status=WARN,
                summary=remote_message,
                hint=REMOTE_CONTROL_SIBLING_GATE_NOTE,
            )
    return None


def check_wrap_marker_staleness(settings_path: Path) -> CheckResult:
    """Flag a project-local ANTHROPIC_BASE_URL left by a crashed wrap session.

    A crashed ``headroom wrap claude`` (SIGKILL, OOM, reboot) can leave
    ``.claude/settings.local.json`` pointing at a dead proxy port, hanging
    every subsequent bare ``claude`` invocation in the project (issue #1768).
    This checks the project-local settings file — separate from the global
    ``~/.claude/settings.json`` :func:`check_claude_routing` inspects.
    """
    name = "wrap_marker"
    marker = _read_wrap_marker(settings_path)
    if marker is None:
        return CheckResult(name=name, status=SKIP, summary="no wrap marker found")
    if not _wrap_marker_is_stale(marker):
        return CheckResult(
            name=name, status=PASS, summary=f"live wrap session (pid {marker.get('pid')})"
        )
    return CheckResult(
        name=name,
        status=WARN,
        summary=(
            f"stale ANTHROPIC_BASE_URL from crashed wrap session "
            f"(pid {marker.get('pid')}, port {marker.get('port')}) — "
            "run `headroom unwrap claude` to clean it up"
        ),
    )


def codex_active_base_url(text: str) -> tuple[str, str | None]:
    """Return ``(provider_id, base_url)`` for the active Codex provider in ``text``."""
    first_table = re.search(r"(?m)^[ \t]*\[", text)
    root = text[: first_table.start()] if first_table is not None else text
    # Only a root `model_provider` picks the default session's provider; one
    # under `[profiles.*]` applies only when that profile is selected.
    active_match = _CODEX_MODEL_PROVIDER_RE.search(root)
    if active_match is None or active_match.group(1) == "openai":
        # A root `openai_base_url` re-points Codex's built-in `openai` provider
        # (the default when `model_provider` is unset), so it beats an inactive
        # `[model_providers.headroom]` table. Headroom Desktop routes this way
        # because the ChatGPT app hides features for any other provider.
        root_url = _CODEX_OPENAI_BASE_URL_RE.search(root)
        if root_url is not None:
            return "openai", root_url.group(1)
    provider_id = active_match.group(1) if active_match else "headroom"
    return provider_id, _codex_provider_base_url(text, provider_id)


def check_codex_routing(
    config_path: Path,
    port: int,
    project_config_paths: Sequence[Path] | None = None,
) -> CheckResult:
    """Is Codex configured to route through the proxy?

    Detection prefers the active ``model_provider`` section's loopback
    ``base_url``, while retaining the ``[model_providers.headroom]`` fallback
    emitted by persistent and wrap installs. Best-effort matching keeps
    malformed TOML a WARN instead of a crash.

    ``config_path`` is the user config (``$CODEX_HOME/config.toml``, so a
    relocated Codex home is inspected rather than ``~/.codex``). Codex layers a
    trusted project's ``.codex/config.toml`` over it, and ``headroom init
    codex`` without ``-g`` writes there, so project candidates are consulted
    first and the summary names the file that supplied the routing.
    """
    name = "codex"
    candidates = [*(project_config_paths or []), config_path]
    existing = [path for path in candidates if path.exists()]
    if not existing:
        return CheckResult(
            name=name,
            status=WARN,
            summary=f"not routed (no {config_path})",
            hint="wrap it: headroom wrap codex",
        )
    first_error: CheckResult | None = None
    found: tuple[Path, str, str, str] | None = None
    for candidate in existing:
        try:
            text = candidate.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            first_error = first_error or CheckResult(
                name=name, status=WARN, summary=f"could not read {candidate}: {exc}"
            )
            continue
        provider_id, base_url = codex_active_base_url(text)
        if base_url is not None:
            found = (candidate, text, provider_id, base_url)
            break
    if found is None:
        if first_error is not None:
            return first_error
        return CheckResult(
            name=name,
            status=WARN,
            summary="not routed (no active provider base_url in config.toml)",
            hint="wrap it: headroom wrap codex",
        )

    config_path, text, provider_id, base_url = found

    # base_url is the active provider's, already extracted and None-checked
    # above. Classify it through the shared URL parser so a lookalike or remote
    # base_url (userinfo, hostname suffix, non-loopback) is a WARN, not a PASS.

    routing = _classify_routing_url(name, base_url, port, source=str(config_path))
    if routing.status != PASS:
        return routing
    # Routed, but Codex may still attach no credentials. A ChatGPT-OAuth user
    # needs `requires_openai_auth = true` in the active provider block or Codex
    # sends no Authorization header and every request fails with 401 (#3206).
    if _codex_block_missing_openai_auth(text, config_path, provider_id):
        return CheckResult(
            name=name,
            status=WARN,
            summary="routed, but Codex will send no Authorization (missing requires_openai_auth)",
            hint="re-run: headroom wrap codex (or headroom init codex) to rewrite the block",
        )
    return routing


def _codex_provider_base_url(text: str, provider_id: str) -> str | None:
    section_match = re.search(
        rf"(?m)^[ \t]*\[model_providers\.{re.escape(provider_id)}\][ \t]*(?:#.*)?$",
        text,
    )
    if section_match is None:
        return None
    section = text[section_match.end() :]
    next_section = re.search(r"(?m)^[ \t]*\[", section)
    if next_section is not None:
        section = section[: next_section.start()]
    base_url_match = _CODEX_BASE_URL_RE.search(section)
    return base_url_match.group(1) if base_url_match else None


def _configured_client_ports(
    claude_paths: Sequence[Path], codex_paths: Sequence[Path]
) -> list[int]:
    """Loopback ports the Claude Code and Codex configs (project and user) send traffic to.

    Headroom Desktop (port 6767) and ``wrap --port N`` leave no deployment
    manifest, so without these a bare ``doctor`` only ever finds 8787.
    """
    urls = [_claude_base_url_in(path)[0] for path in claude_paths]
    for path in codex_paths:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        urls.append(codex_active_base_url(text)[1] or "")
    return [port for port in map(loopback_port, urls) if port is not None]


def _codex_block_missing_openai_auth(
    text: str, config_path: Path, provider_id: str = "headroom"
) -> bool:
    """ChatGPT-OAuth Codex routed without ``requires_openai_auth`` (#3206)."""
    section = f"[model_providers.{provider_id}]"
    start = text.find(section)
    if start == -1:
        return False
    rest = text[start + len(section) :]
    end = rest.find("\n[")
    block = rest if end == -1 else rest[:end]
    if "requires_openai_auth" in block:
        return False
    try:
        from headroom.providers.codex.install import codex_uses_chatgpt_auth

        return codex_uses_chatgpt_auth(config_path.parent / "auth.json")
    except Exception:  # pragma: no cover - never let a doctor check crash
        return False


def check_trust_policy(policy: Mapping[str, Any]) -> CheckResult:
    """Which certificates the proxy trusts for its upstream connections.

    Corporate TLS inspection (Zscaler, Netskope, ...) re-signs every upstream
    certificate with a company root that IT installs in the OS store. The proxy
    only accepts it when the OS store is in use or the root is supplied as a
    bundle, so this line answers "will Headroom trust what my network presents?"
    """
    replacement = policy.get("replacement_bundle")
    additive = policy.get("additive_bundles") or []
    extras = ", ".join(f"{b['env_var']}={b['path']}" for b in additive)
    if replacement:
        return CheckResult(
            name="tls trust",
            status=PASS,
            summary=f"only {replacement['env_var']}={replacement['path']}",
            hint=(
                f"{replacement['env_var']} replaces every other trust source; the OS "
                "certificate store is not consulted. Unset it to trust the OS store."
            ),
        )
    if policy.get("system_store_active"):
        sources = "OS certificate store" + (
            " + certifi" if "bundled" in policy.get("cert_store", []) else ""
        )
        return CheckResult(
            name="tls trust",
            status=PASS,
            summary=sources + (f" + {extras}" if extras else ""),
        )
    reason = (
        "HEADROOM_CERT_STORE excludes 'system'"
        if policy.get("system_store_available")
        else "the truststore package is not installed"
    )
    return CheckResult(
        name="tls trust",
        status=WARN,
        summary="certifi bundle only" + (f" + {extras}" if extras else ""),
        hint=(
            f"The OS certificate store is not used ({reason}), so a corporate "
            "TLS-inspection root is only trusted if you pass it via HEADROOM_CA_BUNDLE."
        ),
    )


def check_proxy_env(environ: Mapping[str, str]) -> CheckResult | None:
    """Warn when an HTTP(S) proxy would capture the agent's loopback traffic."""
    from headroom.proxy.tls_diagnostics import loopback_no_proxy_gap

    gap = loopback_no_proxy_gap(environ)
    if gap is None:
        return None
    return CheckResult(
        name="proxy env",
        status=WARN,
        summary=f"{gap} is set but NO_PROXY does not exempt 127.0.0.1/localhost",
        hint=(
            "Agents may send their requests to Headroom through the corporate proxy, "
            "which cannot reach this machine. `headroom wrap` fixes this for the "
            "processes it launches; for other setups add "
            "NO_PROXY=127.0.0.1,localhost,::1."
        ),
    )


# (label, url, required). Required endpoints fail the check; the rest only warn
# because Headroom degrades (no ML compression, estimated token counts) rather
# than breaking when they are unreachable.
NETWORK_ENDPOINTS: tuple[tuple[str, str, bool], ...] = (
    ("api.anthropic.com", "https://api.anthropic.com/v1/models", True),
    ("api.openai.com", "https://api.openai.com/v1/models", True),
    ("api.githubcopilot.com", "https://api.githubcopilot.com/models", False),
    ("huggingface.co (models)", "https://huggingface.co/api/models?limit=1", False),
    (
        "openaipublic (tiktoken)",
        "https://openaipublic.blob.core.windows.net/encodings/",
        False,
    ),
)


def check_network_endpoints(reports: Sequence[Any], required: set[str]) -> list[CheckResult]:
    """Turn :class:`EndpointReport`s into doctor rows, plus an IT summary row."""
    results: list[CheckResult] = []
    vendors: set[str] = set()
    failing_hosts: list[str] = []
    for report in reports:
        vendor = report.chain.inspection_vendor
        if vendor:
            vendors.add(vendor)
        inspected = f"; TLS inspected by {vendor}" if vendor else ""
        host = urlsplit_host(report.url)
        if report.ok:
            results.append(
                CheckResult(
                    name=f"net {report.name}",
                    status=PASS,
                    summary=(
                        f"reachable, certificate trusted (HTTP {report.status}, "
                        f"{report.elapsed_ms:.0f} ms){inspected}"
                    ),
                )
            )
            continue
        failing_hosts.append(host)
        status = FAIL if report.name in required else WARN
        if report.block_page:
            summary = f"blocked by a network gateway (HTTP {report.status}){inspected}"
        elif report.chain.issuer and "verify" in (report.error or "").lower():
            summary = f"certificate not trusted (issued by {report.chain.issuer})"
        else:
            summary = (report.error or "unreachable").split(". ")[0][:160]
        results.append(
            CheckResult(
                name=f"net {report.name}", status=status, summary=summary, hint=report.error
            )
        )
    if failing_hosts:
        who = " / ".join(sorted(vendors)) or "your TLS-inspection gateway"
        results.append(
            CheckResult(
                name="it request",
                status=WARN,
                summary=f"{len(failing_hosts)} endpoint(s) need a network change",
                hint=(
                    f"Text for your IT team: Headroom (a local AI coding proxy) needs HTTPS "
                    f"access to {', '.join(failing_hosts)}. Either confirm the {who} root "
                    "certificate is deployed to the operating system certificate store on "
                    "developer machines, or exempt these domains from TLS inspection and "
                    "cloud-app blocking. Please do not exempt 'python' as a process; the "
                    "certificate fix is sufficient."
                ),
            )
        )
    return results


def urlsplit_host(url: str) -> str:
    from urllib.parse import urlsplit

    return urlsplit(url).hostname or url


def run_network_probes(extra_urls: Sequence[str]) -> tuple[list[Any], set[str]]:
    """Probe every endpoint concurrently; returns (reports, required names)."""
    from concurrent.futures import ThreadPoolExecutor

    from headroom.proxy.tls_diagnostics import probe_endpoint

    targets = [(label, url) for label, url, _ in NETWORK_ENDPOINTS]
    required = {label for label, _, req in NETWORK_ENDPOINTS if req}
    for url in extra_urls:
        label = urlsplit_host(url)
        targets.append((label, url))
        required.add(label)
    with ThreadPoolExecutor(max_workers=len(targets)) as pool:
        reports = list(pool.map(lambda t: probe_endpoint(*t), targets))
    return reports, required


def network_checks(extra_urls: Sequence[str]) -> list[CheckResult]:
    """The ``--network`` rows, or one skipped row when ``HEADROOM_OFFLINE`` is set.

    Every probe here dials an internet host, so under the air-gap switch none
    of them runs; saying so beats a page of "unreachable" failures.
    """
    from headroom.offline import OFFLINE_ENV, OfflineEgressBlocked

    try:
        reports, required = run_network_probes(extra_urls)
    except OfflineEgressBlocked as blocked:
        return [
            CheckResult(
                name="network",
                status=SKIP,
                summary=f"skipped: {OFFLINE_ENV} is set, no endpoint was contacted",
                hint=str(blocked),
            )
        ]
    return check_network_endpoints(reports, required)


def check_shell_env(environ: Mapping[str, str], port: int) -> CheckResult:
    """Is the *current shell* pointed at the proxy for ad-hoc runs?"""
    name = "shell env"
    for var in ("ANTHROPIC_BASE_URL", "OPENAI_BASE_URL"):
        value = environ.get(var, "")
        if value:
            return _classify_routing_url(name, value, port, source=var)
    return CheckResult(
        name=name,
        status=WARN,
        summary="ANTHROPIC_BASE_URL / OPENAI_BASE_URL unset — this shell bypasses the proxy",
        hint=f"export ANTHROPIC_BASE_URL=http://127.0.0.1:{port} (or launch via headroom wrap)",
    )


def _classify_routing_url(name: str, url: str, port: int, *, source: str) -> CheckResult:
    found_port = _loopback_route_port(url)
    if found_port is None:
        return CheckResult(
            name=name,
            status=WARN,
            summary=f"points at {url}, not the local Headroom proxy ({source})",
        )
    if found_port != port:
        if found_port == _OLLAMA_DEFAULT_PORT:
            # Not a mis-probed Headroom port — this is Ollama's endpoint, so
            # `headroom doctor --port 11434` would only chase a red herring.
            return CheckResult(
                name=name,
                status=WARN,
                summary=(
                    f"points at Ollama ({url}), not the Headroom proxy ({source}) — "
                    "`ollama launch claude` bypasses the persistent Headroom route"
                ),
                hint=(
                    "both claim ANTHROPIC_BASE_URL; run Ollama-backed sessions "
                    "through Headroom by chaining the proxy at its Ollama upstream "
                    "(see issue #2199)"
                ),
            )
        return CheckResult(
            name=name,
            status=WARN,
            summary=f"routed to port {found_port}, but doctor probed port {port} ({source})",
            hint=f"re-run with: headroom doctor --port {found_port}",
        )
    return CheckResult(name=name, status=PASS, summary=f"routed via {source}")


def check_savings(stats: dict[str, Any] | None, savings_file: Path) -> CheckResult:
    """Are savings actually flowing? Lifetime totals + last activity."""
    name = "savings"
    payload: dict[str, Any] | None = None
    source = "proxy /stats"
    if stats is not None and isinstance(stats.get("persistent_savings"), dict):
        payload = stats["persistent_savings"]
    elif savings_file.exists():
        source = str(savings_file)
        try:
            payload = json.loads(savings_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return CheckResult(
                name=name, status=WARN, summary=f"could not read savings file {savings_file}"
            )
    if payload is None:
        return CheckResult(
            name=name,
            status=WARN,
            summary="no savings recorded yet",
            hint="route a client through the proxy and make a request",
        )

    lifetime = payload.get("lifetime") or {}
    tokens = lifetime.get("tokens_saved", 0) or 0
    usd = lifetime.get("compression_savings_usd", 0.0) or 0.0
    cache_reads = lifetime.get("cache_read_tokens", 0) or 0
    if not tokens and not cache_reads:
        return CheckResult(
            name=name,
            status=WARN,
            summary="no tokens saved yet",
            hint="route a client through the proxy and make a request",
        )

    session = payload.get("display_session") or {}
    freshness = None
    last_activity = session.get("last_activity_at")
    if isinstance(last_activity, str):
        freshness = _format_since(last_activity)
    summary = f"{tokens:,} tokens / ${usd:,.2f} saved lifetime"
    if cache_reads:
        cache_usd = lifetime.get("cache_savings_usd", 0.0) or 0.0
        summary += f"; {cache_reads:,} cache-read tokens / ${cache_usd:,.2f} cache savings"
    if freshness:
        summary += f" — last request {freshness}"
    return CheckResult(name=name, status=PASS, summary=f"{summary} ({source})")


def check_kompress_health(health: dict[str, Any] | None) -> CheckResult:
    """Report whether the optional Kompress model can actually run.

    ``/livez`` only proves that the proxy process is alive, and ``/stats``
    cannot distinguish a healthy zero-savings workload from a cold Kompress
    model. The health payload has the component-level readiness state needed
    to explain the "ML extras installed, but every request passes through"
    failure mode.
    """
    name = "kompress"
    if health is None:
        return CheckResult(name=name, status=SKIP, summary="proxy health endpoint not reachable")

    checks = health.get("checks")
    component = checks.get(name) if isinstance(checks, dict) else None
    if not isinstance(component, dict):
        return CheckResult(
            name=name,
            status=WARN,
            summary="proxy does not report Kompress readiness (older version?)",
            hint="restart the proxy on the current version",
        )

    if not bool(component.get("enabled", True)):
        return CheckResult(name=name, status=PASS, summary="disabled")

    backend = component.get("backend")
    backend_text = f" ({backend})" if backend else ""
    if bool(component.get("ready")):
        return CheckResult(name=name, status=PASS, summary=f"ready{backend_text}")

    return CheckResult(
        name=name,
        status=WARN,
        summary=f"not ready{backend_text} — content compression is passing through",
        hint=(
            "pre-download the Kompress model and retry; inspect /debug/warmup "
            "for the resolved load state"
        ),
    )


def check_budget(stats: dict[str, Any] | None) -> CheckResult:
    """Is a spend budget configured on the proxy?"""
    name = "budget"
    if stats is None:
        return CheckResult(name=name, status=SKIP, summary="proxy not reachable")
    cost = stats.get("cost")
    if not isinstance(cost, dict):
        return CheckResult(name=name, status=WARN, summary="cost tracking disabled (--no-cost)")
    if "budget_limit_usd" not in cost:
        return CheckResult(
            name=name,
            status=WARN,
            summary="proxy does not report budget config (older version?)",
            hint="restart the proxy on the current version",
        )
    limit = cost.get("budget_limit_usd")
    if limit is None:
        return CheckResult(
            name=name,
            status=WARN,
            summary="no budget configured — spend is unlimited",
            hint="set one: headroom proxy --budget 10 (env: HEADROOM_BUDGET)",
        )
    period = cost.get("budget_period", "daily")
    summary = f"${limit}/{period} budget enforced"
    return CheckResult(name=name, status=PASS, summary=summary + _estimated_basis_note(cost))


def _estimated_basis_note(cost: dict[str, Any]) -> str:
    """Describe how much of the period's spend was booked from a token estimate.

    Informational, never a WARN: a provider that simply never reports a usage
    breakdown would otherwise sit at a permanent warning. Every read is
    defensive so `doctor` still works against a proxy predating these fields.
    """
    note = ""

    basis = cost.get("budget_basis")
    if isinstance(basis, dict):
        estimated_usd = basis.get("estimated_usd")
        estimated_pct = basis.get("estimated_pct")
        if isinstance(estimated_usd, (int, float)) and estimated_usd > 0:
            pct = f"{estimated_pct:.0f}% " if isinstance(estimated_pct, (int, float)) else ""
            note += (
                f" — {pct}of period spend (${estimated_usd:.4f}) "
                "booked from Headroom token estimates"
            )

    # Reported independently of the breakdown: a non-default policy changes how
    # the budget is enforced and should surface even if the split is missing.
    policy = cost.get("budget_estimated_basis")
    if isinstance(policy, str) and policy and policy != "count":
        note += f" — estimated-basis policy: {policy}"
    return note


def check_deployments(manifests: list[Any], probe: Any = probe_json) -> CheckResult | None:
    """Probe persistent deployment health URLs. None when no deployments."""
    if not manifests:
        return None
    down = []
    for manifest in manifests:
        payload = probe(manifest.health_url)
        ready = bool(payload and (payload.get("ready") or payload.get("status") == "healthy"))
        if not ready:
            down.append(manifest.profile)
    if down:
        return CheckResult(
            name="deployments",
            status=FAIL,
            summary=f"{len(down)} of {len(manifests)} deployment(s) down: {', '.join(down)}",
            hint="inspect with: headroom install status --profile <name>",
        )
    return CheckResult(
        name="deployments",
        status=PASS,
        summary=f"{len(manifests)} deployment(s) healthy",
    )


_STATUS_STYLE = {PASS: "green", WARN: "yellow", FAIL: "red", SKIP: "dim"}
_STATUS_GLYPH = {PASS: "✓", WARN: "⚠", FAIL: "✗", SKIP: "·"}


def _render(checks: list[CheckResult], port: int, installed: str) -> None:
    from rich.console import Console
    from rich.markup import escape
    from rich.table import Table

    console = Console()
    console.print(
        f"[bold]Headroom Doctor[/bold] [dim]{format_version_label(installed)} · port {port}[/dim]\n"
    )
    table = Table(show_header=True, header_style="bold")
    table.add_column("check")
    table.add_column("status")
    table.add_column("summary")
    for check in checks:
        style = _STATUS_STYLE.get(check.status, "white")
        glyph = _STATUS_GLYPH.get(check.status, "?")
        table.add_row(
            check.name,
            f"[{style}]{glyph} {check.status}[/{style}]",
            escape(check.summary),
        )
    console.print(table)
    for check in checks:
        if check.hint:
            console.print(f"[dim]{check.name}:[/dim] {escape(check.hint)}")

    fails = sum(1 for c in checks if c.status == FAIL)
    warns = sum(1 for c in checks if c.status == WARN)
    if fails or warns:
        console.print(f"\n[bold]{fails} failure(s), {warns} warning(s)[/bold]")
    else:
        console.print("\n[green bold]all checks passed[/green bold]")


def resolve_probe_port(
    requested: int | None,
    manifests: Sequence[DeploymentManifest],
) -> int:
    """Resolve the port `doctor` should probe.

    Precedence: an explicit ``--port`` (or ``HEADROOM_PORT``) wins, then the
    port a managed deployment recorded, then the built-in default.

    The manifest tier matters because ``headroom deploy --port N`` writes N
    into the deployment's own environment, not into the shell `doctor` later
    runs in. Without it a healthy non-default deployment is reported as
    unreachable, and the remediation hints point at the wrong port.

    A deployment is only consulted when it is unambiguous: the ``default``
    profile, or a lone profile under another name. With several named profiles
    and no explicit request there is no non-arbitrary choice, so the built-in
    default is used and the per-deployment section reports each one instead.

    Args:
        requested: Port supplied on the command line or via the environment.
        manifests: Deployment manifests to consider.

    Returns:
        The port to probe.
    """
    if requested is not None:
        return requested
    default_profile = next((m for m in manifests if m.profile == "default"), None)
    if default_profile is not None:
        return default_profile.port
    if len(manifests) == 1:
        return manifests[0].port
    return DEFAULT_PROXY_PORT


@main.command()
@click.option(
    "--port",
    "-p",
    default=None,
    type=click.IntRange(1, 65535),
    envvar="HEADROOM_PORT",
    help=(
        "Proxy port to check (env: HEADROOM_PORT). Defaults to the port of a "
        f"single managed deployment, else {DEFAULT_PROXY_PORT}."
    ),
)
@click.option("--json", "emit_json", is_flag=True, help="Emit JSON instead of formatted output.")
@click.option(
    "--network",
    is_flag=True,
    help=(
        "Also test HTTPS to the provider APIs and model hosts: who signed the "
        "certificate (Zscaler, Netskope, ...), whether Headroom trusts it, and "
        "whether a gateway block page is in the way."
    ),
)
@click.option(
    "--network-url",
    "network_urls",
    multiple=True,
    metavar="URL",
    help="Extra upstream URL to test with --network (repeatable), e.g. a custom gateway.",
)
def doctor(
    port: int | None,
    emit_json: bool,
    network: bool,
    network_urls: tuple[str, ...],
) -> None:
    """Check that the Headroom proxy and client routing are working.

    \b
    Exit codes:
        0  everything healthy
        1  warnings only (working, but not optimally wired)
        2  at least one failure (proxy down / deployment down)
    """
    manifests = list_manifests()
    port = resolve_probe_port(port, manifests)
    base_url = f"http://127.0.0.1:{port}"
    livez = probe_json(f"{base_url}/livez")
    readyz = probe_json(f"{base_url}/readyz", timeout=3.0) if livez else None
    health = probe_json(f"{base_url}/health", timeout=5.0) if livez else None
    stats = probe_json(f"{base_url}/stats", timeout=5.0) if livez else None
    installed = get_version()
    project_claude_settings = Path.cwd() / ".claude" / "settings.json"
    project_local_claude_settings = Path.cwd() / ".claude" / "settings.local.json"
    live_elsewhere = None
    if livez is None:
        # Cheap, bounded: only ports Headroom recorded (HEADROOM_PORT, 8787,
        # deployment manifests, project wrap markers, live client markers, and
        # ports agents are configured for), probed in parallel.
        live_elsewhere = find_live_proxy_elsewhere(
            port,
            manifests=manifests,
            extra=_configured_client_ports(
                [project_local_claude_settings, project_claude_settings, claude_settings_path()],
                [codex_project_config_path(), codex_config_path()],
            ),
            probe=lambda p: is_headroom_livez(
                probe_json(f"http://127.0.0.1:{p}/livez", timeout=0.5)
            ),
        )

    checks = [
        note_live_proxy_elsewhere(check_proxy_liveness(livez, base_url), live_elsewhere),
        check_proxy_readiness(livez, readyz, base_url),
        check_version_drift(livez, installed),
        check_claude_routing(
            claude_settings_path(),
            port,
            [project_local_claude_settings, project_claude_settings],
        ),
        check_wrap_marker_staleness(project_local_claude_settings),
        check_codex_routing(codex_config_path(), port, [codex_project_config_path()]),
        check_installed_hooks(expected_init_hooks(manifests)),
        check_shell_env(os.environ, port),
        check_kompress_health(health),
        check_savings(stats, savings_path()),
        check_budget(stats),
    ]
    from headroom.proxy.ssl_context import describe_trust_policy

    # Prefer the running proxy's own policy (its env can differ from this
    # shell's under launchd/systemd); fall back to what this shell would use.
    proxy_tls = ((health or {}).get("config") or {}).get("tls")
    trust_row = check_trust_policy(proxy_tls or describe_trust_policy())
    if not proxy_tls:
        trust_row.summary += " (this shell; proxy not reporting)"
    checks.append(trust_row)
    proxy_env_check = check_proxy_env(os.environ)
    if proxy_env_check is not None:
        checks.append(proxy_env_check)
    if network or network_urls:
        checks.extend(network_checks(network_urls))
    auth_conflict_check = check_claude_auth_conflict(
        claude_settings_path(),
        project_claude_settings,
        project_local_claude_settings,
        os.environ,
    )
    if auth_conflict_check is not None:
        checks.append(auth_conflict_check)
    # Lazy resolver: `claude --version` is a Node CLI subprocess (seconds of
    # cold start, 10s worst-case timeout) — only pay for it when the RC gate
    # is actually plausible (custom base URL + subscription auth).
    remote_control_gate_check = check_claude_remote_control_gate(
        claude_settings_path(), os.environ, version_resolver=detect_claude_code_version
    )
    if remote_control_gate_check is not None:
        checks.append(remote_control_gate_check)
    desktop_check = check_claude_desktop(claude_desktop_config_dir())
    if desktop_check is not None:
        checks.append(desktop_check)
    deployments = check_deployments(manifests)
    if deployments is not None:
        checks.append(deployments)

    if any(c.status == FAIL for c in checks):
        exit_code = 2
    elif any(c.status == WARN for c in checks):
        exit_code = 1
    else:
        exit_code = 0

    if emit_json:
        click.echo(
            json.dumps(
                {
                    "port": port,
                    "installed_version": installed,
                    "exit_code": exit_code,
                    "checks": [asdict(c) for c in checks],
                },
                indent=2,
            )
        )
    else:
        _render(checks, port, installed)
    raise SystemExit(exit_code)
