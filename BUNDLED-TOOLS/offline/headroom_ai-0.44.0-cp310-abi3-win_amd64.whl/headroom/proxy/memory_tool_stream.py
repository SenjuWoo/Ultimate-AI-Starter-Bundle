"""Hide proxy-handled memory tool calls from an Anthropic SSE stream.

The proxy injects its own memory tools (``memory_save``, ``memory_search``,
...) into requests. The client never declared them, so when the model calls
one the client cannot run it: Claude Code answers ``No such tool available``
and the model concludes the save or search failed (GH #2195).

``MemoryToolStreamFilter`` sits between the upstream SSE stream and the
client. It forwards every event live except:

* the ``content_block_*`` events of a ``tool_use`` block whose name is a
  proxy-owned memory tool, which it withholds;
* ``message_delta`` / ``message_stop``, which it holds until the caller
  knows whether the turn ends here or continues with a server-side
  continuation round.

Content block indices are rewritten so the blocks the client sees stay
contiguous, including across continuation rounds whose blocks are appended
to the same client message. Frames that need no rewrite are forwarded as the
exact upstream bytes.

Everything the filter holds back (a pending partial frame, withheld tool
blocks and their input, held tail frames) is charged its size on the wire
against ``max_retained_bytes``; past it the filter drops what it holds and
raises ``MemoryToolStreamOverflowError`` rather than forwarding withheld
bytes.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Collection
from typing import Any

from headroom.proxy.sse_byte_buffer_policy import (
    SSE_DATA_LINE_PREFIX,
    SSE_EVENT_LINE_PREFIX,
    find_sse_event_terminator,
)

logger = logging.getLogger(__name__)

_BLOCK_EVENTS = ("content_block_start", "content_block_delta", "content_block_stop")
_TAIL_EVENTS = ("message_delta", "message_stop")

# Same budget as the proxy's SSE reconstruction buffer. Legitimate streams
# retain a few KiB at most: one partial frame plus the memory calls' input.
DEFAULT_MAX_RETAINED_BYTES = 10 * 1024 * 1024


class MemoryToolStreamOverflowError(Exception):
    """The filter would have to retain more than ``max_retained_bytes``."""


def _parse_frame(frame: bytes) -> tuple[str | None, dict[str, Any] | None]:
    """Return ``(event_name, payload)`` for one complete SSE frame."""
    event_name: str | None = None
    data_lines: list[str] = []
    for raw_line in frame.splitlines():
        line = raw_line.decode("utf-8")
        if line.startswith(SSE_EVENT_LINE_PREFIX):
            event_name = line[len(SSE_EVENT_LINE_PREFIX) :].strip()
        elif line.startswith(SSE_DATA_LINE_PREFIX):
            data_lines.append(line[len(SSE_DATA_LINE_PREFIX) :].lstrip())
    if not data_lines:
        return event_name, None
    try:
        payload = json.loads("\n".join(data_lines))
    except json.JSONDecodeError:
        return event_name, None
    if not isinstance(payload, dict):
        return event_name, None
    return event_name or payload.get("type"), payload


def _render_frame(event_name: str, payload: dict[str, Any]) -> bytes:
    return f"event: {event_name}\ndata: {json.dumps(payload)}\n\n".encode()


class MemoryToolStreamFilter:
    """Per-round SSE filter; see the module docstring.

    Args:
        tool_names: Memory tool names the proxy injected and will execute
            itself. Tools the client declared are never withheld.
        index_offset: Client-side index of this round's first visible block.
            Zero for the first round; ``next_index`` of the previous round
            for a continuation round.
        forward_message_start: False for continuation rounds, whose blocks
            extend the message the client already opened.
        max_retained_bytes: Limit on the bytes held back at any time;
            ``DEFAULT_MAX_RETAINED_BYTES`` when None.
        hold_tool_use: Hold every block from the round's first ``tool_use``
            on, until the caller decides with ``release_held``. A withheld
            ``headroom_retrieve`` alongside a client tool is served by
            dropping the client call for the model to re-issue, which is
            only possible while that call has not reached the client.
            Text before the first tool call still streams live.
    """

    def __init__(
        self,
        tool_names: Collection[str],
        *,
        index_offset: int = 0,
        forward_message_start: bool = True,
        max_retained_bytes: int | None = None,
        hold_tool_use: bool = False,
    ) -> None:
        self._tool_names = frozenset(tool_names)
        self._hold_tool_use = hold_tool_use
        self._holding = False
        # Frames held from the first tool_use on, with their upstream index;
        # client indices are assigned when they are released.
        self._held: list[tuple[str, dict[str, Any], bytes, int]] = []
        self._held_bytes = 0
        # Upstream indices of held client tool_use blocks.
        self._held_tool_use: set[int] = set()
        self._max_retained_bytes = (
            DEFAULT_MAX_RETAINED_BYTES if max_retained_bytes is None else max_retained_bytes
        )
        # Wire bytes of the frames behind _hidden (per upstream index) and
        # _tail; _buffer is counted live.
        self._hidden_bytes: dict[int, int] = {}
        self._tail_bytes = 0
        self._forward_message_start = forward_message_start
        self._buffer = bytearray()
        self._index_map: dict[int, int] = {}
        # Withheld tool_use blocks by upstream index, with their streamed
        # input JSON, so the calls can run even when the whole response
        # cannot be reconstructed (buffer cap, unparseable stream).
        self._hidden: dict[int, tuple[dict[str, Any], list[str]]] = {}
        # Upstream indices of withheld blocks whose content_block_stop arrived.
        self._hidden_stopped: set[int] = set()
        self.next_index = index_offset
        self.visible_tool_use = False
        self.stop_reason: str | None = None
        self._tail: list[tuple[str, dict[str, Any] | None, bytes]] = []

    @property
    def hid_tool_calls(self) -> bool:
        return bool(self._hidden)

    @property
    def hidden_tool_names(self) -> list[str]:
        return [block["name"] for block, _ in self._hidden.values()]

    @property
    def holds_client_tool_use(self) -> bool:
        """A client ``tool_use`` block is held and has not reached the client."""
        return bool(self._held_tool_use)

    def release_held(self, *, drop_tool_use: bool = False) -> list[bytes]:
        """Return the held frames, re-indexed, for the client.

        ``drop_tool_use`` leaves out the held client ``tool_use`` blocks: the
        round goes back to the model with the proxy's results instead, and
        the model re-issues whatever it still needs.
        """
        frames: list[bytes] = []
        dropped = self._held_tool_use if drop_tool_use else set()
        for event_name, payload, frame, upstream_index in self._held:
            if upstream_index in dropped:
                continue
            if event_name == "content_block_start":
                block = payload.get("content_block")
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    self.visible_tool_use = True
                self._index_map[upstream_index] = self.next_index
                self.next_index += 1
            client_index = self._index_map.get(upstream_index, upstream_index)
            if client_index == upstream_index:
                frames.append(frame)
            else:
                frames.append(_render_frame(event_name, {**payload, "index": client_index}))
        self._held.clear()
        self._held_bytes = 0
        self._held_tool_use.clear()
        return frames

    def hidden_calls(self) -> list[dict[str, Any]]:
        """The withheld ``tool_use`` blocks that finished with a complete input.

        A call cut off mid-input (e.g. ``max_tokens``) or whose block never
        reached ``content_block_stop`` (the stream ended early) is left out
        rather than run: the model never finished requesting it, and some
        memory tools mutate state.
        """
        calls: list[dict[str, Any]] = []
        for upstream_index, (block, parts) in self._hidden.items():
            if upstream_index not in self._hidden_stopped:
                logger.warning(
                    "Memory: skipping %s call %s whose block never finished",
                    block.get("name"),
                    block.get("id"),
                )
                continue
            tool_input: Any = block.get("input") or {}
            if parts:
                try:
                    tool_input = json.loads("".join(parts))
                except json.JSONDecodeError:
                    logger.warning(
                        "Memory: skipping %s call %s with incomplete input",
                        block.get("name"),
                        block.get("id"),
                    )
                    continue
            if not isinstance(tool_input, dict):
                continue
            calls.append({**block, "input": tool_input})
        return calls

    def feed(self, chunk: bytes) -> list[bytes]:
        """Consume upstream bytes; return the frames to forward now.

        Raises:
            MemoryToolStreamOverflowError: The bytes held back exceed
                ``max_retained_bytes``. The filter has dropped them; the
                caller must end the stream instead of forwarding anything
                further.
        """
        self._buffer.extend(chunk)
        out: list[bytes] = []
        while (match := find_sse_event_terminator(self._buffer)) is not None:
            idx, terminator_len = match
            frame = bytes(self._buffer[: idx + terminator_len])
            del self._buffer[: idx + terminator_len]
            forwarded = self._route(frame)
            if forwarded is not None:
                out.append(forwarded)
        retained = (
            len(self._buffer)
            + self._tail_bytes
            + self._held_bytes
            + sum(self._hidden_bytes.values())
        )
        if retained > self._max_retained_bytes:
            self._buffer.clear()
            self._hidden.clear()
            self._hidden_bytes.clear()
            self._hidden_stopped.clear()
            self._tail.clear()
            self._tail_bytes = 0
            self._held.clear()
            self._held_bytes = 0
            self._held_tool_use.clear()
            raise MemoryToolStreamOverflowError(
                f"memory tool stream filter would retain {retained} bytes "
                f"(limit {self._max_retained_bytes})"
            )
        return out

    def _route(self, frame: bytes) -> bytes | None:
        event_name, payload = _parse_frame(frame)
        if payload is None or event_name is None:
            return frame

        if event_name == "message_start":
            return frame if self._forward_message_start else None

        if event_name in _TAIL_EVENTS:
            if event_name == "message_delta":
                delta = payload.get("delta")
                if isinstance(delta, dict) and delta.get("stop_reason"):
                    self.stop_reason = delta["stop_reason"]
            self._tail.append((event_name, payload, frame))
            self._tail_bytes += len(frame)
            return None

        if event_name not in _BLOCK_EVENTS:
            return frame

        upstream_index = payload.get("index")
        if not isinstance(upstream_index, int):
            return frame

        if event_name == "content_block_start":
            block = payload.get("content_block")
            if (
                isinstance(block, dict)
                and block.get("type") == "tool_use"
                and block.get("name") in self._tool_names
            ):
                # A repeated start for the same index replaces the block,
                # its charge and any earlier stop. The frame may carry the
                # whole input inline, so it is charged in full.
                self._hidden[upstream_index] = (block, [])
                self._hidden_bytes[upstream_index] = len(frame)
                self._hidden_stopped.discard(upstream_index)
                self._holding = self._hold_tool_use
                return None
            is_tool_use = isinstance(block, dict) and block.get("type") == "tool_use"
            if self._hold_tool_use and (self._holding or is_tool_use):
                self._holding = True
                if is_tool_use:
                    self._held_tool_use.add(upstream_index)
            else:
                if is_tool_use:
                    self.visible_tool_use = True
                self._index_map[upstream_index] = self.next_index
                self.next_index += 1

        if upstream_index in self._hidden:
            delta = payload.get("delta")
            if (
                event_name == "content_block_delta"
                and isinstance(delta, dict)
                and delta.get("type") == "input_json_delta"
            ):
                self._hidden[upstream_index][1].append(str(delta.get("partial_json", "")))
                # The frame's size bounds the fragment's, and needs no
                # re-encoding (a lone surrogate cannot be encoded).
                self._hidden_bytes[upstream_index] += len(frame)
            elif event_name == "content_block_stop":
                self._hidden_stopped.add(upstream_index)
            return None
        if self._holding and upstream_index not in self._index_map:
            self._held.append((event_name, payload, frame, upstream_index))
            self._held_bytes += len(frame)
            return None
        client_index = self._index_map.get(upstream_index, upstream_index)
        if client_index == upstream_index:
            return frame
        return _render_frame(event_name, {**payload, "index": client_index})

    def closing_frames(self, *, prior_usage: dict[str, int] | None = None) -> list[bytes]:
        """End the client message after this round without a continuation.

        Held frames are released first, client tool calls included: with no
        continuation, the round is the model's answer as it stands.
        """
        held = self.release_held()
        ends_on_hidden_call = (
            self.hid_tool_calls and not self.visible_tool_use and self.stop_reason == "tool_use"
        )
        return held + self.tail_frames(
            stop_reason="end_turn" if ends_on_hidden_call else None,
            prior_usage=prior_usage,
        )

    def tail_frames(
        self,
        *,
        stop_reason: str | None = None,
        prior_usage: dict[str, int] | None = None,
    ) -> list[bytes]:
        """Return the held ``message_delta`` / ``message_stop`` frames.

        ``stop_reason`` replaces the upstream stop reason, e.g. ``end_turn``
        when the only tool calls were withheld memory calls: a ``tool_use``
        stop with no visible ``tool_use`` block leaves the client waiting on
        a tool it was never shown.

        ``prior_usage`` holds earlier continuation rounds' usage. Their
        ``message_delta`` frames never reach the client, so it is added to
        this one: ``output_tokens`` always, other counters where the delta
        reports them.
        """
        frames: list[bytes] = []
        for event_name, payload, raw in self._tail:
            if (
                event_name != "message_delta"
                or payload is None
                or not isinstance(payload.get("delta"), dict)
                or (stop_reason is None and not prior_usage)
            ):
                frames.append(raw)
                continue
            rendered = dict(payload)
            if stop_reason is not None:
                rendered["delta"] = {**payload["delta"], "stop_reason": stop_reason}
            if prior_usage:
                usage = dict(payload.get("usage") or {})
                for key, value in prior_usage.items():
                    if key == "output_tokens" or isinstance(usage.get(key), int):
                        usage[key] = int(usage.get(key) or 0) + value
                rendered["usage"] = usage
            frames.append(_render_frame(event_name, rendered))
        if self._buffer:
            # The stream ended mid-frame. It may belong to a withheld block,
            # so drop it rather than risk exposing it to the client.
            logger.warning(
                "Memory: dropping %d bytes of an unterminated SSE frame at end of stream",
                len(self._buffer),
            )
            self._buffer.clear()
        return frames
