"""LiteLLM callback — add Headroom compression to LiteLLM with one line.

    # Local mode (compression runs in-process):
    import litellm
    from headroom.integrations.litellm_callback import HeadroomCallback

    litellm.callbacks = [HeadroomCallback()]

    # Cloud mode (managed CCR, TOIN, analytics via Headroom Cloud):
    litellm.callbacks = [HeadroomCallback(api_key="hdr_xxx")]

Works with LiteLLM's completion(), acompletion(), the Anthropic Messages
proxy routes (/v1/messages), and proxy modes.
Cloud mode requires httpx: pip install httpx
"""

from __future__ import annotations

import logging
from typing import Any

# _DEFAULT_CLOUD_URL and guard_egress stay importable from this module.
from headroom.integrations._compress_backend import (  # noqa: F401
    _DEFAULT_CLOUD_URL,
    CompressBackend,
)
from headroom.offline import guard_egress, pin_litellm_cost_map_local  # noqa: F401

logger = logging.getLogger(__name__)


try:
    pin_litellm_cost_map_local()
    from litellm.integrations.custom_logger import CustomLogger as _CustomLogger
except ImportError:  # litellm not installed — fall back to plain object
    _CustomLogger = object  # type: ignore[assignment,misc]


class HeadroomCallback(CompressBackend, _CustomLogger):
    """LiteLLM callback that compresses messages before each API call.

    Implements the LiteLLM callback hooks looked up by name:
    ``async_pre_call_hook``, ``async_post_call_success_hook``,
    ``async_success_handler`` and ``async_failure_handler``.

    Inherits from litellm.integrations.custom_logger.CustomLogger so that
    any hook LiteLLM adds in future versions (e.g. async_post_call_success_hook
    added in 1.89.x) has a no-op default and won't raise AttributeError (#1114).

    Two modes:
    - Local (default): Compresses in-process using headroom.compress().
    - Cloud (api_key set): Calls Headroom Cloud API for managed compression
      with org-scoped CCR, TOIN learning, and analytics dashboards.

    Usage (local):
        litellm.callbacks = [HeadroomCallback()]

    Usage (cloud):
        litellm.callbacks = [HeadroomCallback(api_key="hdr_xxx")]

    Usage (cloud with LiteLLM proxy config):
        # litellm_config.yaml
        litellm_settings:
          callbacks: [headroom.integrations.litellm_callback.HeadroomCallback]
        environment_variables:
          HEADROOM_API_KEY: "hdr_xxx"
    """

    _log = logger

    def __init__(
        self,
        min_tokens: int = 500,
        model_limit: int = 200000,
        hooks: Any = None,
        api_key: str | None = None,
        api_url: str | None = None,
    ) -> None:
        super().__init__()
        self._min_tokens = min_tokens
        self._total_saved = 0
        self._init_compress_backend(model_limit, hooks, api_key, api_url)

    @property
    def total_tokens_saved(self) -> int:
        """Total tokens saved across all calls."""
        return self._total_saved

    async def aclose(self) -> None:
        """Close the shared cloud HTTP client, if it was initialized.

        Applications using LiteLLM should await this method during their async
        shutdown lifecycle. It is safe to call when cloud mode was not used or
        after the client has already been closed.
        """
        client = self._client
        self._client = None
        if client is not None:
            await client.aclose()

    async def async_pre_call_hook(
        self,
        user_api_key_dict: Any = None,
        cache: Any = None,
        data: dict[Any, Any] | None = None,
        call_type: str = "",
        *_args: Any,
        **_kwargs: Any,
    ) -> dict[Any, Any] | None:
        """Called by LiteLLM before each API call. Compresses messages."""
        if isinstance(cache, dict) and isinstance(data, str):
            data, call_type = cache, data

        if data is None:
            return None

        # LiteLLM's proxy maps the Anthropic Messages API routes to their own
        # call types (CallTypes.anthropic_messages for /v1/messages and
        # /anthropic/v1/messages, plus the async twin), and the payload still
        # carries "messages" in Anthropic format, which compress() handles.
        if call_type not in (
            "completion",
            "acompletion",
            "anthropic_messages",
            "aanthropic_messages",
        ):
            return data

        messages = data.get("messages", [])
        model = data.get("model", "")

        if not messages:
            return data

        try:
            if self._api_key:
                result = await self._cloud_compress(messages, model)
            else:
                result = self._local_compress(messages, model)

            if result and result.get("tokens_saved", 0) > 0 and "messages" in result:
                data["messages"] = result["messages"]
                self._total_saved += result["tokens_saved"]
                logger.info(
                    "Headroom%s: %d→%d tokens (saved %d, %.0f%%) [total saved: %d]",
                    " Cloud" if self._api_key else "",
                    result["tokens_before"],
                    result["tokens_after"],
                    result["tokens_saved"],
                    result.get("compression_ratio", 0) * 100,
                    self._total_saved,
                )

        except Exception as e:
            logger.warning("Headroom compression failed, using original messages: %s", e)

        return data

    async def async_post_call_success_hook(
        self,
        data: dict[str, Any],
        user_api_key_dict: Any,
        response: Any,
    ) -> Any:
        """Called by the LiteLLM proxy after a successful call. Returns response unchanged."""
        return response

    async def async_success_handler(
        self, kwargs: dict, response: Any, start_time: Any, end_time: Any
    ) -> None:
        """Called after successful completion. No-op for now."""
        pass

    async def async_failure_handler(
        self, kwargs: dict, response: Any, start_time: Any, end_time: Any
    ) -> None:
        """Called after failed completion. No-op for now."""
        pass
