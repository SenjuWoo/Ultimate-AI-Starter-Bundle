"""Provider-shaped CCR tool-call extraction and classification."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from headroom.proxy.tool_name_policy import extract_tool_name

from .tool_injection import CCR_TOOL_NAME, parse_tool_call

_CLIENT_CCR_TOOL_ALIASES = frozenset(
    {
        "headroom_headroom_retrieve",
        "mcp__headroom__headroom_retrieve",
        "mcp_headroom_headroom_retrieve",
    }
)


@dataclass
class CCRToolCall:
    """Represents a detected CCR retrieval tool call."""

    tool_call_id: str
    hash_key: str
    tool_name: str | None = None


def extract_tool_calls(response: dict[str, Any], provider: str) -> list[dict[str, Any]]:
    """Extract provider-native tool-call objects from a response payload."""
    if provider == "anthropic":
        content = response.get("content", [])
        if isinstance(content, list):
            return [
                block
                for block in content
                if isinstance(block, dict) and block.get("type") == "tool_use"
            ]
        return []

    if provider == "openai":
        choices = response.get("choices", [])
        if not isinstance(choices, list) or not choices:
            return []
        first_choice = choices[0]
        if not isinstance(first_choice, dict):
            return []
        message = first_choice.get("message", {})
        if not isinstance(message, dict):
            return []
        tool_calls = message.get("tool_calls", [])
        return list(tool_calls) if isinstance(tool_calls, list) else []

    if provider == "google":
        candidates = response.get("candidates", [])
        if not isinstance(candidates, list) or not candidates:
            return []
        first_candidate = candidates[0]
        if not isinstance(first_candidate, dict):
            return []
        content = first_candidate.get("content", {})
        if not isinstance(content, dict):
            return []
        parts = content.get("parts", [])
        if not isinstance(parts, list):
            return []
        return [part for part in parts if isinstance(part, dict) and "functionCall" in part]

    if provider == "openai_responses":
        output = response.get("output", [])
        if isinstance(output, list):
            return [
                item
                for item in output
                if isinstance(item, dict) and item.get("type") == "function_call"
            ]
        return []

    return []


def drop_tool_calls(
    response: dict[str, Any],
    provider: str,
    calls: list[dict[str, Any]],
) -> dict[str, Any]:
    """Return a shallow copy of ``response`` without ``calls``.

    ``calls`` are objects ``extract_tool_calls`` returned for this response and
    are matched by identity. Anthropic and OpenAI chat only: a Responses
    ``function_call`` can be the item a ``reasoning`` item requires next, and a
    Gemini ``functionCall`` part can carry the turn's thought signature, so
    removing one there can make the continuation invalid. Other providers get
    ``response`` back unchanged.
    """
    drop = {id(call) for call in calls}
    if provider == "anthropic":
        content = response.get("content")
        if isinstance(content, list):
            return {**response, "content": [b for b in content if id(b) not in drop]}
    elif provider == "openai":
        choices = response.get("choices")
        if isinstance(choices, list) and choices and isinstance(choices[0], dict):
            message = choices[0].get("message")
            if isinstance(message, dict) and isinstance(message.get("tool_calls"), list):
                tool_calls = [c for c in message["tool_calls"] if id(c) not in drop]
                first = {**choices[0], "message": {**message, "tool_calls": tool_calls}}
                return {**response, "choices": [first, *choices[1:]]}
    return response


def is_ccr_tool_call(tool_call: dict[str, Any]) -> bool:
    """Return true when a provider-native tool call names the CCR retrieval tool."""
    return (
        tool_call.get("name") == CCR_TOOL_NAME
        or (tool_call.get("function") or {}).get("name") == CCR_TOOL_NAME
        or (tool_call.get("functionCall") or {}).get("name") == CCR_TOOL_NAME
    )


def has_ccr_retrieve_tool(tools: Any) -> bool:
    """Return true when a tool list defines the CCR retrieval tool.

    Accepts flat definitions (Anthropic, OpenAI Responses: ``{"name": ...}``) and
    chat-completions definitions nested under ``"function"``.
    """
    if not isinstance(tools, list):
        return False
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        if tool.get("name") == CCR_TOOL_NAME:
            return True
        function = tool.get("function")
        if isinstance(function, dict) and function.get("name") == CCR_TOOL_NAME:
            return True
    return False


def client_retrieval_tool_name(tools: list[dict[str, Any]] | None) -> str | None:
    """Select the canonical retrieval tool, or a default Headroom MCP alias."""
    alias = None
    for tool in tools or ():
        name = extract_tool_name(tool)
        if name == CCR_TOOL_NAME:
            return name
        if alias is None and isinstance(name, str) and name.lower() in _CLIENT_CCR_TOOL_ALIASES:
            alias = name
    return alias


def has_ccr_tool_calls(response: dict[str, Any], provider: str) -> bool:
    """Return true when ``response`` contains at least one CCR tool call."""
    return any(is_ccr_tool_call(tool_call) for tool_call in extract_tool_calls(response, provider))


def tool_call_id_for_provider(tool_call: dict[str, Any], provider: str) -> str:
    """Return the provider-specific identifier used by the matching tool result."""
    if provider == "google":
        function_call = tool_call.get("functionCall", {})
        if isinstance(function_call, dict):
            if function_call.get("id"):
                return str(function_call["id"])
            name = function_call.get("name", CCR_TOOL_NAME)
            return str(name)
        return CCR_TOOL_NAME
    if provider == "openai_responses":
        call_id = tool_call.get("call_id", tool_call.get("id", ""))
        return str(call_id)
    return str(tool_call.get("id", ""))


def parse_ccr_tool_calls(
    response: dict[str, Any],
    provider: str,
) -> tuple[list[CCRToolCall], list[dict[str, Any]]]:
    """Split provider-native tool calls into CCR retrievals and other tools."""
    ccr_calls: list[CCRToolCall] = []
    other_calls: list[dict[str, Any]] = []

    for tool_call in extract_tool_calls(response, provider):
        hash_key = parse_tool_call(tool_call, provider)
        if hash_key is None:
            other_calls.append(tool_call)
            continue

        tool_name = None
        tool_call_id = tool_call_id_for_provider(tool_call, provider)
        if provider == "google":
            function_call = tool_call.get("functionCall", {})
            if isinstance(function_call, dict) and function_call.get("id"):
                tool_name = str(function_call.get("name", CCR_TOOL_NAME))
        ccr_calls.append(
            CCRToolCall(tool_call_id=tool_call_id, hash_key=hash_key, tool_name=tool_name)
        )

    return ccr_calls, other_calls
