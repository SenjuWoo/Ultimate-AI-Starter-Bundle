"""Loop detection for Headroom Learn — find repeated tool-call patterns.

A *loop* is the single highest-value pattern for `headroom learn` to catch,
because its token waste scales with the number of repetitions rather than
being a one-time cost. Two loop shapes matter:

1. **Error loops** — the same call fails, the agent retries, it fails again
   (e.g. a wrong path read N times). Every repetition is pure waste.

2. **Re-fetch loops** — a shell command's output is limited or truncated
   (``grep foo | head -50``). When the limit drops what the agent needed, the
   agent re-runs a *variant* of the same command to fetch more (``head -100``,
   a new offset, a narrower pattern). Each call succeeds (``is_error=False``)
   but returns insufficient output, so the loop is invisible to failure-only
   analysis.

This module collapses such variants to a canonical signature, counts the
repetitions, and measures the wasted tokens so the analyzer can (a) surface
loops to the LLM and (b) weight loop-derived recommendations above one-offs.
The analyzer historically ranked recommendations purely by an LLM-guessed
``estimated_tokens_saved`` with a flat confidence — loops had no special
weight at all.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field

from .models import Recommendation, SessionData, ToolCall

# Upper bound on the signature body kept for fuzzy rule matching. Matches the
# width that ``input_summary`` previously imposed, so the majority-overlap rule
# in ``apply_loop_weighting`` keeps behaving exactly as it did before identity
# stopped going through that truncation.
_SIGNATURE_MATCH_LIMIT = 100

# Minimum repetitions of one signature before it counts as a loop. Three is the
# smallest count that distinguishes a loop ("again, and again") from a one-off
# retry ("that failed once, try once more") — matching the analyzer's existing
# "2+ occurrences or explicit user direction" evidence bar but one stricter so
# a single retry is not mislabeled a loop.
DEFAULT_MIN_OCCURRENCES = 3

# Rough bytes-per-token used to convert measured output sizes into a token
# estimate. The analyzer's digest builder uses the same 4:1 approximation.
_BYTES_PER_TOKEN = 4

# Pagination / output-limiting fragments that vary between re-fetch
# attempts but do NOT change which command is being run. Stripping these is
# what collapses ``grep foo | head -50`` and ``grep foo | head -100`` to one
# signature. Order-independent: applied as a global substitution.
_PAGINATION_PATTERNS = [
    r"\|\s*head\s+-n?\s*\d+",  # | head -50, | head -n 50
    r"\|\s*tail\s+-n?\s*\d+",  # | tail -50
    r"-n\s*\d+",  # -n 50 (git log -n 50, grep -n is rare but harmless here)
    r"--max-count[= ]\d+",  # grep --max-count=50
    r"--lines[= ]\d+",
    r"\bhead\s+-\d+",  # head -50
    r"\b(limit|offset)[= ]\d+",  # LIMIT 50 / offset=100 (sql-ish)
    r"\bLIMIT\s+\d+",
    r"\bOFFSET\s+\d+",
]
_PAGINATION_RE = re.compile("|".join(_PAGINATION_PATTERNS), re.IGNORECASE)

# Collapse any remaining bare integers so e.g. line numbers / byte offsets in
# otherwise identical commands do not split a loop into singletons.
_INT_RE = re.compile(r"\b\d+\b")

# A loop's digest line shows its sample input cut to this many chars and its
# first _DIGEST_MAX_INDICES message indices beside its full repeat count.
_SAMPLE_INPUT_CHARS = 120
_DIGEST_MAX_INDICES = 20


@dataclass
class LoopPattern:
    """A repeated tool-call pattern detected within a session.

    ``wasted_tokens`` is a *measured* lower bound (from real output sizes),
    not an LLM guess — for an N-occurrence loop it counts the N-1 redundant
    repetitions, since the first call is legitimate work.
    """

    tool: str
    signature: str  # Canonical, variant-collapsed signature
    sample_input: str  # A human-readable example of the looped call
    count: int
    is_error_loop: bool
    wasted_tokens: int
    msg_indices: list[int] = field(default_factory=list)

    @property
    def kind(self) -> str:
        return "error-loop" if self.is_error_loop else "refetch-loop"


# Input fields that identify a call, per tool. ``ToolCall.input_summary`` reads
# the same fields but is a *display* helper — it cuts Bash commands at 100 chars
# and renders any tool missing from this table as ``str(input_data)[:80]``. Two
# distinct calls sharing a long prefix survive that truncation as equal strings,
# so identity is taken from the untruncated input here instead.
#
# Because identity no longer reads ``input_summary``, a field that distinguishes
# two calls has to be named here to count — adding one to the summary alone
# changes the display and leaves the grouping merged.
#
# Adding a *second* field to a tool listed here also moves it to the structured
# identity form in ``_identity_input``, which ``_PAGINATION_RE`` below is not
# written against — so a second field on ``bash``/``shell`` would stop
# re-fetch variants of one command collapsing.
_IDENTITY_FIELDS: dict[str, tuple[str, ...]] = {
    "bash": ("command",),
    "shell": ("command",),
    "read": ("file_path",),
    # A search is identified by pattern *and* path: the same pattern swept
    # across three service directories is three searches, not a loop. #3455
    # pins this on the display side; identity has to agree or one undoes the
    # other depending on merge order.
    "grep": ("pattern", "path"),
    "glob": ("pattern", "path"),
    "edit": ("file_path",),
    "write": ("file_path",),
}


def _identity_input(tc: ToolCall) -> str:
    """Render a tool call's input in full, for identity comparison.

    Falls back to the whole input mapping — key-sorted so ordering cannot split
    a group — rather than to a truncated ``repr``. The fallback also covers a
    tool that *is* in :data:`_IDENTITY_FIELDS` but carries none of its fields:
    ``normalize_tool_name`` maps provider tools onto the builtin names without
    normalizing their input schema, and an empty identity would collapse every
    such call into one loop — the merge this function exists to prevent.
    """
    data = tc.input_data if isinstance(tc.input_data, dict) else {}
    fields = _IDENTITY_FIELDS.get(tc.name.lower())
    if fields is not None:
        parts = [str(data.get(field, "")) for field in fields]
        if any(parts):
            # A lone field is already unambiguous, and leaving it bare is what
            # the shell pagination normalization below matches against. Two or
            # more have to carry their own boundaries: joined on a space,
            # ("error in src", "logs") and ("error", "in src logs") are two
            # different searches rendering one string — and so one phantom loop.
            # Escaping stays off: ``\u00e9`` would reach _signature_tokens as a
            # token no recommendation can contain, diluting the majority overlap
            # apply_loop_weighting needs to credit the loop.
            return parts[0] if len(parts) == 1 else json.dumps(parts, ensure_ascii=False)
    try:
        return json.dumps(tc.input_data, sort_keys=True, default=repr, ensure_ascii=False)
    except TypeError:
        # Unorderable keys — not reachable from parsed JSON, but identity is
        # derived from files the user did not write, so it must not raise.
        return str(tc.input_data)


def _canonical_signature(tc: ToolCall) -> str:
    """Collapse a tool call to a signature stable across re-fetch variants.

    For shell commands this strips pagination/limit fragments and bare
    integers so output-limit variants of the same command map together.
    For other tools the identity input is normalized on whitespace only.
    """
    raw = _identity_input(tc).strip()
    if tc.name.lower() in ("bash", "shell"):
        raw = _PAGINATION_RE.sub(" ", raw)
        raw = _INT_RE.sub("N", raw)
    # ``" ".join(split())`` collapses whitespace runs and strips, identically to
    # ``re.sub(r"\s+", " ", raw).strip()`` but without the regex engine walking the
    # whole input — the dominant cost now that the signature is the untruncated one.
    raw = " ".join(raw.split()).lower()
    return f"{tc.name.lower()}::{raw}"


def _group_key(signature: str) -> str:
    """Fixed-size grouping key for a canonical signature.

    The signature is lossless, so it can be as large as the tool input itself.
    Hashing keeps the grouping tables bounded regardless of input size; the
    digest is never surfaced, only used to bucket identical signatures.
    """
    return hashlib.blake2b(signature.encode("utf-8", "replace"), digest_size=16).hexdigest()


def _fuzzy_signature(signature: str) -> str:
    """Bounded form of a canonical signature, for fuzzy rule matching.

    ``LoopPattern.signature`` is consumed only by :func:`_signature_tokens`,
    which requires a *majority* of its tokens to appear in a recommendation. An
    unbounded signature would put that threshold out of reach for large inputs
    and silently strip real loops of their measured-waste boost, so the stored
    value is capped. Identity still comes from the full signature above.
    """
    name, sep, body = signature.partition("::")
    return f"{name}{sep}{body[:_SIGNATURE_MATCH_LIMIT]}"


def _tokens(tc: ToolCall) -> int:
    """Token estimate for a single call's output."""
    nbytes = tc.output_bytes or len(tc.output)
    return nbytes // _BYTES_PER_TOKEN


def _without_replays(calls: list[ToolCall], seen: set[str]) -> list[ToolCall]:
    """Drop calls whose ``tool_call_id`` is already in ``seen``, recording the rest.

    ``seen`` is mutated, so the caller chooses the scope a replay is judged
    against: a fresh set collapses a transcript's own repeated turns, while a
    set carried across sessions suppresses a resume's replay of earlier ones.
    An id-less call is always kept — nothing identifies it as a replay.
    """
    kept: list[ToolCall] = []
    for call in calls:
        if call.tool_call_id:
            if call.tool_call_id in seen:
                continue
            seen.add(call.tool_call_id)
        kept.append(call)
    return kept


def detect_loops(
    sessions: list[SessionData],
    *,
    min_occurrences: int = DEFAULT_MIN_OCCURRENCES,
) -> list[LoopPattern]:
    """Detect repeated tool-call patterns across sessions.

    Calls are grouped by canonical signature *within each session* (a loop is
    a within-conversation phenomenon; the same command in two unrelated
    sessions is not a loop). Groups meeting ``min_occurrences`` become
    ``LoopPattern`` results, sorted by measured wasted tokens descending.

    A call is counted once per ``tool_call_id``. A resumed conversation can be
    written as a fresh transcript that replays earlier turns, which presents the
    same provider-assigned call to the scanner more than once; without this the
    replayed turns would inflate the loop. Calls carrying no id are always
    counted, since nothing identifies them as replays.

    This makes ``tool_call_id`` uniqueness a scanner contract: an id must be
    unique across sessions, not just within one, or two unrelated sessions look
    like one replayed twice. Scanners that synthesize ids scope them by session
    (see ``GeminiPlugin`` and ``OpenCodePlugin``).

    Dedup runs *before* the threshold, twice over. A session is screened on its
    distinct calls, because the question the threshold asks — did this
    conversation repeat itself? — is not answered by one call written into the
    transcript three times. Only then are its calls merged, deduped again
    against the calls already collected for that signature so a resume that
    replays an earlier session adds only what is new. Screening the raw group
    instead would let three sessions that each merely replayed one call
    contribute one real call apiece and clear the bar together, reporting a loop
    no conversation ran.
    """
    groups: dict[str, list[ToolCall]] = {}
    signatures: dict[str, str] = {}
    seen_ids: dict[str, set[str]] = {}
    for session in sessions:
        per_session: dict[str, list[ToolCall]] = {}
        for tc in session.tool_calls:
            sig = _canonical_signature(tc)
            key = _group_key(sig)
            signatures.setdefault(key, sig)
            per_session.setdefault(key, []).append(tc)
        # Merge each session's qualifying groups into the global view keyed by
        # signature so cross-session recurrence of the SAME loop accumulates.
        for key, calls in per_session.items():
            distinct = _without_replays(calls, set())
            if len(distinct) < min_occurrences:
                continue
            bucket = groups.setdefault(key, [])
            bucket.extend(_without_replays(distinct, seen_ids.setdefault(key, set())))

    loops: list[LoopPattern] = []
    for key, calls in groups.items():
        # No post-merge threshold re-check: every group here was seeded by a
        # session that cleared the bar on its own distinct calls, and merging
        # only ever adds.
        count = len(calls)
        is_error_loop = sum(1 for c in calls if c.is_error) >= (count / 2)
        if is_error_loop:
            # Every repetition of a failing call is waste — including the first,
            # since with upfront knowledge it would never have run.
            wasted = sum(_tokens(c) for c in calls)
        else:
            # Re-fetch loop: the first call is legitimate; the N-1 follow-ups
            # are the redundant re-fetches the output truncation provoked.
            per_call = sorted((_tokens(c) for c in calls), reverse=True)
            wasted = sum(per_call[1:])
        loops.append(
            LoopPattern(
                tool=calls[0].name,
                signature=_fuzzy_signature(signatures[key]),
                sample_input=calls[0].input_summary[:_SAMPLE_INPUT_CHARS],
                count=count,
                is_error_loop=is_error_loop,
                wasted_tokens=wasted,
                msg_indices=sorted(c.msg_index for c in calls),
            )
        )

    loops.sort(key=lambda lp: lp.wasted_tokens, reverse=True)
    return loops


def format_loops_for_digest(loops: list[LoopPattern], max_chars: int | None = None) -> str:
    """Render detected loops as a high-priority digest section for the LLM.

    Loops are rendered in the given order (detect_loops sorts them costliest
    first). With *max_chars*, rendering stops at the first loop that would
    take the section past that many chars, so the costliest ones are kept.

    Returns "" when there are no loops, or none fits, so the digest is
    unchanged in the common case.
    """
    if not loops:
        return ""
    header = [
        "=== Detected Loops (HIGHEST PRIORITY) ===",
        (
            "These tool-call patterns REPEATED within a session — the most "
            "expensive kind of waste, since cost scales with repetition. A rule "
            "that prevents a loop is worth far more than one that prevents a "
            "one-off error. Emit a guardrail for EACH loop below and set its "
            "estimated_tokens_saved to at least the measured wasted tokens shown."
        ),
        "",
    ]
    used = sum(len(ln) + 1 for ln in header)  # each line plus its newline
    entries: list[str] = []
    for lp in loops:
        entry = (
            f'- [{lp.kind}] {lp.tool}: "{lp.sample_input[:_SAMPLE_INPUT_CHARS]}" '
            f"repeated {lp.count}x, ~{lp.wasted_tokens:,} tokens wasted "
            f"(messages {lp.msg_indices[:_DIGEST_MAX_INDICES]})"
        )
        used += len(entry) + 1
        if max_chars is not None and used > max_chars:
            break
        entries.append(entry)
    if not entries:
        return ""
    return "\n".join([*header, *entries, ""])


def _signature_tokens(signature: str) -> set[str]:
    """Word tokens from a canonical signature, for fuzzy rule matching."""
    body = signature.split("::", 1)[-1]
    return {t for t in re.split(r"[^a-z0-9]+", body) if len(t) > 2}


def apply_loop_weighting(recommendations: list[Recommendation], loops: list[LoopPattern]) -> None:
    """Boost recommendations that address a detected loop, in place.

    The analyzer ranks recommendations by ``estimated_tokens_saved`` (an LLM
    guess). For a recommendation whose text overlaps a detected loop's
    signature, we raise that figure to at least the loop's *measured* wasted
    tokens and tag it as loop-derived. Because measured loop waste aggregates
    many repetitions, this reliably lifts loop guardrails above one-off rules
    without trusting the LLM to have weighted them correctly.
    """
    if not loops:
        return
    for rec in recommendations:
        haystack = f"{rec.section} {rec.content}".lower()
        best: LoopPattern | None = None
        for lp in loops:
            sig_tokens = _signature_tokens(lp.signature)
            if not sig_tokens:
                continue
            overlap = sum(1 for t in sig_tokens if t in haystack)
            # Require a majority of the signature's salient tokens to appear so
            # we don't over-credit a generic rule.
            if overlap >= max(1, (len(sig_tokens) + 1) // 2):
                if best is None or lp.wasted_tokens > best.wasted_tokens:
                    best = lp
        if best is not None:
            rec.estimated_tokens_saved = max(rec.estimated_tokens_saved, best.wasted_tokens)
            rec.is_loop_guardrail = True
            rec.loop_occurrences = best.count
