"""Hermes Studio scoped coding-agent proxy support.

Hermes owns authentication and protocol adaptation for its scoped proxy routes.
This module owns the small Headroom integration point: safely compress the chat
portion of those requests before the generic proxy forwards them upstream.
"""

from __future__ import annotations

import json
import logging
import os
from collections.abc import Mapping
from typing import Any

from headroom.providers.claude import proxy_base_url as claude_proxy_base_url
from headroom.providers.codex import proxy_base_url as codex_proxy_base_url

logger = logging.getLogger("headroom.providers.hermes")

_CHAT_ROLES = frozenset({"user", "assistant"})
_CLAUDE_TEXT_PART_TYPES = frozenset({"text"})
# Responses uses protocol-specific text part names; normalize these only while
# passing a message through the generic compressor, then restore them exactly.
_RESPONSES_TEXT_PART_TYPES = frozenset({"text", "input_text", "output_text"})
_CODEX_RESPONSES_SUFFIX = "/v1/responses"
_CLAUDE_MESSAGES_SUFFIX = "/v1/messages"
# Hermes Studio's scoped proxy prefixes. They live under `/api/`, so a
# Factory-mode proxy must keep every path below them on the normal catch-all.
CODEX_PROXY_PREFIX = "/api/codex-proxy/"
CLAUDE_CODE_PROXY_PREFIX = "/api/claude-code-proxy/"
SCOPED_PATH_PREFIXES = (CODEX_PROXY_PREFIX, CLAUDE_CODE_PROXY_PREFIX)


def build_launch_env(
    port: int, environ: Mapping[str, str] | None = None
) -> tuple[dict[str, str], list[str]]:
    """Build the environment used to route the Hermes CLI through Headroom."""
    env = dict(environ if environ is not None else os.environ)
    openai_base_url = codex_proxy_base_url(port)
    anthropic_base_url = claude_proxy_base_url(port)
    env["OPENAI_BASE_URL"] = openai_base_url
    env["ANTHROPIC_BASE_URL"] = anthropic_base_url
    return env, [
        f"OPENAI_BASE_URL={openai_base_url}",
        f"ANTHROPIC_BASE_URL={anthropic_base_url}",
    ]


# Hermes honors OPENAI_BASE_URL / ANTHROPIC_BASE_URL only for these providers.
# Its default (openrouter) and others such as nous call their own endpoints.
_ROUTED_PROVIDERS = frozenset({"anthropic", "openai"})


def unsupported_provider_error(hermes_args: tuple[str, ...] | list[str]) -> str | None:
    """Return an error unless ``--provider`` names a provider Headroom can route.

    ponytail: the flag is required on purpose. Hermes also resolves a provider
    from config.yaml and HERMES_INFERENCE_PROVIDER; mirroring that order here
    would drift. Parse them only if requiring the flag proves too strict.
    """
    args = list(hermes_args)
    provider = ""
    for index, arg in enumerate(args):
        if arg == "--provider" and index + 1 < len(args):
            provider = args[index + 1]
        elif arg.startswith("--provider="):
            provider = arg.split("=", 1)[1]
    if provider.strip().lower() in _ROUTED_PROVIDERS:
        return None
    selected = f"'{provider}'" if provider else "no --provider flag"
    return (
        f"Error: Headroom cannot route this Hermes launch ({selected}).\n"
        "Only the anthropic and openai providers go through Headroom. Hermes's "
        "default provider (openrouter) and others such as nous call their own "
        "endpoints.\n"
        "Run: headroom wrap hermes -- --provider anthropic\n"
        "To use another provider, run `hermes` directly, without Headroom."
    )


def is_scoped_coding_agent_path(path: str) -> bool:
    """Return whether *path* is a Hermes scoped coding-agent endpoint."""
    return (path.startswith(CODEX_PROXY_PREFIX) and path.endswith(_CODEX_RESPONSES_SUFFIX)) or (
        path.startswith(CLAUDE_CODE_PROXY_PREFIX) and path.endswith(_CLAUDE_MESSAGES_SUFFIX)
    )


def compress_scoped_passthrough_body(
    path: str,
    body: bytes,
    *,
    optimize: bool,
    bypass: bool,
) -> bytes:
    """Compress supported Hermes request bodies, otherwise return *body* unchanged.

    The adapter deliberately understands only Hermes's two scoped routes. It
    leaves system, tool, reasoning, and non-dictionary input items untouched;
    only user/assistant messages are handed to Headroom's compressor.
    """
    if not optimize or bypass or not is_scoped_coding_agent_path(path):
        return body

    try:
        payload = json.loads(body)
        if not isinstance(payload, dict):
            return body
        model = str(payload.get("model") or "").strip()
        if not model:
            return body

        if path.startswith(CLAUDE_CODE_PROXY_PREFIX):
            field_name = "messages"
            route_name = "claude-code"
        else:
            field_name = "input"
            route_name = "codex"

        raw_items = payload.get(field_name)
        if isinstance(raw_items, str) and route_name == "codex":
            compressed = _compress_messages(
                [{"role": "user", "content": raw_items}], model=model, route_name=route_name
            )
            if compressed is None:
                return body
            payload[field_name] = compressed
            return _encode_payload(payload)

        if not isinstance(raw_items, list):
            return body

        chat_indices = [
            index
            for index, item in enumerate(raw_items)
            if _is_compressible_chat_message(item, route_name=route_name)
        ]
        if not chat_indices:
            return body

        chat_messages = [raw_items[index] for index in chat_indices]
        messages_for_compression = (
            _normalize_responses_text_parts(chat_messages)
            if route_name == "codex"
            else chat_messages
        )
        compressed = _compress_messages(
            messages_for_compression, model=model, route_name=route_name
        )
        if compressed is None:
            return body
        if route_name == "codex":
            compressed = _restore_responses_text_parts(chat_messages, compressed)
        payload[field_name] = _splice_compressed_messages(raw_items, chat_indices, compressed)
        return _encode_payload(payload)
    except Exception as exc:  # Compression must never block Hermes passthrough.
        logger.info("Hermes passthrough compression skipped: %s", exc)
        return body


def _is_compressible_chat_message(item: Any, *, route_name: str) -> bool:
    """Return whether a message has only text content safe for compression."""
    if not isinstance(item, dict) or item.get("role") not in _CHAT_ROLES:
        return False
    content = item.get("content")
    if isinstance(content, str):
        return True
    if not isinstance(content, list) or not content:
        return False
    text_part_types = (
        _RESPONSES_TEXT_PART_TYPES if route_name == "codex" else _CLAUDE_TEXT_PART_TYPES
    )
    return all(
        isinstance(part, dict)
        and part.get("type") in text_part_types
        and isinstance(part.get("text"), str)
        for part in content
    )


def _normalize_responses_text_parts(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Adapt Responses text parts to the compressor's generic ``text`` shape."""
    normalized: list[dict[str, Any]] = []
    for message in messages:
        content = message.get("content")
        if not isinstance(content, list):
            normalized.append(message)
            continue
        normalized.append(
            {
                **message,
                "content": [{**part, "type": "text"} for part in content],
            }
        )
    return normalized


def _restore_responses_text_parts(
    original_messages: list[dict[str, Any]], compressed_messages: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Restore Responses part types and metadata after generic compression.

    If the compressor unexpectedly changes the list/message/block structure,
    preserve the original message rather than risk producing an invalid
    Responses request.
    """
    if len(compressed_messages) != len(original_messages):
        return original_messages

    restored: list[dict[str, Any]] = []
    for original, compressed in zip(original_messages, compressed_messages, strict=True):
        if not isinstance(compressed, dict):
            return original_messages
        original_content = original.get("content")
        compressed_content = compressed.get("content")
        if isinstance(original_content, str):
            if not isinstance(compressed_content, str):
                return original_messages
            restored.append({**original, "content": compressed_content})
            continue
        if not isinstance(original_content, list) or not isinstance(compressed_content, list):
            return original_messages
        if len(compressed_content) != len(original_content):
            return original_messages

        restored_parts: list[dict[str, Any]] = []
        for original_part, compressed_part in zip(
            original_content, compressed_content, strict=True
        ):
            if not isinstance(compressed_part, dict) or not isinstance(
                compressed_part.get("text"), str
            ):
                return original_messages
            restored_parts.append({**original_part, "text": compressed_part["text"]})
        restored.append({**original, "content": restored_parts})
    return restored


def _compress_messages(
    messages: list[dict[str, Any]], *, model: str, route_name: str
) -> list[dict[str, Any]] | None:
    from headroom import compress as headroom_compress

    before_bytes = len(json.dumps(messages, ensure_ascii=False).encode("utf-8"))
    result = headroom_compress(messages=messages, model=model, optimize=True)
    compressed = list(result.messages)
    after_bytes = len(json.dumps(compressed, ensure_ascii=False).encode("utf-8"))
    logger.info(
        "Hermes %s passthrough compression: %d -> %d bytes (saved %d)",
        route_name,
        before_bytes,
        after_bytes,
        max(0, before_bytes - after_bytes),
    )
    return compressed


def _splice_compressed_messages(
    original_items: list[Any], chat_indices: list[int], compressed_items: list[dict[str, Any]]
) -> list[Any]:
    """Restore compressed chat messages to their original slots.

    A defensive fallback retains an original item if a compressor unexpectedly
    returns fewer messages than it received.
    """
    compressed_by_index = dict(zip(chat_indices, compressed_items, strict=False))
    return [compressed_by_index.get(index, item) for index, item in enumerate(original_items)]


def _encode_payload(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
