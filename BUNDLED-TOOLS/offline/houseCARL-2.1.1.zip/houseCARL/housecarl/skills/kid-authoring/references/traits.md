# KID Traits — section 3

The traits section (position 3) narrows distribution by **type-specific item properties** — the
enchanted flag, an armor-rating range, a weapon's animation type, a spell's school, and so on. It's
optional; leave it blank or `NONE` to skip it.

Only the **12 trait-bearing types** have traits (the ✅ rows in `types.md`). The other 7 types
(Location, Misc Item, Key, Activator, Flora, Race, Talking Activator) parse **no** traits — a traits
section on them is ignored. **[source]**

**Notations used below [source]:**
- **Single-letter booleans** (`E`, `T`, `H`, `B`, `P`, `F`, `S`, `AV`, `BLACK`, `DISPEL`) negate with a
  `-` prefix: `E` = enchanted, `-E` = not enchanted. Range/value traits do **not** negate.
- **`X(min/max)`** = a numeric range (e.g. `AR(10/50)`). One number — `X(10)` — sets only the minimum.
  The separator is any non-digit, but `/` is canonical (the Nexus examples use it).
- **`KEY(value)`** = a single enum number; the value lists live in `value-tables.md`.
- Traits are **comma-separated**; combine several to AND them (`P,F` = poison **and** food).

**Trait classes in this file:** Armor · Weapon · Ammo · Magic Effect · Potion · Ingredient · Book ·
Soul Gem · Spell / Enchantment / Scroll (shared) · Furniture · Worked examples.

**The record field column.** Each table below names the record field the trait reads, so a census can
be written without a second lookup — that is the field path to hand `housecarl_records`'s `where=`.
The field names are the schema's, read off `housecarl:mutagen-reference`; KID's own source is not
bundled here, so the column says *which field holds that property*, not that KID's C++ reads it by
that name. Where the schema holds no single field for a trait the column says so rather than guessing
a path — resolve those against the record with `housecarl:mutagen-reference` before you census them.
The spellings differ in places: KID writes `HandToHandMelee` where the schema writes `HandToHand`, so
a `where=` clause uses the schema's spelling and the INI line uses KID's.

---

## Armor (ARMO)

| Trait | Meaning | Record field |
|---|---|---|
| `E` / `-E` | enchanted / not enchanted | `ObjectEffect` set / unset |
| `T` / `-T` | templated / not templated | `TemplateArmor` set / unset |
| `AR(min/max)` | armor-rating range (float) | `ArmorRating` |
| `W(min/max)` | weight range (float) | `Weight` |
| `30`–`61` | a single number = **biped body slot** (slot N → bit `1<<(N-30)`) | `BodyTemplate.FirstPersonFlags` (a bit-flag enum, `BipedObjectFlag`) |
| `HEAVY` / `LIGHT` / `CLOTHING` | armor class | `BodyTemplate.ArmorType` — `HeavyArmor` / `LightArmor` / `Clothing` |

## Weapon (WEAP)

| Trait | Meaning | Record field |
|---|---|---|
| `E` / `-E` | enchanted / not enchanted | `ObjectEffect` set / unset |
| `T` / `-T` | templated / not templated | `Template` set / unset (not `TemplateArmor` — WEAP's is plain `Template`) |
| `W(min/max)` | weight range (float) | `BasicStats.Weight` |
| `D(min/max)` | damage range (float) | `BasicStats.Damage` |
| animation type | one of: `HandToHandMelee` `OneHandSword` `OneHandDagger` `OneHandAxe` `OneHandMace` `TwoHandSword` `TwoHandAxe` `Bow` `Staff` `Crossbow` | `Data.AnimationType` — same spellings **except** KID's `HandToHandMelee`, which the schema calls `HandToHand` |

## Ammo (AMMO)

| Trait | Meaning | Record field |
|---|---|---|
| `B` / `-B` | is a bolt / is not a bolt (i.e. arrow) | `Flags`, the `NonBolt` bit — **inverted**: `B` is `NonBolt` *clear*, `-B` is `NonBolt` *set* |
| `D(min/max)` | damage range (float) | `Damage` |

## Magic Effect (MGEF)

| Trait | Meaning | Record field |
|---|---|---|
| `H` / `-H` | hostile / not hostile | `Flags` has `Hostile` |
| `DISPEL` / `-DISPEL` | has / lacks the *Dispel With Keywords* flag | `Flags` has `DispelWithKeywords` |
| `D(value)` | delivery type — `value-tables.md` → Delivery | `TargetType` (the schema's name for delivery: `Self` / `Touch` / `Aimed` / `TargetActor` / `TargetLocation`) |
| `CT(value)` | casting type — `value-tables.md` → Casting Type | `CastType` |
| `R(value)` | resistance actor value (numeric) — `value-tables.md` → Resistances | `ResistValue` |
| `<av>(min/max)` | **school + skill range** — `<av>` is the school's actor-value number, `min/max` the skill level. `20(0/25)` = all novice (0–25) Destruction effects. Schools in `value-tables.md`. | two fields: `MagicSkill` for the school, `MinimumSkillLevel` for the range |

## Potion (ALCH)

| Trait | Meaning | Record field |
|---|---|---|
| `P` / `-P` | poison / not poison | `Flags` has `Poison` |
| `F` / `-F` | food / not food | `Flags` has `FoodItem` |

*(Potions, food, and poisons are all ALCH — these two traits separate them.)*

## Ingredient (INGR)

| Trait | Meaning | Record field |
|---|---|---|
| `F` / `-F` | food / not food | `Flags` has `FoodItem` (INGR's own flag enum, not ALCH's) |

## Book (BOOK)

| Trait | Meaning | Record field |
|---|---|---|
| `S` / `-S` | teaches a spell / doesn't | `Teaches`, a polymorphic field, sitting on its `BookSpell` arm |
| `AV` / `-AV` | teaches a skill (actor value) / doesn't | `Teaches` sitting on its `BookSkill` arm (the third arm is `BookTeachesNothing`) |
| `<av>` | a numeric actor value = the specific skill/spell-type the book is associated with (e.g. `20` = Destruction). Names→numbers in `value-tables.md`. | `Teaches.Skill` on the `BookSkill` arm — typed `Skill`, not `ActorValue`, and the two numberings differ: `Skill` runs `OneHanded` 0 … `Destruction` **14** … `Enchanting` 17, while KID's `<av>` is the ActorValue number (Destruction **20**). Census by name — `where=["Teaches.Skill = Destruction"]` — because the KID number compared as a `Skill` selects a different skill, or none, with no error |

## Soul Gem (SLGM)

| Trait | Meaning | Record field |
|---|---|---|
| `BLACK` / `-BLACK` | can / cannot hold an NPC (black) soul | `MajorFlags` has `CanHoldNpcSoul` |
| `SOUL(size)` | size of the soul **currently contained** — `value-tables.md` → Soul Sizes (1–5) | `ContainedSoul` — `None` `Petty` `Lesser` `Common` `Greater` `Grand`, with `None` at 0, so KID's 1–5 line up with the names one-for-one |
| `GEM(size)` *or bare* `<size>` | the gem's **maximum capacity** — sizes 1–5 | `MaximumCapacity`, same enum |

## Spell · Enchantment · Scroll (SPEL / ENCH / SCRL) — shared

| Trait | Meaning | Record field |
|---|---|---|
| `H` / `-H` | hostile / not hostile | **no field of its own** — hostility lives on the effects (`Effects[*].BaseEffect` → MGEF `Flags` has `Hostile`); how KID reduces several effects to one answer is not settled by this reference |
| `ST(value)` | spell type — `value-tables.md` → Spell Types (0–13) | SPEL / SCRL: `Type`; ENCH: `EnchantType`. The schema's `SpellType` enum carries fewer names than KID's 0–13 table, so census a number KID lists but the schema does not by the field it derives from instead |
| `D(value)` | delivery type — `value-tables.md` → Delivery | `TargetType` |
| `CT(value)` | casting type — `value-tables.md` → Casting Type | `CastType` |
| `<av>` | a single numeric actor value = associated skill/school (e.g. `20` = all Destruction spells). *No `(min/max)` here — that range form is Magic-Effect-only.* | **no field of its own** — the school comes from the effects (`Effects[*].BaseEffect` → MGEF `MagicSkill`) |

## Furniture (FURN)

| Trait | Meaning | Record field |
|---|---|---|
| `T(value)` | furniture type — `value-tables.md` → Furniture Types (0–3) | **not one scalar field** — FURN carries `Flags` (which has `IsPerch`) and a `Markers` list; resolve against the record before you census it |
| `BT(value)` | workbench type — `value-tables.md` → Bench Types (1–7) | `WorkbenchData.BenchType`, whose enum runs `None` 0 … `SmithingArmor` 7, so KID's 1–7 line up |
| `US(value)` | workbench use-skill — `value-tables.md` → Actor Values gives the KID number | `WorkbenchData.UsesSkill`, typed `Skill`, not `ActorValue`, and the two numberings differ the same way the BOOK `<av>` row describes. Census by name — `where=["WorkbenchData.UsesSkill = Smithing"]` — because the KID number compared as a `Skill` selects a different skill, or none, with no error |

---

## Worked examples [desc]

```ini
;all novice destruction magic effects (school 20, skill 0-25)
Keyword = NoviceDestruction|Magic Effect|NONE|20(0/25)

;poisonous foods (poison AND food)
Keyword = PoisonousFood|Potion|NONE|P,F

;non-enchanted heavy gauntlets (slot 33) — trait -E plus a slot number
Keyword = PlainGauntlets|Armor|NONE|-E,33

;all magic effects with the Absorb archetype (archetype is a STRING filter, not a trait)
Keyword = MagicAbsorb|Magic Effect|Absorb
```
