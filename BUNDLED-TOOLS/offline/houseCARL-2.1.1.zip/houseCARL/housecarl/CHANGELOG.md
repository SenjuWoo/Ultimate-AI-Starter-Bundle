﻿# Changelog

All notable changes to houseCARL are documented here. Versioning is [semantic](https://semver.org);
the `version` in `.claude-plugin/plugin.json` is bumped on each release, so installed users update only
when it changes.

**Writing an entry.** Entries go in `plugin/changelog.d/`, one file per change (its README says how), never
under `## Unreleased` here. One bold sentence saying what the tool now does or refuses, and at most one more
sentence saying how the reader can check it. Keep the whole entry under about forty words. It carries only
what a user notices and how to check it; how it works goes in the matching `docs/architecture/` note.

## Unreleased

## 2.1.1 — 2026-10-22

houseCARL 2.1.1 moves to .NET 10, because support for .NET 9 ends on 2026-11-10. Install the .NET Runtime 10.0 (x64) before updating: setup will not start without it, and its window opens and closes with nothing in it. The ASP.NET Core runtime is no longer needed. Names now read and write in your game's language, from MO2's winning string tables, whether loose or in an INI-listed or plugin-named archive, and a language Skyrim.esm has no tables in is refused; re-check non-English patches made with an earlier release. The rest are fixes found on real plugins: a partial-form override of a WRLD, DIAL, or interior or persistent CELL no longer wins over a full copy; plugin names with accented or Cyrillic letters are read from plugins.txt as MO2 writes them, so their ticks are kept; compacting keeps the plugin's master flag, author, description and header version, and counts only records whose FormID actually changes as moved; "any rank" faction ownership keeps its rank and adds no master; and records overridden last by a plugin houseCARL could not read are marked on reads and refused by apply and forward. Run side by side against 2.1.0 on a 1,410-plugin English modlist, every answer and every written plugin matched 2.1.0 except for the differences these entries explain. The entries below are in the order they landed.

- **houseCARL now runs on the .NET 10 runtime, and the ASP.NET Core runtime is no longer needed.** Install the .NET Runtime 10.0 (x64) before updating: setup will not start without it, and its window opens and closes with nothing in it.
- **Plugin names with accented or Cyrillic letters are now read from plugins.txt as MO2 writes them, so an unticked one is no longer loaded and a ticked one keeps its tick.** Check with `housecarl_load_order_status` on a profile holding such a plugin.
- **Compacting a plugin now keeps its master flag, author, description and header version, and only records whose FormID actually changes count as moved.** A re-run on an already-compacted plugin no longer refuses over its referencers, rewrites them or re-copies facegen and voice files in place (into a new file it still copies the face and voice of every NPC and dialogue line the plugin defines, since the new mod folder starts empty), and says no FormID moved instead of reporting a clean repoint. Check: compact an ESM-flagged plugin and read its header in xEdit, then compact it again and read the report.
- **"Any rank" faction ownership on container, NPC inventory and leveled-list items keeps its rank and adds no master, in patches and in plugins edited in place, and an in-place write repairs ranks an earlier version damaged.** A patch no longer gains, as a master, the plugin the rank word seemed to point into.
- **Names read and write in your game's language from MO2's winning string tables (loose, or an INI-listed or plugin-named archive); a language Skyrim.esm has no tables in is refused.** Re-check non-English patches made with an earlier release.
- **Records a plugin houseCARL could not read overrides last are now marked on reads and refused by apply and forward; errors names references into that plugin instead of calling them undefined.** Check: find a FormID it overrides in xEdit, then run an apply dry run on it.
- **A partial-form override (0x4000) of a WRLD, DIAL, or interior or persistent CELL no longer wins over a full copy; reads, scans and edits use that copy.** Check: `records` names the newest copy that is not partial as winner.

## 2.1.0 — 2026-10-18

houseCARL 2.1.0 is the engine upgrade: big reads finish in seconds, with the same answers. Run side by side against 2.0.5 on a large real modlist, 77 read calls gave identical answers apart from the walk receipt described below, the calls together took 335 s instead of 1,496 s, and the server's peak memory fell from 3.36 GB to 1.60 GB; a warm reverse walk from NordRace takes about 5 s instead of about 109 s, and a forward walk from the Player about 18 s instead of 139 s. Behind that, `->` and `*parent` scans, `formids=` reads with or without `resolve_names`, `form=everything` and `form='delta'` reads, conflicts-only scans, MGEF chains, reverse and forward walks, cell-and-reference gathers, SkyPatcher post-state reads and `skypatcher_layer` are all faster, as are the scripts and facegen checks; the dialogue check on a large follower quest no longer runs out of memory, and nested `apply`, in-place and forward writes are faster too. A plugin with one unreadable record group still answers from its other groups, and an `info_order` or MGEF seed whose plugin will not open is a row error naming it, not a failed call. A plugin saved by another program, such as xEdit, while a call runs now refuses that call, naming the plugin, and a write no longer overwrites the other program's save; rerun the call. After a plugin is copied into a higher-priority mod under the same name, an in-place edit never writes the shadowed copy (it refreshes and asks for a rerun), and a read naming that mod, or a status call, does the same; plain reads follow once one of those has refreshed. The walk receipt, `read N record bodies` in text and `rows_read` in json, now counts the record bodies actually read: a consumer reading it must expect the window's count, not the reached count, while the window note `rows a–b of N` still carries the total. The entries below are in the order they landed.

- **Whole-record reads are many times faster: `form=everything` over 300 records drops from about 16 s to 0.25 s.** Time a `form=everything` read of a few hundred records to check.
- **The dialogue check on a large follower quest no longer runs out of memory.** Seed `housecarl_check findings=["dialogue"]` with a follower quest such as Inigo's `InigofollowerDialogue`: it answers in seconds.
- **SkyPatcher post-state reads over many cells are about 4× faster (150 s to 35 s on a real install); nested apply, in-place and forward writes gain more.** On a test plugin, 2,000 placed-reference edits took 1 s, not 13 s.
- **Record reads that gather cells together with their placed references now read each shared group once, so they
  are faster and lighter.** To check, read a few hundred Skyrim.esm cells and their references with `formids=` and
  compare the time against the previous version.
- **A facegen check is faster with the same answer: a whole-order check takes about a quarter of the time or less, and a `plugins=` check drops from minutes to seconds.** Run `housecarl_check` with `findings=["facegen"], plugins=["Skyrim.esm"]` and time it.
- **The scripts check is much faster: a whole-order `findings=["scripts"]` sweep of a large modlist took about 18 s on an idle machine instead of 4–5 minutes, same findings.** Time it on your order.
- **`where=` scans that follow a `->` link or a `*parent` step are much faster: on a large modlist a FLST `Items[*any]->` scan took 3.9 s instead of 290 s, and an NPC `Template->` scan 3.4 s instead of 124 s.** Time one on your order.
- **A plugin with one unreadable record group still answers from its other groups instead of hiding all its records.** A `housecarl_records` read over such a plugin names only the broken group's records as unscannable.
- **A `formids=` read of many records, with or without a plugin `source=` or `resolve_names`, is faster: each plugin group it needs is read once per 2,000 rows.** A 200-armor `fields` read with `resolve_names` on ARR answers in about 0.12 s instead of 0.3 s.
- **`housecarl_skypatcher_layer` is much faster: on a large modlist the whole-layer call took about 9 s instead of 150 s, with the same answer.** Time it on your order.
- **Reverse and forward walks are faster on large orders.** Check: a reverse walk from a widely used record lists the same referrers, and the same dropped-candidate counts, as before.
- **Conflicts-only scans and multi-seed MGEF chains are faster: a 30,000-row `conflicts_only` spill took 4.8 s instead of 672 s.** An `info_order` or MGEF seed whose plugin will not open is now a row error naming it, not a failed call.
- **A `project.form='delta'` over many records is faster: each plugin group it needs is read once per window of rows.** On ARR, the 13,275-NPC face delta against `previous_provider` answers in about 6 s instead of 18 s.
- **A plugin saved by another program (xEdit, say) while a call runs now refuses that call, naming the plugin, and a write no longer overwrites the other program's save; rerun the call.** There is no way to check it on a live install without racing a save against a call.
- **A plugin copied into a higher-priority mod is never missed by an in-place edit (it refreshes, asks for a rerun) or a read naming that mod; plain reads follow after a write or status call.** Check: copy one up, edit in place twice; the higher copy's md5 changes.
- **A walk whose window fits reads only the rows it shows, and its receipt (`read N record bodies`) counts them.** On ARR the 50,001-record iron-cuirass reverse walk answers in 1.3 s instead of 5.3 s.

## 2.0.5 — 2026-10-14

houseCARL 2.0.5 makes the slow link scans fast and gives json one row shape. The `->` and `*parent` scans that ran for ten minutes or more on 2.0.4, and could run a server out of memory, now finish in seconds or tens of seconds: on a 3,258-plugin order, a `*parent.EditorID` filter over every placed reference went from over 15 minutes to 27 s, and `resolve_names`, cold record reads and `asset_status`'s first call over many folders are faster too. In json and `to_file` rows every `fields` entry is now one leaf, `{path, value}` or `{path, note}`, and the nested `cells` member of a json row is gone (each list element is now its own entry), so a script that reads `cells` must change; json scan notes, such as unmatched `in` names, sit in `notes`, which replaces `scan_note` and `reverse_index`. Summary rows carry each record's `Name`, which moves dense summary's later columns one place, and the default answer size is now about 40k characters. A `where=` path that names no field is refused before the scan with the field it most likely meant, instead of answering 0, as are an enum value the field lacks and a word-keyed list step. An `editorid in` or `formid in` list names the members that matched no record, a scan scoped to several plugins judges each record's highest-loading scoped copy, and flags fields take `[Body, Hands]`, `Body | Hands` or `slot32`. Every format names flag bits, known ones by name and others as `slotNN` or `bitN`, in reads, in the write tools' read-back and in `nif_inspect`, and a condition prints as one line. From field reports: `apply` `Remove` leaves out a nullable link such as an INFO's `PreviousDialog` and copies carry it as the source has it, so a patch 2.0.4 or earlier wrote with these should be re-run `into=` that patch; `check to_file=` writes a row for every finding it counts; a `[*]` path ending in one field returns it from every element; and `info_order` on a topic one plugin touches applies its PNAM links. A game setting whose EditorID another GMST shares now says so on its row. `load_order_status filter=` names the folder serving a plugin, its other copies and its header; the SKSE config audit reads bracketed plugin names and IED's form objects and cuts a large file per reference; SkyPatcher overlay reads show only the warnings that can reach the records read, and scans take the overlay pole; `bsa_list` and `bsa_extract` take `under=`; `format='dense'` works on more reads; more refusals name the call that works; and the server instructions reach a session whole. The entries below are in the order they landed.

- **`housecarl_skse findings='config'` now reads a plugin name with brackets or parentheses whole, so a reference
  into `[Caenarvon] Magecore.esp` or `Asuras Guard [Armor].esp` is checked instead of counted as a missing plugin.**
- **houseCARL's server instructions now reach a Claude Code session whole, so the enable, generated-output and
  SkyPatcher routing rules are no longer cut off.** The housecarl instructions in a new session no longer end in
  `[truncated]`.
- **`housecarl_bsa_list` and `housecarl_bsa_extract` take `under=` paths or globs, as `asset_status` does, and
  `bsa_list` takes `counts_only=`, so reading two scripts no longer unpacks the whole archive.** Try
  `bsa_extract under=["scripts/dlc2thirskdoorscript.pex"]` on `Skyrim - Misc.bsa`.
- **`housecarl_records` now names every flag bit in every format, known bits by name and others as `slotNN` or
  `bitN`; json adds a numeric `slots` array on biped fields.** Read an ARMA with slot 60 set.
- **A `where=` step into a gendered arm, list or index a record lacks (`WorldModel[1].File` on a male-only ARMA)
  now counts as unset, not a read fault.**
- **`housecarl_records types=… where=` now refuses an enum value the field does not have, with a "did you mean",
  instead of answering 0 matches.** `Archetype.ActorValue in [HeavyArmorMod]` on MGEF names `HeavyArmorModifier`.
- **`housecarl_records format='dense'` now works on a `formids=` read, an off-order `source=`, and a
  `plugins=` scope with a named `source=`, which used to refuse or answer in text; other forms refuse, naming what
  to use.**
- **`housecarl_load_order_status filter=<plugin>` now names the folder serving the plugin, every other copy with
  its size, and the header's ESL and master flags, masters and record count.** Try `filter="Requiem.esp"`.
- **A SkyPatcher overlay read now shows only the warnings whose INI line can reach the records read; the rest are one
  line pointing to `housecarl_skypatcher_layer filter=<INI>`, which lists each line's warnings under it.**
- **`housecarl_asset_status` answers a first call over many folders several times faster on a large order, for
  `under=`, `asset_paths=` and `@file` alike.** A whole mod's files as `asset_paths=@file` on a fresh server shows it.
- **`housecarl_skse findings=config filter=…` now cuts a file too big for `max_chars` per reference, non-OK first,
  instead of dropping the whole file.** The cut file ends on `showing N of M references (all K non-OK shown)`.
- **A list path keyed by a word (`Conditions[any]`) is now a wrong path, not a read fault, and a `delta` or `tree`
  path with no field on both sides shows NO FIELD instead of identical.** `where=` refuses it, naming `Conditions[*any]`.
- **`housecarl_records` json and `to_file` rows no longer carry `cells`: every `fields` entry is `{path, value}`
  or `{path, note}`, so a consumer reads `f[path] = value`.** Grouping by element: `docs/architecture/json-wire.md`,
  "One leaf shape".
- **A `housecarl_records` scan scoped to several plugins now shows each record's highest-loading scoped copy, not
  whichever plugin was named first, and `where=` judges that copy.** Rows come back in load order whatever the
  order of `plugins.names`, which changes `limit=`/`offset=` pages.
- **`has`, `has_any`, `has_none` and `=` on a flags field now take `[Body, Hands]`, `Body | Hands` and `slot32`
  as well as `Body, Hands`, and on a list such as `Keywords` the has-family refuses with the form to use.**
- **`housecarl_records` now prints a condition as one line, `[HasPerk(058200:Skyrim.esm) == 1 on Subject OR]`; one
  more depth level shows every sub-field.** Read a PERK's `Conditions` at `depth=2`.
- **`housecarl_nif_inspect` now names an unnamed shader flag bit with the `bitN` token `housecarl_records` uses,
  instead of `(+unknown bits 0x…)`.**
- **The default answer size is now about 40k characters (was 80k), so a large read spills to a results file or cuts with a notice before a client can reject it.** Raise `max_chars` for more inline.
- **A `housecarl_records` scan with `where=["editorid in [...]"]` or `formid in [...]` now names the list members that matched no record in the selection.** Check: list a GMST name no plugin defines; the note and json `unmatched` name it.
- **`housecarl_apply`, `housecarl_create` and `housecarl_forward` now decode a flags value in their read-back, and apply and create on each edit line (json: `display` on the op row), as `housecarl_records` does: named bits, `slotNN`/`bitN`, slot numbers.**
- **`housecarl_skse findings=config` now reads the `{"id": …, "plugin": "…"}` forms in JSON configs such as IED's,
  each at its JSON path, instead of calling those files clean; PlayerRef reads OK, not DANGLING.** Check with
  `findings=config filter=IED`.
- **`housecarl_records` summary rows now carry each record's `Name`, the pole's copy under `source=`, and `form='identity'` is a spelling of `summary`.** Dense summary gains a `name` column after `editorid` (later columns move one place), and summary artifacts list `name` in `row_schema`.
- **`housecarl_records` scans now take the SkyPatcher overlay pole, replaying the `limit=` window, and a `plugins=` scope with a named `source=` now answers summary, aggregate and `counts_only`.** Check: `types=["ARMO"]` with `source={"overlay": "skypatcher", "state": "post"}`.
- **`housecarl_records` refusals for `fields_source=` a plugin, `walk=` with `where=`, and `project.fields` on the chain form now name the call that works.** Check: `fields_source="Skyrim.esm"` on a scoped scan answers with `source="Skyrim.esm"`.
- **A nullable link, such as an INFO's `PreviousDialog`, is now left out by `apply` `Remove`, and copied as the source has it by `CopyFrom`, `bundle=` and `copy target=`; re-run a patch 2.0.4 or earlier wrote with these, `into=` that patch.** The echo reads `(null link)`.
- **`housecarl_check to_file=` now writes a row for every finding it counts — dialogue quest-level, `.seq`, silent-line and result-script findings included — and its manifest shows `complete:false` when `limit=` cut rows or seeds.**
- **`info_order` on a topic one plugin touches now shows the order with its PNAM links applied, marks lines that changed order, and says the in-game order is untested.** Check: read such a topic whose PNAM skips a line.
- **A quantified path ending in one field, such as `Responses[*].FormKey`, now returns that field from every element instead of stopping at the 2000-line cut.** Check: HirelingIdles (`055DEB:Skyrim.esm`, source Skyrim.esm) lists all 247.
- **A `*parent` filter, aggregate or projection now gathers the containing cells and topics in one walk per plugin instead of one seek each: on a 3,258-plugin order, `*parent.EditorID = BleakFallsBarrow01` over every placed reference went from over 15 minutes to 27 s.**
- **A game setting whose EditorID another GMST in the order shares now says so on its row, naming the other FormIDs and the copy the game uses.** Read `iAllyHitNonCombatAllowed` at `F129D5:Skyrim.esm` on ARR: the note names `3D2E8D:Requiem.esp`.
- **`->` link scans, `resolve_names` and cold record reads are much faster on large load orders.** To check: `resolve_names` over an armor's 25 armatures now answers in about 0.1 s, down from 43 s.
- **A `housecarl_records` scan read as `everything`, a comparison or `info_order`, or saved with `to_file=`, now gives every scan note, such as unmatched `in` names; on json they sit in `notes`, which replaces `scan_note` and `reverse_index` there.** Check: `form=everything where=["editorid in [A,Typo]"]` names `Typo`.
- **A `where=` path that names no field is refused before the scan, on every form, with the field it most likely meant, instead of answering a bare 0.** To check: FLST `where=["Items[*any]->type = Armor"]` with `form=fields` refuses, naming `Type`.

## 2.0.4 — 2026-10-05

houseCARL 2.0.4 refuses inputs it used to drop silently and keeps more answers inside their cap. `housecarl_apply` and `housecarl_create` refuse stray arguments, five tools refuse `patch=` beside `into=`, and apply's default patch name steps past a disabled `Patch.esp` as the others do. An in-place apply, create, remove or forward now refuses a pre-1.71 plugin with its own records below 0x800, as 2.0 promised, and an in-place or `into=` write refuses when the parser would drop or resize a subrecord. `housecarl_skypatcher_layer` and `info_order` cut to fit `max_chars` and mark the cut, and the layer says when a cap is too small for its header. The facegen and scripts checks name what they could not read, and never-baked presets get their own class. The errors and dialogue checks and SkyPatcher-layer reads no longer mix two profiles when MO2 switches mid-call. A walk takes `walk.through` to find the NPCs that carry an item, SkyPatcher keys match without regard to case, plugin lists take `@file`, delta and tree reads skip walks they cannot use and refuse only past ten minutes, a text answer names plugins lost to a load failure, and a malformed NIF is named. The tool descriptions now say each thing once, so the tool list is about a quarter smaller. The entries below are in the order they landed.

- **`housecarl_skypatcher_layer` now stays inside the `max_chars` it is given, or says it ran over when
  that cap cannot hold its header and warnings.** Pass `max_chars=8000` on a large layer: the answer is 8,000 characters or fewer.
- **`housecarl_records project=info_order` now lists as many lines of a topic as fit in `max_chars` and marks the cut,
  instead of dropping a topic too big for the cap.** A topic of 60 lines at `max_chars=3000` lists its first lines.
- **`housecarl_nif_inspect` and `housecarl_nif_set` answer a malformed mesh with a named error, naming where it
  breaks (the block or header field) and the bad count, instead of running the server out of memory.** Inspect a mesh with a corrupted count and read the error.
- **`housecarl_check findings=["facegen"]` now names a mod folder it could not list, and counts the pairs it left
  untested there apart from those whose mod ships no plugin.**
- **`housecarl_check` now names the archives that failed to open and the asset build's warnings when the facegen or
  scripts family runs.** In json, these and `root_read_failures` are `null` when no family that reads assets ran.
- **`housecarl_check findings=["facegen"]` puts the Player and CharGen presets that have no bake in a new
  `never_baked` class instead of `bake_absent`, counted and listed only by name, and marks a `bake_absent` row with no
  head parts or face data as a likely voice or dummy actor.** List them with `findings=["never_baked"]`.
- **`housecarl_check`'s errors and dialogue families now read the MO2 profile, its folders and, for dialogue, its
  mod files together with the load order they check, so switching profiles in MO2 mid-check can no longer mix two
  profiles.**
- **A `housecarl_records` call with a SkyPatcher overlay source or pole now replays the INI layer over the same asset
  build its winners came from, so a profile switch mid-call can no longer mix two profiles.**
- **`housecarl_skypatcher_layer` keeps a share of `max_chars` for its replay and scan notes, and says
  `showing N of M note(s)` when it cuts them instead of dropping them silently.**
- **`housecarl_records`' `plugins.names` and `housecarl_check`'s `plugins=` and `exclude=` now take `@file`, one plugin
  filename per line.** Pass `plugins={"names": ["@C:/work/plugins.txt"]}`: the scan covers exactly those plugins.
- **An in-place or `into=` write now refuses before touching the file when houseCARL's parser would drop a subrecord
  or change its length, naming the record and the subrecords.** An `in_place=` apply to a plugin with the #961 ARMA
  order is refused.
- **`housecarl_records` delta and tree now skip reference walks a row can never reach, and explain an absent plugin
  once per call instead of once per row.** A narrowed tree over an absent plugin's ids returns at once.
- **`housecarl_records` delta and tree now time their reads as they go and refuse only once the call would pass ten
  minutes, naming the measured rate.** A whole-record delta over 1,276 ids runs.
- **A text response on an order that lost plugins to a load failure now names them beside the epoch, up to three
  then `+N more`, and points at `housecarl_load_order_status` for the reason unless the response prints it.**
- **The SkyPatcher overlay now matches key names without regard to case, as SkyPatcher does, and reads a `#` line, which
  can never be a key, as a comment.** A `filterByNPCs=...:race=...` line now changes the post-state Race.
- **A walk now takes `walk.through` and a reverse walk takes `walk.exclusions`, so one call finds the NPCs that carry an
  item through leveled lists and outfits.** Other types are left out and counted per type; NPC template inheritance is
  not followed.
- **`housecarl_apply` and `housecarl_create` now refuse `value=`, `values=` or `entries=` beside `compose=` or `composes=`,
  instead of dropping them unwritten.** A dry run with both now refuses rather than showing the dropped value.
- **`housecarl_apply` with `patch=` omitted now writes `Patch_001` when a disabled mod holds `Patch.esp`, as create,
  forward and copy do, instead of refusing.** Passing `patch="Patch"` is still refused.
- **`housecarl_apply` and `housecarl_create` now refuse `key=` on an op that does not read it, such as a list Add, instead
  of appending at the end.** A list Add with `key=` now refuses and points at InsertAtIndex.
- **`housecarl_compile_script`, `housecarl_decompile_script`, `housecarl_copy`, `housecarl_nif_set` and
  `housecarl_place` now refuse `patch=` beside `into=` instead of dropping `patch=`.** A blank `patch=` or `into=` on copy now
  names the patch after `new_editorid=`, not 'Patch'.
- **An in-place apply, create, remove or forward now refuses, before writing, a plugin with a header version below 1.71
  that defines records of its own below 0x800, as 2.0 promised.** A 1.71 plugin, which may use that range, is not refused.

## 2.0.3 — 2026-09-23

houseCARL 2.0.3 widens what several tools take and makes more answers say so when they cannot finish. `housecarl_decompile_script` writes into any absolute folder with `out_path=`, rebuilds more functions correctly, and fails a function loudly or refuses a file rather than writing wrong source. `housecarl_asset_status` takes `formids=`, `to_file=` and `@file` lists, answers a sweep as a census with `counts_only=`, writes an over-long answer to an artifact instead of cutting it, and no longer slows with each folder asked about. The dialogue check and `info_order` take an unenabled patch on `source=`, and the Nexus tools take `game=`. The asset, SKSE, SkyPatcher, NIF, place, compact and create answers and the facegen, scripts and dialogue checks now name a mod folder they could not read. A json answer over `max_chars` now says so with `max_chars_overrun`, and `housecarl_skse` and `housecarl_skypatcher_layer` keep their json and warning lists inside it. An aggregate honours `limit=` and a count table refuses `offset=`, a path that is not absolute is refused by name, and a call during an MO2 re-sort asks for a retry. A PERK effect Mutagen refuses no longer hides the whole perk, the index hands spare memory back once built, and the main tools carry plain titles. The entries below are in the order they landed.

- **`housecarl_decompile_script` takes `out_path=`, an absolute folder it writes the `.psc` into with no MO2
  instance needed; an incomplete class hierarchy is now named.** Decompile into a scratch folder: the `.psc`
  lands there and no mod folder is created.
- **`housecarl_decompile_script` reconstructs a function that uses the value of a call returning `None`.**
  Decompile a script that assigns or returns a void call and read the line.
- **A PERK entry-point effect Mutagen refuses reads as one marked row instead of taking the whole record, so
  `references=` scans no longer skip that perk.** Check with `project.form="fields"`, `fields=["Effects"]`,
  `depth=3` on the perk.
- **`housecarl_asset_status` takes `formids=`, `to_file=`, and `@file` lists; each NPC resolves as two FaceGen
  rows, split when their winners sit in different mods.** Run `formids=` over your NPCs with `to_file=` and read
  the artifact's `pair_differs` and `pair_exists` columns.
- **`project.form="info_order"` folds one off-order plugin named on `source=` into the merge, so a dialogue
  patch's merged order reads before MO2 enables it.** Read a topic your patch re-lists with and without
  `source=`.
- **`check(findings=["dialogue"])` takes an off-order plugin on `source=`, folded in where MO2 would load it, so
  a dialogue patch validates before it is enabled.** Run the family over a seed in your unenabled patch with and
  without `source=`.
- **`housecarl_decompile_script` refuses a `.pex` whose script object is not named like a plain script, instead of
  writing the `.psc` outside the folder you asked for.** Decompile such a file and read the refusal.
- **`housecarl_asset_status` no longer truncates over `max_chars`: the resolved result is written to an artifact
  and the response names the file.** Run a sweep at a small `max_chars` and open the file the `spilled` line
  names.
- **`housecarl_asset_status` takes `counts_only=`, which answers a sweep as a census: which layers win how many
  paths, the loose-versus-BSA split, and how many are absent.** Run a FaceGen sweep with `counts_only=true` and
  read the layer table.
- **Every path you name — `out_path=`, `to_file=`, an `@file` list, a `where=` list file, a SkyPatcher draft INI —
  has to be absolute, and one that is not is refused by name.** Pass one with no drive letter and read the refusal.
- **A call that lands while MO2 holds the profile open says so and asks for a retry instead of failing, and an
  asset answer off the older build says which.** Run `housecarl_asset_status` during an MO2 re-sort.
- **The load order's index hands its spare memory back once it is built.** Watch the houseCARL process's memory
  after your first call on a large order.
- **`housecarl_decompile_script` fails a function loudly instead of emitting two calls in an order the script never
  ran them in.** Read the failure comment in the `.psc` for the function it names.
- **`housecarl_decompile_script` puts a `= None` default back on a function whose own script calls it without that
  argument, so the source it writes still compiles.** Decompile a script with such a call and read the signature.
- **`housecarl_decompile_script` brings back an expression whose result the script throws away, instead of failing
  the function it sits in.** Decompile vanilla `WEBountyCollectorScript` and read `OnStoryScript`.
- **`housecarl_asset_status` names a mod folder it could not read instead of quietly leaving it out of the
  answer.** Ask about a path or a folder a mod blocks: the answer names that mod above the rows.
- **`housecarl_records`, `housecarl_apply`, `housecarl_create` and `housecarl_remove` are titled for what they
  do, with no internal spec naming.** Call `housecarl_records` and read the "Used …" line: it now says
  "Read records".
- **`housecarl_nexus_search`, `housecarl_nexus_mod` and `housecarl_nexus_check_updates` take `game=`, a Nexus
  domain name or game id, and default to Skyrim SE; a mod URL for any game now works as pasted.** Look up
  `https://www.nexusmods.com/baldursgate3/mods/3479`.
- **`housecarl_skse`, `housecarl_skypatcher_layer` and `housecarl_nif_inspect` name the mod folder they could not
  read, instead of only warning that one failed.** Run any of them with a mod folder blocked: the answer names that
  mod.
- **`housecarl_decompile_script` now names a `.pex` beside the input it could not read, so every thin part of the
  class hierarchy is stated.** Decompile a script whose folder holds a corrupt `.pex` and read the note.
- **A count table caps with `limit=` and never pages: `project.form="aggregate"` now honours `limit=`, and every lane
  refuses `offset=` against a table in one sentence.** Run an aggregate with `limit=1` and read the row it kept.
- **A `format="json"` response over `max_chars` now closes with `max_chars_overrun`, naming its own length and the
  cap that fits it; `housecarl_check`'s text notice is reworded to match.** Run any json call at `max_chars=100`.
- **Asset calls no longer get slower with each folder asked about.** Ask about twenty distinct asset paths in one
  session: the twentieth answers about as fast as the second.
- **A `housecarl_skse` `format="json"` answer now comes back inside the `max_chars` it was given, instead of about one
  row over it.** Run any family at `max_chars=8000` and check the length.
- **The facegen and scripts sweeps, a created line's voice and result-script notes, and a compact's asset carry
  name the mod folder they could not read.** Block a mod folder, then run `housecarl_check` and
  `housecarl_compact_plugin`: each answer names that mod.
- **The dialogue check, and a `housecarl_place` or `housecarl_nif_set` that finds no copy, name the mod folder they
  could not read.** Block a mod folder, then place a path nothing provides: the answer names that mod.
- **`housecarl_skse` and `housecarl_skypatcher_layer` now cut a long list of warnings or unreadable archives inside
  `max_chars` and count the rest, instead of letting it push the answer out.** Read the `showing N of M` line.

## 2.0.2 — 2026-09-15

houseCARL 2.0.2 fixes three answers 2.0.1 got wrong and closes two costs measured after it shipped. `housecarl_create` now reports every field from the file it wrote, superseding 2.0.1's interim entry; the entry says which claim it withdraws. An auto-spill no longer fails when another process holds the file it is about to write; the entry says what changed and what a `to_file=` write keeps. `format="json"` carries non-ASCII text as itself and `max_chars` counts characters on every json render; the entry names the one range that still escapes. A `tree` or `delta` reads its bodies a plugin at a time, and a bulk `create` under many parents reads per plugin rather than per parent; each entry carries its bound and its measurements. The entries below are in the order they landed.

- **A bulk `housecarl_create` under many different parents no longer re-reads a whole plugin per parent.** Each
  parented record read its parent's body by enumerating the parent's defining plugin from the top, so 200 records
  under 200 distinct `Skyrim.esm` topics walked that file 200 times: on a 3,254-plugin order the call took 398 s and
  peaked at 2.7 GB. The parent bodies are now read a plugin at a time, one walk each — the same call takes 6 s and
  peaks at 0.9 GB — and the written patch is byte-identical on the same inputs. What the gather covers is the parent
  read the refusal-free path makes: a parent the order does not hold is still refused without reading a body, and the
  one remaining per-parent read — a child going into a parent's single-child slot, where the artifact already carries
  that parent — is named at the declaration in `WritePatchBuilder`.
- **`project.form="tree"` and `project.form="delta"` read their bodies a plugin at a time.** Both lanes fetched each
  provider — a tree's whole touching stack, a delta's two poles, and a tree's `versus=` pole — with a walk of that
  plugin from the top for one record, so rows whose providers are the same few large masters paid one whole-plugin
  walk each. The bodies of a chunk of rows are now gathered per plugin, one walk answering that plugin's whole share
  of the chunk — the rows it wins and the rows it merely overrides together, which on a real order is usually the
  same plugin in both roles. The answer is unchanged: the same rows, the same nodes in the same order, the same
  deltas, and `limit=`'s bound on what a tree reads is unchanged (see `limit=`). What a chunk holds is the new bound,
  and it is what the chunk size is there to set: a tree holds one plugin's record bodies at a time — the 2.0.1 tree
  entry below says what that was about and it is unmoved — plus one reference field set per row of the chunk, and a
  delta holds its chunk's rows' subject and reference bodies rather than the one pair a row needed. Measured over 100
  contested records on a 3,254-plugin order, driven per arm as a private server: tree 33.4 s to 8.6 s, delta 31.4 s
  to 8.1 s and tree against a named `versus=` plugin 36.4 s to 11.3 s over placed references; tree 8.9 s to 6.3 s
  and delta 11.1 s to 6.3 s over weapons. Peak working set is unchanged on every arm.
- **`format="json"` carries non-ASCII text as itself, and `max_chars` counts characters on every json render.** A
  Japanese or accented name — the `FULL` of a translated record, a plugin whose filename has an accent — was written
  as a run of `\uXXXX` escapes; it now rides as the characters it is (`"` `'` `<` `>` `&` `+` are still escaped, as
  json and HTML safety require). Every json the server writes goes through the one encoder, the rows of a `to_file=`
  artifact included, so a name is spelled the same way inline and in the file. This supersedes the `\uXXXX` clause that closes the 2.0.1 UTF-8 entry below, which
  described what the tool did when that entry shipped. The bound is the Basic Multilingual Plane, U+0000 to U+FFFF:
  a character above it — an emoji, a CJK Extension-B ideograph — is still written as its `\uXXXX\uXXXX` surrogate
  pair, because no encoder widens past the plane without also unescaping the characters named above; check with a
  `format="json"` read of the record and compare the value you get back, which parses to the same string either way.
  Those escapes were also what kept a json document's UTF-8 byte count equal to its
  character count, and the caps were measured in bytes while `max_chars` and every notice that states a length are
  stated in characters. Every json cap test, reserve and stated length now counts characters, in one place
  (`JsonWire.Chars`), so a response with non-ASCII in it states its own length and is cut at the cap it was given
  rather than sooner. A document that reported itself longer than it was is the case this closes; the overrun notice
  is the one place a response may still exceed `max_chars`, and it says so.
- **An auto-spill no longer fails when something else is holding the file it is about to write.** A truncated
  response spills its complete result to a file in the results directory, and the server reserved that file's name by
  creating it empty and then writing the artifact over it with a replace-move. On Windows that move fails with
  "Access to the path is denied" whenever anything holds a handle on the destination without share-delete — which is
  exactly how a scanner or indexer opens a file it just saw appear — and the response then said the complete result
  existed nowhere, discarding an artifact that was correct and whole. The reservation is now the file itself: the
  handle that claims the name is the handle the artifact is written through, so nothing can take or hold it in
  between. A scanner grabbing every file the results directory gains failed the spill 10 times out of 10 before and
  0 times out of 10 after. Unchanged: the file's name, its contents, and every sentence the response says about it.

- **`housecarl_create` now reports every field from the file it wrote, not from memory.** This supersedes
  the 2.0.1 entry saying a create's reported values were not re-read: they are now. The create lane runs the
  same post-write file check `housecarl_apply` runs, on both lanes (a new patch, `into=`, and `in_place=`),
  and each per-field line prints what the re-opened file holds at that leaf. A created record the written file
  does not contain says `DID NOT LAND`, counted and named above the record rows and outside their budget so a
  `max_chars` cut cannot leave a response claiming every record was created; a nested child whose dragged-in
  PARENT is missing from the file says the same thing and names the parent, because a child cannot be in a
  parent the file does not hold. Both say what a create must do about it, which is the opposite of what an
  edit does: read the artifact back, and re-create only if that agrees the record is absent. A leaf the file
  answered with but did not PARSE keeps its caveat too: an opaque `bytes` field such as `Model.Data` prints
  its value with `structure NOT checked` beside it. The Creation Kit parity fills (the SNAM marker, DIAL
  Priority, INFO/DLVW/DLBR/QUST defaults) are explanations of what the write did rather than field readings,
  and still print as they did. In
  `format: "json"` each op gains `after_on_disk`, `landed_on_disk` and `landed_source`, each created record
  gains `verified`, `absent_from_file`, `parent_formid` and `parent_absent_from_file`, and `verify_ran`,
  `records_absent`, `record_absent_formids` and `parent_absent_formids` sit outside the `created` array.
  `readback=true` keeps its full dump. The check is one walk of the written file however many records the
  call made, not one per record (in place it is the second walk of the two the forced read-back already
  made it): 200 nested creates
  under 200 distinct `Skyrim.esm` topics on a 3,252-plugin order measured 3.52 s before and 3.56 s after (best
  of three each), and the written patch is byte-identical on the same inputs.

## 2.0.1 — 2026-09-15

houseCARL 2.0.1 carries what the first days of 2.0.0 on real load orders turned up. Among the wrong answers fixed: a UTF-8 name reads as itself and is never written as `?`, a chain walk reports the cycles it found, and a write's verify names the bytes it did not judge. Read and write paths that paid per record now pay per plugin — bulk `apply` and `forward`, the reverse lane, `tree` fill, `[*count]` — and a forward walk, a `*parent` predicate and a `tree` no longer hold what they reached. New refusals, each one sentence naming the fix: `from_source` outside `CopyFrom`, a raw path into the mods folder, `walk.max_nodes` above its bound, a `delta` or `tree` past its record cap, an in-place value the file's encoding cannot spell, and a merge donor whose master is not active. Every write says when it forks a record another plugin overrides, and a merge says where its output has to load. The entries below are in the order they landed.

- **A translated name carrying UTF-8 now reads as itself, and a write no longer turns it into `?`.** Mutagen picks
  a plugin's text encoding from the target language, and Skyrim SE + English is the one pairing whose answer is
  Windows-1252 with no UTF-8 lane — which is the setup the Japanese community ships: `sLanguage=ENGLISH` with the
  `*_English.STRINGS` tables replaced by UTF-8 translations, and UTF-8 in the inline `FULL` fields of non-localized
  ESPs. Every such name came back as mojibake, and because the Windows-1252 encoder has no spelling for a character
  outside 1252, an in-place edit or a copy of that record wrote `?` over the text. A read now decodes each string as
  UTF-8 when it is valid UTF-8 and as what Mutagen would have chosen for the language otherwise, so a Windows-1252
  name still reads exactly as it did — and it records, per plugin, which of the two its own bytes turned out to be.
  A write then uses ONE encoding for the whole file: an in-place edit re-encodes in the lane that plugin's read
  resolved to, and a new file (a patch, a merge, a compacted copy) uses UTF-8 if any plugin that contributed a record
  to it resolved as UTF-8. So a Japanese plugin comes back UTF-8, a Windows-1252 one comes back Windows-1252, both
  byte-identical wherever the write did not change the text, and a plugin carrying Japanese and accented Latin
  together is never written half in one encoding and half in the other. A value the chosen encoding has no spelling
  for is never stored as `?`: the write goes through a strict encoder, so a new file that turns out to need UTF-8 —
  a Japanese name typed into a patch built from plugins that were all ASCII — is simply written as UTF-8 instead,
  and an in-place edit, which cannot change encoding without converting every other name in the file, refuses in one
  sentence naming the value, the character it cannot spell and where to put it instead, leaving the file untouched.
  Extending a plugin flagged LOCALIZED with `into=` is refused the same way an in-place edit of one already was: its
  text lives in separate `.STRINGS` files that houseCARL cannot write as one set with the plugin, and the refusal
  says to write the edits into a fresh patch instead. One case none of this reaches, and it is not guarded: a
  Windows-1252 string whose bytes also happen to be valid UTF-8 is read as UTF-8. Nothing else moves: which language
  is selected, and which
  language's table is read, are unchanged. In `format="json"` the characters ride as `\uXXXX` escapes, json's own
  spelling for non-ASCII, and parse back to the same string.

- **A `[*count]` column costs the number, not the list.** `project.fields=["Temporary[*count]"]` read the list the
  way naming it does: building every element to count them, and — on a field that holds CHILD RECORDS — assembling
  the additive union, which opens a body per plugin touching the record. The element count now comes off the
  collection's own count with no element built, the column reads at depth 1 whatever depth was asked for, and a
  field read only for a count takes the child union's index-only tier: the number carries the sentence saying other
  plugins declare children here that were not read, and the response states that tier's clause. Name the list
  without the token for the assembled union. The number rendered is unchanged, and it is the same number
  `where=["Temporary[*count] > 200"]` compares — that predicate no longer builds the elements either. Measured over
  60 contested placed-reference-dense CELL records on a 3,245-plugin order: 2.1 s / 1,185 MB peak working set
  before, 0.3 s / no rise above the idle set after.
- **`housecarl_records` `project.form="chain"` now reports the cycles a forward walk actually found.** A cycle was
  only ever recorded when `walk.follow` named a single chain; a closure walk deduped its revisits on its visited set
  and reported none, so a leveled item pointing at itself, and a pair pointing at each other, both came back
  `cycles: 0`. The walk now records the edges it crossed and finds the cycles from them once it is done, which is
  also what tells a real loop apart from two paths meeting on one record. Each one is listed under its seed as the
  loop itself (`A -> B -> A`), and the response carries a `cycles` count beside `seeds` and `reached`. What a cycle
  means, and every bound on the count — which nodes it is found over, that it counts closing links rather than
  distinct loops, and that the search stops at 200 loops per seed — are in the `project.form` description. A count of
  zero means acyclic only over a walk that finished: a response whose walk was cut at `walk.depth` or
  `walk.max_nodes` says so beside the count, including on `counts_only`, because zero is the answer that reads as
  proof. Both renders hold the cycle list to `max_chars` and say how many they held back.
- **`housecarl_place` and `housecarl_nif_set` no longer tell you to sort a new mod above a winner it already
  out-ranks.** Both pick their closing instruction on the LANE now, not only on whether something else provides
  the path. A placement into a folder houseCARL creates (the default lane) says to enable it and stops: MO2
  registers a folder it has not seen at the highest priority, so the placed copy out-ranks the current winner
  the moment it is ticked. A placement into an existing folder (`into=`) still says to sort it above the current
  winner, because that folder's priority is already fixed. Both keep the note that a mod you add later can
  out-rank this one. Three winners are answered apart, because neither instruction fits them: a path won by
  MO2's overwrite folder, which sits above every mod in the VFS (move or delete that copy); a path won by a BSA
  or the game's Data folder, which any enabled mod's loose copy beats at any priority, so no sort is asked for
  on either lane; and a path the destination folder itself already provides, where the placement replaces its
  own earlier copy and keeps winning, so there is nothing to enable or sort.
  The same laning reaches the "enable + sort it in MO2" line the write tools print after creating a patch,
  which now says "enable it in MO2" and names the reason: a record's precedence is the plugin load order, and
  MO2 adds a newly activated plugin at the end of it. An `into=` or in-place patch already has a place in that
  order, so its lines are unchanged.

- **A bulk `housecarl_apply` or `housecarl_forward` no longer costs megabytes of memory per operation.** Each op
  fetched its record by enumerating that record's plugin from the top, so a call paid (records in that plugin) per
  op, and the memory it churned stayed in the process after the call returned: on a 3,254-plugin order a 2,484-op
  apply peaked at 3.3 GB, took 73 s, and left the server sitting at 3.3 GB. The bodies are now gathered a plugin at
  a time, one walk each: the same apply takes 3.2 s, peaks at 0.9 GB and leaves the server back at its idle size.
  The written patch is unchanged — byte-identical on the same inputs.

- **A write's per-edit line now reports what the written file holds, not what the call held in memory.**
  `housecarl_apply` re-opened the patch it had just written only to read its master header, so each edit's
  `-> value` came from the record in memory. A record can exist in memory and serialize to nothing, and when it
  did the response reported the edit as applied — an Add on a leveled list answering `-> [list: 11 item(s)]`
  over a file still holding 10 — while `full_readback: true`, which did read the file, contradicted it in the
  same response. Every edit line is now re-read off the written file, for every verb, out of the re-open the
  lane was already doing. `in_place=` writes get the same change: only their read-back clause came from the
  file before, while their edit lines came from memory like the patch lane's. Where an edit targeted a record
  the re-opened file does not contain, the line says so outright — that is the reading that means the edit is
  not in the file — and the count is repeated above the edit list, where a `max_chars` cut cannot drop it.
  Where the file cannot judge a value at all the line says `not-checked` and prints no value instead of the
  in-memory one; a leaf the file could not read is the case that reaches it. Many ops into one field still
  print the file's reading on every line, the field as the file now holds it, marked on the lines a later op in
  the same call wrote too — marked as the field's final state, since it is not that op's own result. In
  `format: "json"` the file's reading is `after_on_disk` (with `after_on_disk_is_final_leaf` on the ops that
  marking applies to) and `landed_source` names where each clause came from, with `record_absent` for the
  record the file does not hold; `after` stays the in-memory reading, so the two are never confused for one
  another. The absent count and the records it names sit outside the row budget on both transports —
  `ops_record_absent` and `record_absent_formids` in json — so a `max_chars` cut cannot leave a response
  claiming every edit applied. A 500-op apply pays one more reflective read per op: measured 175 ms before
  against 226 ms after, best of five runs each, on a synthetic 500-record order.

- **`housecarl_create` says that its reported values were not re-read from the written file.** Unlike an edit's,
  a create's per-field lines are the applied edit's own reading taken before the file was written, and after the
  change above the two lanes' lines look identical. The create response now says which it is, and points at
  `readback=true` to read every created record back off the file. Making that lane report from the file, as the
  edit lanes now do, is #763.

- **Three published shapes now say what the server actually does.** `housecarl_copy`'s `seed_paths` told you to
  reach for `op=Merge` / `op=ReplaceAll` on `housecarl_apply`'s `bundle=`/`assignments=` zip; that zip has no `op=`
  at all — it transplants each named field whole onto the target, one `CopyFrom` per named field per target,
  replacing what the target had. Both the parameter text and the refusal that routes you there now say that. A
  compose's nested `sets[].verb` named five verbs while the gate took all eight; five is right, and the other three
  are now refused there by name instead of consuming nothing. A nested set is `{path, verb, value, key, compose}`,
  so it has no member to carry `ReplaceAll`'s `values=`, `Merge`'s `entries=`, or `CopyFrom`'s source record:
  `ReplaceAll` replaced a collection with the empty list and `Merge` merged nothing, both reported as a write that
  landed, and `CopyFrom` reached apply as a verb the leaf does not take. The five are published as an `enum` a
  client can check against. Set a collection's elements or a dict's entries one at a time; copy a field from
  another record with `housecarl_apply`'s `CopyFrom` op. A nested member the
  server refuses the call without no longer publishes a type accepting `null`, so a schema-validating client can
  no longer be told an explicit null satisfies it — and, the other way, a verb slot the server DEFAULTS still
  publishes one, so such a client does not refuse a null verb the server reads as `Set`.

- **An MO2 instance whose profile name or game path is non-ASCII now resolves.** MO2 stores those values as Qt
  byte arrays, and Qt writes every non-ASCII byte as a `\xHH` escape, so a profile named 大肥鱼整合 was read as the
  literal escape text and every tool refused with "the active profile's folder is missing". Both INI readers —
  `ModOrganizer.ini` and a mod's `meta.ini` — now read a value the way Qt wrote it: the quote pair Qt puts around
  the whole value, wrapper included, when it holds `;` `,` `=` or an edge space (so a profile named `Requiem, AE`
  also resolves now), then the `@ByteArray(...)` wrapper, then the escapes — `\xHH` runs (UTF-8 bytes, or a UTF-16
  code unit for a value above 0xFF) and the named ones. Qt doubles every backslash, so a value carrying a lone one
  was not written by Qt and is left exactly as it stands rather than half-decoded. If a tool still reports the
  folder missing, the name it prints is now the decoded one — compare it with the folder under `profiles\`.

- **`houseCARL-Setup.exe` ships framework-dependent, like the server.** The self-contained apphost aborted
  during CLR startup on some machines — a CET / hardware-shadow-stack interaction, asserting before any app
  code ran, so the window opened and closed and nothing was written. The exe now uses the same installed
  .NET 9 the server already requires: it is single-file still, 0.22 MB instead of 10.7 MB, and untrimmed
  (trimming is a self-contained-only option). Setup now needs that runtime to start at all, and a console
  app's missing-framework message goes to stderr, which a double-clicked window closes over: the
  requirements block in the README and in `START-HERE.txt` therefore names the flash-and-close itself as
  the diagnosis, and says to take the x64 runtime builds, which is what a `win-x64` apphost needs. Setup's
  preflight still names a missing ASP.NET Core Runtime, the half the base runtime's installer does not
  carry, and it no longer calls the base runtime missing while running on it — a runtime reached through
  `DOTNET_ROOT` with `dotnet` off PATH is now found, because the shared-framework root the setup process
  is itself running out of is scanned alongside the machine-wide one. That root is also the only one known
  to be the server's architecture, so where the process and the OS disagree on architecture — an x64 setup
  on Windows-on-ARM — it is the only one that counts, and an arm64 ASP.NET Core Runtime no longer passes
  the check for an x64 server that cannot use it. When that root is what answered and it is not the
  machine-wide install, the detection block says so: a framework only setup's own runtime can see is one
  the host may not see, because a host launched from Explorer inherits no `DOTNET_ROOT` from setup's shell.
- **The README says how to install by hand, and which file each Claude surface reads.** Move the whole
  `housecarl` folder to `~/.claude/skills/housecarl` and add an `mcpServers` entry in `~/.claude.json`
  pointing at `server/housecarl-mcp.exe` — the layout setup produces, and the way out if the exe will not
  run on a machine. `~/.claude.json` is Claude Code's file, the terminal CLI and the desktop app's Code
  tab; the desktop app's plain chat is a separate surface reading
  `%APPDATA%\Claude\claude_desktop_config.json`. Neither reads `~/.claude/claude_mcp_config.json`, so a
  hand-migration that edits only that file leaves the host spawning the server it had before.
- **`HOUSECARL_MAX_SCHEMA_DEPTH` publishes the tool schemas cut to a nesting depth.** Set it on the server entry
  to the depth your provider accepts (JSON container nesting, the measure the refusing providers report), and
  every published schema is cut there and closed with the same node the recursion bound already closes with, under
  a clause of its own: nesting continues below and is accepted, and is not spelled out in this document, having
  been cut at that depth by this variable. `housecarl_create` and `housecarl_apply`
  publish at 24 and 21 today, which a provider capped at 10 refuses — and it refuses the whole server at
  `tools/list`, naming no tool. What a tool ACCEPTS does not move: a call nested deeper than the cut is bound and
  answered exactly as before, so the schema is less descriptive below the cut, never wrong. It applies to the
  server entry, not to one model, so models sharing that entry all get the cut schemas; use a second entry to
  split them. Unset — the default — publishes the full schemas, byte for byte what they were. A value that is not
  a whole number of 4 or more stops the server's start with one sentence naming the variable: a schema cut below 4
  loses the parameters and parameter types every call is checked against, which would quietly change what a call
  gets back. A cut that cannot reach the depth it was given stops the start the same way, naming the tool, rather
  than publishing a schema over the cap.
- **A forward `walk=` no longer holds every record it reached.** A record body read from a plugin is a slice
  of that record group's whole byte array and keeps it alive, so caching one body per reached node until the
  call returned pinned one array per source group per plugin: 270 KB per reached node, and a raised
  `walk.max_nodes` ran the process out of memory. A reached node now costs its row — its identity, its links,
  its pull chain — and a body lives only for the gather pass that read it, so the reached set is gone before
  anything renders. Measured on a 3,801-plugin order, the forward closure from one NPC: at
  `walk.max_nodes: 10000`, 3,528 MB peak working set becomes 1,430 MB; at 40,000, 9,469 MB becomes 1,490 MB;
  and at a budget big enough to exhaust the closure — which used to die with `OutOfMemoryException` at
  55,875 MB private after 471 s — the walk now finishes, reaching that seed's full 195,848 nodes in 308 s at
  1,808 MB. What the walk reports is unchanged.
- **`walk.max_nodes` now has a hard upper bound of 250,000, and a higher budget is refused naming it.** Fixed,
  not derived from the machine: a reached node costs a row of a few KB wherever the walk runs, so the arithmetic
  is the same on every box, and a bound that moved with the machine would let one call succeed on one and be
  refused on another. It bounds the budget without bounding an answer — the whole forward closure a single seed
  reaches, measured on a 3,801-plugin order, is 195,848 nodes, so a walk that finishes still finishes. The bound
  is on the PER-SEED reading of the budget, which the parameter's own description separates: the forward walk and
  the reverse carrier walk. The transitive reverse walk, where one budget is shared across every seed and every
  hop, is unchanged, and so is `walk.depth`.
- **`nif_set` no longer refuses a correct edit on a mesh whose stored block order is not NiflySharp's.** The write
  is verified by diffing the saved mesh against a normalized copy block by block, and the save re-sorts the block
  list into the library's own order — so on a mesh an exporter wrote in some other order, the block id the edit
  declared (read off the list as loaded) named a different block than the one the diff saw change, and the edit
  was refused as collateral damage. The id is now read after the save, from the same order the diff compares in.
  You can tell the case apart by the refusal it gave: it named a block the edit did not address, with an
  `expected only [...]` id that `nif_inspect`'s own census does not put that block type at. What the verification
  catches is unchanged — an edit that really does change a block it should not is still refused.
- **A `where=` predicate leading with `*parent` no longer holds the records it hopped to.** It shared the
  `->` link step's target cache, so every containing record it ever climbed to stayed held until the call
  returned — and a record body is a slice of its whole record group's byte array, which it keeps alive, the
  same cost the walk entry above describes. The hop now climbs the containment map in keys, so a record in the
  middle of a `*parent.*parent` chain is not read at all; only the record the terms are read ON costs a body,
  and that body is released when the candidate that read it is decided. What carries across candidates is the
  verdict, so a containing record is still read once per call however many children sit under it. Measured on
  a synthetic 21-plugin order, 20,000 placed references in 4,000 cells whose winners are spread across
  20 plugins, `where=["*parent.EditorID = <a cell>"]` with `counts_only`: 635 MB peak working set becomes
  289 MB, and the 580 MB that was still held 35 s after the call returned becomes 209 MB. Elapsed and the
  answer are unchanged. The per-candidate cost that remains is a clock, not a live set: the hop reads the
  containing record's body with an untyped whole-plugin seek, one per distinct parent.
- **A write's verify no longer says "re-read clean" about bytes it never parsed, and a read annotates every
  opaque blob with the record's FormVersion.** The forced in-place verify is a record-library re-read, and the
  library models a `bytes` field — `Model.Data` (MODT) is the case that bites — as raw bytes it never decodes, so a
  blob whose internal layout belongs to a different FormVersion re-reads byte-identical and the game crashes on it.
  The verify line now names those fields in the same sentence, each with its own byte count, and says they were
  re-read as bytes only with their structure not checked; a record carrying a list of blobs names the first few and
  counts the rest, so the compact line stays compact. A read renders a blob as `opaque bytes, N byte(s) — layout
  follows this record's FormVersion V; not parsed` — in the text read, the `readback=true` dump, and as `display`
  beside `opaque_bytes` / `opaque_form_version` in json — so a blob copied between records at different FormVersions
  is visible on the line. The version named is the one of the record the blob was READ off, which a `*parent` hop
  makes different from the record you asked about. The folded `rows` and `dense` renders take a short form,
  `[opaque 12B @FV40]`, because a cell there is positional and width-bounded. The annotation is display-only: the hex
  token still round-trips to a write, and no other line of any render changed. Nothing here decodes MODT — the layout
  is not modeled, and houseCARL does not hand-write per-record-type decoders — so a blob is only safe to copy between
  records at the same FormVersion, which these lines now let you check.
- **A forward `walk=` that reaches a record Mutagen cannot parse now records it and carries on.** Such a record
  used to be entered, and the parse fault came back as an internal houseCARL failure naming no record. The walk
  now keeps it as a boundary — its FormID, its type, its EditorID, and the exception on one line, the same
  "could not be scanned" account the `check` and merge lanes already give — and every other chain the walk was
  following still finishes. The boundary line is in the `chain` form's node list; a seed whose own content will
  not parse says so on its own line instead, and reaches nothing.

- **The reverse lane no longer walks a whole plugin per match.** An unbounded `references=` and a reverse
  `walk=` both read the winner's body of every candidate the reverse-reference index names, and each of those
  reads enumerated the winner plugin from the top to find one record — so a common target cost minutes after
  an index that was already built. Both now gather the candidates they are about to judge a block at a time,
  one enumeration per winner plugin, which is what the forward walk and the winner-source scan already did.
  The answers are unchanged: the same matches, in the same order, with the same per-cause drop counts. On a
  3,244-plugin order a warm unbounded `references=` on IronIngot (1,988 matches) went from 223 s to 5 s, and
  the reverse walk from it at the default budget from 275 s to 13 s. The index build itself is unchanged —
  the response still reports what it cost.

- **`housecarl_records` `project={form:'aggregate'}` on a `formids=` list now holds `max_chars`.** The count table
  rendered every group row whatever the ceiling said and stated nothing; it now stops at the cap and says how many
  of its groups it laid, the same notice the scan lane's count table carries. The counts themselves are unchanged —
  only the rendering is cut, so the table's totals stay exact. The json shape gains `rendered` and `truncated`
  alongside `groups`, as the scan lane's already has, and both json count tables now carry `groups_total` — how
  many groups the table has, so a cut document says what it was cut from. Raise `max_chars` to see the rest.

- **A `group_by=type` count table now names the types that were asked for and matched nothing.** They were simply
  absent before, so reading "no PARW records" meant diffing the request against the response. The counted rows are
  followed by one `no records: …` line naming them (json: an `empty_groups` array beside `groups`), which is charged
  against `max_chars` ahead of the counted rows so a cut table still carries it; past the room that line has, it
  says how many names it did not print. Both lanes state it: a scan, and the `formids=` list lane's carrier walk,
  where `types=` narrows the carrier types. A type name the tool does not know is still refused by name, which is a
  different answer from a known type with nothing in it.
- **`where=` takes a negated string operator: `not contains` and `not startswith`.** A complement over a
  substring had no spelling — `where=["Name not contains Dagger"]` refused with "'not' must be followed by
  'in'" and the only way through was to spill every row and filter by hand. `not` now leads a string operator
  as well as the membership complement it already led (`not in`). The operators that already have a complement
  keep it, and a `not` in front of one is refused by name pointing at it (`!=` for `=`, `missing` for `exists`,
  `has_none` for `has`). On a field path a negated term matches only records the path reads a value on, the same
  rule the accounting note on the result states for every other value operator: on a field that is unset
  everywhere the answer is zero matches with that note, not everything. The identity term `editorid` is the
  exception the parameter description names — it always gives a verdict, so a record with no EditorID is on the
  negated side, where `!=` and `not in` already put it.
- **An exact `editorid =` that matches nothing now names the record the winner renamed.** A scan filters on the
  load-order winner's body, so `editorid = ArmorIronCuirass` reads as a clean zero when the winner renames that
  record — the name is real and only a losing copy carries it. The result now carries one sentence naming the
  plugin that defines the name asked for, the FormID, and the EditorID the winner gives it. It runs only on a
  zero-row winner-lane scan bounded by `types=` whose `where=` is nothing but that one term — any other selection
  term (`formids=`, `references=`, `references_none=`, `editorid_contains=`, `conflicts_only=`, `plugins=`, or a
  second `where=` predicate) gives the zero another possible cause, so the sentence is not offered. It reads the
  EditorID header and nothing else, one plugin at a time so an unreadable file skips rather than ending the walk,
  and when no plugin in the order carries the name the plain zero-row result stands as before. The bound it gives
  up at is `EditorIdNearMiss.Budget`.

- **`housecarl_skse` now says which source a plugin's version came from, and prints the DLL's file version and the
  mod's meta.ini version beside it wherever they disagree.** The version it reads is the SKSE manifest's own
  declaration, which authors routinely leave stale: Spell Perk Item Distributor 7.3.3 declares 7.0.0, and 51 of the
  313 DLLs on the order this was measured against declare something other than their file version. A row now reads
  `v7.0.0 (SKSE manifest; DLL file version 7.3.3.0)`, so a version floor (SPID's 7.3-only INI tokens, say) is
  decided against both numbers rather than against the declaration alone. A DLL with no manifest to declare anything
  shows whichever version was read — the file version, or the mod's meta.ini when that is the only one. `format='json'`
  carries them as `file_version` and `mod_version`, each null when the DLL carries no version resource / the provider
  has no meta.ini. Versions that agree are not repeated, and versions are compared on their numbers, so a meta.ini
  tag ("7.0.19.0-AIO", "5.2SE") is not reported as a disagreement.

- **`housecarl_merge_plugins` refuses a donor whose master is not active before it walks the load order.** The merge
  reads each donor's declared masters from the plugin headers and checks them against the active order first, so the
  refusal — the same sentence the write already gave, naming the master to enable — arrives in the time a header read
  takes rather than after the whole-order pass that lists external referencers. Nothing else about the merge changes,
  and the write still makes the same check before serializing.
- **`project.form="tree"` no longer holds every provider of a record at once.** The fill read all of them and
  kept each one's fields alive until the whole render was built, so a record hundreds of plugins touch — a
  worldspace — cost gigabytes for a single row, and the process still held it after the call returned. It now
  reads the providers winner first and keeps one at a time: a record getter pins its whole group's bytes, and the
  diff needs only the reference pole plus the provider being compared. Same answer, character for character
  (pinned by a golden over a three-provider record). Measured on a 3,571-line order, a tree over Tamriel and
  WhiterunWorld: peak working set 2,971 MB → 1,878 MB, held after the call 2,600 MB → 1,818 MB, elapsed
  unchanged. What remains is the answer itself — the deltas of every provider — so the lever is still the number
  of records asked for.

- **`housecarl_merge_plugins` now describes the normal job, and carries injected records.** The description said merging a
  mod together with its own patches was the intended use; it now says what the tool is for — merge a family of patches into
  one plugin and leave the mods they patch alone and active — and marks the mod-plus-its-patches shape as the narrow case it
  is. A record whose FormID sits in one donor's space while another donor defines it (an injected record) is now renumbered
  into the merged plugin like any other record; before, it was copied at its old identity and the write failed with a raw
  Mutagen missing-mod fault after the whole merge had been built. A plugin outside the merge that carries that record too is
  named in the external-overrider warning, as any other dependent is. A donor reference into donor space that no donor holds
  is refused in one sentence naming the referencing record, before anything is written.

- **A merge now says where the merged plugin has to load.** The report carries a placement paragraph: the load-order
  positions the donors sat at, the last master the output must load after, and the position it must sit at — the last
  donor's, because the merge resolved the donors' conflicts as they stood there, so an earlier slot lets content the donors
  used to beat win over the merge and a later one puts the merge over plugins that used to beat them. It says what that
  position decides, the donors' overrides kept at their masters' FormIDs, and what it does not: the donors' own records are
  renumbered into the output's FormID space, so a plugin that overrode one is orphaned by the swap, which the report's
  existing warning names, rather than outranked by where the output sits. A master the order carries BELOW the last donor is
  said plainly, since the output cannot then sit where the donors did. Derived from what the merge already computed, so it
  costs no extra scan and there is no new parameter.

- **`limit=` now bounds what a `delta` or `tree` over a scan READS, not only what it renders.** Those rows read
  every provider of their record, so asking for the first ten rows of a 17,727-row scan used to read all 17,727 —
  the window was applied after the work. It is applied to the selection now, and the response says the rows outside
  it were not read. Measured on a 3,571-line order, a tree over one plugin's 17,727 placed references with
  `limit=10`: still running when it was killed at 4 minutes, against 8.3 s. A census and a `to_file=` artifact are
  unchanged: both state the whole selection by definition, so both still read all of it.

- **A `delta` or `tree` past 250 records refuses up front instead of going quiet.** The call knows the count and
  the form before it reads a body, so it now says so in one sentence — the count, that a tree reads every override
  of each record, the estimate, and what to try (`limit=`, `where=`/`types=`, or `project.form='fields'` for the
  winning value alone). The bound is about a minute at the 0.25 s a two-provider record costs on a large order; a
  record with more providers costs more again, so treat it as a floor. The twenty-minute silent read that prompted
  this — a tree over ten plugins' placed references — now answers in under a second.

- **`housecarl_apply` refuses `from_source=` on any verb but `op='CopyFrom'`.** Only `CopyFrom` reads it; on
  another verb it was accepted, dropped, and the edit written off the load-order winner instead of the plugin
  you named — with success reported. The refusal names the op index and the verb it got, the way `from=` on a
  non-`CopyFrom` op is already refused, and nothing is written.

- **`housecarl_place` and `housecarl_nif_inspect` refuse a raw path into MO2's mods folder.** Reading or writing
  through a mod folder's own path goes around the virtual file system. A mods path passed as `place`'s `path=`
  or `source=`, or as a `nif_inspect` `mesh_paths=` entry, is now refused in one sentence that hands back the
  address form instead: the mod folder named in `source_provider=`, with the Data-relative path. A path
  anywhere else on disk is unchanged — naming one exact copy outside the mods tree is still how you place it, and
  so is the Data-relative form, which is judged on the path you wrote rather than on where the server happens to
  be running. A `'<archive.bsa>|<entry>'` source keeps its entry in the sentence, and a FaceGen pair placed from
  one member (a `formid=` with no `kind=`) is pointed at that same archive by its filename, which is a provider
  name — each slot then derives its own entry from it. The destination refuses the whole call with the other
  malformed members; the source is a per-member failure, so the rest of the batch still places.

- **`housecarl_records` with `plugins=` no longer fails the whole call when one named plugin is not loaded.** It
  answers for the plugins that are in the order and names the missing one beside the result, so the other named
  plugins' reads are not thrown away with it. Each missing name carries its own cause — the plugin is installed
  but unticked, or the did-you-mean for a near-miss spelling — on both the served note and the refusal. A scope
  whose every name is missing is still refused, naming them: there is nothing left to scan. The same shape holds
  when `source=` names a plugin outside the load order, which reads on its own lane, and on every form and both
  transports: the forms whose rows come from a body read built their own header and carried none of the scan's
  coverage notes, so this line — and the existing unscannable-record and unreadable-plugin notes — reached a
  scan render and not a body one. An empty entry in `plugins.names` is refused by its index instead of reaching
  the resolver as bad input.

- **A write that forks a record another plugin already overrides now says so.** `housecarl_apply`,
  `housecarl_forward` and a nested `housecarl_create` (which overrides its parent in) all land an override in a
  patch, and Skyrim applies only the last-loaded copy of a record — so a second patch overriding the same record
  splits it in two and one half never applies, which used to happen with every call reporting success. Every lane
  that lands an override — a new patch, `into=` an existing one, and `in_place=` — now carries one `warning:` line
  naming the other plugin(s) and the lane that builds on that copy instead. It is a warning, not a refusal: a
  deliberate fork still writes. Which plugins count is the write path's own provider list for the record, minus the
  patch being written and the record's defining plugin, and then narrowed by where the patch sits: a patch that has
  a position (`into=`, `in_place=`) counts every plugin at or below it, whoever wrote it, and the remedy names
  `into=` or `in_place=` accordingly; a NEW patch has no position yet but has copied the winner's body in, so it
  counts only a sibling houseCARL patch, judged by the same `meta.ini` ownership marker `into=` itself is gated on.
  Overriding a nested record drags its container in as an override too — a placed reference pulls its cell, an INFO
  pulls its topic — so the question is asked about each record's containers as well, and a container another patch
  already overrides is named even though nothing in your own call mentioned it. The wording follows the lane: a new
  patch really does make a second copy, while an in-place edit of a record the plugin already carries makes none, so
  there the line says the edit is out-loaded rather than calling it a fork.
  Two bounds worth knowing. It reads the ACTIVE load order, so a sibling patch that is installed but unticked in
  `plugins.txt` is not named — its records are not indexed, and finding them would mean opening every installed
  plugin on every write — and the line says nothing about an unticked plugin either way. And a single `into=` is
  offered only when every affected record answers to the same plugin; when they do not, the line says to route each
  record into whichever of the named plugins loads last over it, naming the same `into=`/`in_place=` split. A long
  list of plugin names keeps the LAST-loaded three — the copies that actually win — and counts the earlier ones.

## 2.0.0 — 2026-09-11

houseCARL 2.0.0 replaces the 1.x tool surface with 31 tools. The record plane is one grammar: a read is one call composed from four axes (SELECT × SOURCE × PROJECT × TRANSPORT); a write is one call composed from an op list, a lane and a transport; one record is a set of one. Record coverage is generated from Mutagen.Bethesda.Skyrim 0.54.4 at build time, 1,174 types, and the write pre-flight and the `mutagen-reference` skill are two renderings of that one artifact. The 1.x tool and parameter names are deleted, not deprecated: a retired tool name is refused with a refusal naming its successor, from `AliasTable.cs`; a retired parameter name is refused as an unknown parameter, with the parameters the tool does take. Seven skills ship. `housecarl_check` gains the facegen family. The installer shows what it will write before writing, and uninstalls. The entries below are in the order they landed.

- **Setup can take houseCARL back off the machine.** `[4] Uninstall` on the menu, or `--uninstall` with
  `--claude`, `--codex` or `--both`, removes what an install wrote: the skill folders setup recorded
  installing, the server with the saved MO2 instance beside it, the rest of the files a houseCARL package
  ships, the record itself, and the `housecarl` entry in `~/.claude.json` and `~/.codex/config.toml`. A file
  or folder under those locations that houseCARL did not install is left where it is and named, and so is the
  folder holding it. Each config file is copied to a `.houseCARL.uninstall.bak` beside it — a name of its own,
  so the copy the install took is still there — and then spliced, so the entry goes and every other byte in
  the file stays where it was, its BOM and each line's own newline included. A config that carries no entry
  setup recognises is reported as not found and is not written to at all. The `setup-uninstall` CI guard
  drives the splices over a table of config shapes and asserts the byte-for-byte result of each. The patches
  houseCARL wrote live in your MO2 mods folder and are not touched. The shared `~/.agents/skills` holds other
  agents' skills, so only folders the record names are removed there; what an install with no record removes
  instead, per host, is on `Uninstall` in `src/housecarl-setup/Uninstall.cs`.
- **The Claude install records which skills it wrote.** `installed-skills.txt` at the root of the installed
  tree, mirroring the one the Codex install has kept since it started sharing `~/.agents/skills`. It is what
  the uninstall reads to name the skills it is taking back. An install made before this version left none, and
  an uninstall of one says which route it took instead.
- **A run says what it did when it is over.** Install and uninstall both close with the same block: the paths
  that were written or removed, host by host, then what to do next — restart the host, and for an install that
  houseCARL asks for your Mod Organizer 2 folder the first time a tool is used. An install writes every line
  of its plan, so its block is that plan printed again; a removal's is not, because a host with nothing
  installed or a config with no entry of ours is a line the run does not act on. Each removal line is what
  that step actually did, carried back from the run, on `Plan.PrintRemovalSummary` in
  `src/housecarl-setup/Plan.cs` — a removal that took nothing off says so rather than claiming the paths it
  intended to touch.
- **The .NET runtime and broken-package refusals now come after the menu rather than before it.** The runtimes
  and the package are the install's, so only an install needs them; refusing at the detection block left a
  machine missing a runtime, or holding a half-unzipped download, with no way to reach `[4] Uninstall`. The
  detection block still reports both runtimes before anything is chosen.
- **The detection block and the host menu read in colour.** A host that is here, and a houseCARL already
  installed for it, are green; anything absent or unchecked — a host that is not on the machine, a runtime
  that was not found or was skipped — is dim. Nothing in the block is red: a refusal is what says a run is
  stopping, in its own red, after the choice. The text is the same either way, and when it is not coloured,
  and why, is on `Ui` in `src/housecarl-setup/Ui.cs`.

- **The plugin's own `README.md` describes the 2.0 surface.** This is the file the installer copies to
  `~/.claude/skills/housecarl/README.md` and the marketplace shows. It is now the installed-copy subset of
  the top-level `README.md`, and says what it carries. It was still the 1.x text, including a claim that
  Mutagen is kept warm in memory, which the lazy-read design contradicts. The grammar, the predicate language, the runtime layers and the
  internals stay in the top-level `README.md`, which it links to.
- **The top-level `README.md` describes the 2.0 surface.** It names the tool surface and the axes a call is
  composed from, states what houseCARL is not, and carries the install, requirements and upgrade-from-1.x
  notes. The 1.x-to-2.0 tool-name mapping is the refusal
  itself: a retired name is refused with the sentence naming its successor, from `AliasTable.cs` in
  `src/housecarl-mcp/`.
- **The setup program says which version it is installing, and leads every error with one sentence.** The
  banner now reads `houseCARL <version>  ·  setup`, stamped from the same `plugin.json` version the server
  reports. Each refusal — the plugin folder not being beside the program, a missing .NET runtime, a server
  file in use — now opens with one plain sentence saying what went wrong and what to try, with the paths,
  download links and the two-installer note indented below it; the runtime refusal names only the runtime
  that is actually missing rather than listing both. Output is coloured; when it is not, and why, is on `Ui`
  in `src/housecarl-setup/Ui.cs`.
- **The setup program says what it found, then what it is about to write, and waits for a yes.** Before it
  copies anything it prints what is on the machine — each host, whether houseCARL is installed for it and at
  what version, and the .NET runtimes — and then the plan: one line per destination, naming the exact path,
  and a per-host label from `Plan.HostAction` in `src/housecarl-setup/Plan.cs`, which compares the installed
  version against the package's rather than only testing them for equality. The plan reads the destinations
  from the same path helpers the install writes to, on `Program` in `src/housecarl-setup/Program.cs`, so the
  plan and the install cannot disagree, and it says that an upgrade deletes the skill folders this version no
  longer ships. Enter proceeds and `q` quits, on `--claude`, `--codex` and `--both` runs too; `--yes` is the
  one way past the confirm, on `Confirm` in that file. Where exactly one host is found, Enter at the menu
  picks it.
- **Setup refuses a question it has nobody to ask instead of answering it.** A run whose input is redirected
  used to take the missing keypress as a yes at the plan and as a cancel at the host menu. Both now refuse
  with one sentence naming the flag that answers the question in advance — `--claude`, `--codex` or `--both`
  for the host, `--yes` for the confirm — and `--help` says so. A host is also reported found only on a file
  the host itself writes, not on a directory bearing its name; which files those are is on `Detect` in
  `src/housecarl-setup/Detect.cs`.
- **A refusal for an unknown field now names every field the record type has.** `housecarl_apply` and
  `housecarl_create` run the same pre-flight, and it used to name twelve fields and then `(+N more)` with no
  route from the call to the rest — a write call is the only place the surface shows a type's schema without
  an instance of that type in the load order, so the cut ended there. It now names them all, and where the
  list is too long to be a sentence it cuts and says in the same sentence that the `mutagen-reference` skill
  carries the remainder. Where the cut falls, and what it is set against, is on `FieldListCap` in
  `src/housecarl-core/CorpusRulebook.cs`.
- **A record read tells a present-but-zero link apart from an absent one.** A nullable link whose subrecord is
  present carrying FormID zero now reads `(null link, subrecord present)`; an absent subrecord still reads
  `(null link)`. A `where=["PreviousDialog exists"]` sweep and the conflict diff make the same split. The two shapes mean opposite
  things on an INFO's `PreviousDialog` (PNAM), and how to re-list a line without moving it is in
  `docs/dialogue.md`. Check a line before you re-list it —
  `project={"form":"fields", "fields":["PreviousDialog"]}` on the INFO says which shape it carries, and
  `project={"form":"info_order"}` on its topic says where the line lands.
- **`housecarl_copy` says which of the source folders it names the game is not loading.** Every arm of
  `from_source=` that resolved into a mod folder the active profile does not load gets its own `note:` line
  beside the sources it consulted — not just the arm the record was read from, since the folder a placement
  is handed afterwards is often one of the others. A folder MO2 lists and has switched off is reported with
  the sentence `housecarl_place` already uses; a folder MO2 has not registered gets its own, because there
  is nothing in MO2's list to switch on for it. Nothing about what is copied changes: the standalone claim
  under it is about what the patch masters, and it now reads next to the fact that the game is not loading
  the source.
- **`housecarl_create` refuses a dialogue branch with no `Flags` instead of filling one.** A `DialogBranch`
  created with no `Flags` is now refused in one sentence naming both values and what each does — `TopLevel`
  for a menu entry the player can pick, `0` for a scripted `Say()` topic that must stay hidden — and nothing
  is written. Neither value can be filled: `TopLevel` is what publishes a branch to the player's menu, so `0`
  on a menu branch kills it and every topic under it, while `TopLevel` on a hidden branch puts a nameless line
  in the menu as a selectable `...`. Skyrim.esm carries both shapes. A `Flags` you pass always wins, an
  explicit `0` included. Both cases and how to pick are in `docs/dialogue.md`.
- **The `dialogue-authoring` skill is gone; seven skills ship.** It tied its no-skill control on the September
  behavioural gate, so the dialogue tools are the whole surface now. What it held that was measured in game
  moves to `docs/dialogue.md`: which topic a generic greeting enters is decided by quest priority across quests
  before intra-topic order, so a gate that always passes replaces the NPC's whole greeting pool; and a
  re-listed INFO — any override of an existing one, including one that only adds a condition — falls to the
  bottom of the merged topic order unless it carries `PreviousDialog` naming the line above it, read from
  `project={"form":"info_order"}`. That page also names the `DialogBranch.Flags` refusal, the
  `Goodbye` flag nothing fills for you, and the two lanes that cannot see an unenabled plugin. `housecarl_create`
  and `housecarl_check` cite it by URL, the way the facegen page is cited, so a session authoring or checking
  dialogue reaches it from the tool description.
- **A write refusal now names and counts every rejected op, including several that name the same record.** The
  pre-flight harvests the FormID values a call sets into a deduplicating set, and decided whether an op needed
  the link type-check by whether that set had grown — so the second and later ops pointing at one FormID were
  taken for link-free, kept the verdict reached before the check existed, and were neither listed nor counted.
  Four illegal ops on one armor refused as "2 of 4 edit(s) rejected", naming two, which reads as the other two
  having passed. Every op is now checked and reported, and the count is the number rejected. Nothing was ever
  written: the refusal was already all-or-nothing, so a hidden op could not reach a plugin.
- **The `mutagen-reference` schema reference now reports a record-identity field as not writable.** A field
  marked `id` — `FormKey` on a record, and `ModKey` / `Master` on the `SkyrimMod` and `MasterReference`
  structs — is refused by the write pre-flight whether or not the library exposes a setter for it. The two
  that did expose one, `MasterReference.Master` and every record's `FormKey`, flip from `"w":true` to
  `"w":false` here, so the reference now reads `"w":false` on every `id` field and counts them out of a type's
  `writable/total` summary (ARMO is `31/32`, not `32/32`). The read view and the write tools now agree about
  what can be set. The skill says what `w` means; how to change a record's identity is in the same section.
- **Four skills fold in what the September behavioural gate found.** `mutagen-reference` says how to resolve a
  field's `target` and blesses one whole-file grep for enumerating the modeled types; `open-animation-replacer`
  gives a legacy Form B folder's priority (0), tells you to recompute the winner table with your submod spliced
  in rather than parking near int32 max, covers the base-clip layer and says the sweep is third-person only, and
  converts a different worked folder; `kid-authoring` names the record field behind every trait, adds an
  exclusion-then-trait example, and says how a KID line differs from a SPID one; `spid-authoring` documents the
  FormLink wire form and the one-call union census, says a written-out player exclusion is inert, and labels its
  level-filter census as measured on one instance. The four questions that entry left open are settled by the entry on the
  four grammar questions answered from the distributors' own source.
- **`kid-authoring` and `spid-authoring` answer four grammar questions from the distributors' own source.** A KID
  plugin-name filter selects by the plugin that *defines* a record, not the one that wins it, so an override
  changes nothing about the set; a KID `*wildcard` is a case-insensitive substring test against EditorID, display
  name and the item's own keyword EditorIDs only — a `.nif` term tests the model path instead, and archetype and
  actor-value names are exact-match channels a wildcard never reaches; SPID's INI scan reads `Data/` itself and
  does not descend, so a `_DISTR.ini` in a subfolder is never read; and SPID's SKSE version manifest carries only
  the major digit, so every 7.x release declares 7.0.0 there while the DLL's own file-version resource carries
  the full number — `housecarl_skse`'s number is a major-version floor, MO2's `meta.ini` is the installed
  download's version string and can lag a repack or a manual update, and the file-version resource is the
  authoritative read. The same
  read corrected how KID's filter groups combine: Matches and Wildcards are separate gates a line must pass
  both of, not one pooled OR. Each fact
  cites the function and release tag it was read at, in the skills' `references/`; the corpus-status files record
  what closed and what is still open.
- **`housecarl_check` gains a FACEGEN findings family, and the `facegen-diagnostics` skill is gone.**
  `findings=["facegen"]` answers the dark-face question server-side, one row per NPC: which mod wins its head
  `.nif`, which wins its face `.dds`, which plugin wins the `NPC_` record behind them, the mismatch class and a
  fix sentence. Two independent precedences decide a face — the MO2 VFS for the files, load order for the record
  — and the desync between them is why xEdit shows nothing; joining them by hand outside the tools took about
  half an hour and two dozen calls. Classes: `tint_absent`, `mesh_absent`, `bake_absent`, `split_bake`,
  `stale_bake`, `family_split` (benign — counted in the header, listed only under its own token),
  `foreign_index` and `inert`. The population is the union of every in-scope NPC that needs a bake and every
  facegen file on disk whose key resolves to nothing; an NPC that inherits its appearance through
  `Template`+`Traits`, or whose race carries no `FaceGenHead` flag, is excluded and counted rather than reported
  as broken. It is not in the default findings set, and it is allowed unscoped: a whole-order sweep of a
  3,801-plugin order measured 45 seconds, beside the errors family's 24 to 37. The skill it replaces is deleted;
  its causes-and-fixes reference is now `docs/facegen.md`, and its mesh-repair reference folded into
  `housecarl_nif_set`'s own parameters.
- **`housecarl_check` gains `to_file=`.** It writes every running family's findings to one JSONL artifact under
  the same manifest convention `housecarl_records` uses, with a `family` and a `class` column, and renders only
  the manifest inline. The rows are the sweep's findings rather than the render's, so nothing is missing because
  the inline body ran out of characters. Refused beside `counts_only=true`, which returns histograms and no rows.

- **`housecarl_check`'s record-type scope is now the set-valued `types=`, the same spelling and value form
  `housecarl_records` takes.** One type is a set of one, so `types=["Npc"]` sweeps what `type="Npc"` swept; a set
  sweeps the union of its types in one pass and merges the findings, and the response's narrowing line names every
  type in it. An unknown type is still refused by name, and the cost is what the parameter says it is: the scope is
  applied at the record stream, so the types you did not name cost nothing. A BLANK entry in a type set is refused
  saying it is blank, on `housecarl_check` and `housecarl_records` alike; an empty or omitted set is the separate
  thing it has always been (no narrowing). And because the scope's types share ONE listing — filled plugin by plugin
  and type by type inside each — a short listing under a multi-type scope now names the types sharing it (spelling
  the arms an entry like `GMST` expands to) and the knob that cut it, `limit=` or `max_chars=`: a type absent from
  the listing is unlisted, not clean.
- **The note a write emits when a link target's plugin cannot be read now names what it counts: the distinct
  records the write links to in that plugin.** The values a write's link check needs are enumerated by the same
  schema walk that does the checking, and two slots naming one record are one record here. What the note says
  about the skip is unchanged: those links are not type-checked, and the write proceeds. An in-place edit that has
  both a bad `field_path` and a bad `from_plugin` now reports the source problem first, as the patch lane already
  did, and the field-path problem on the re-run.
- **The tools no earlier wave renamed now take the 2.0 parameter names, and an old spelling the tool no
  longer declares is refused by name.** `housecarl_compact_plugin`: `plugin=` is `source=`, `patch_name=` is
  `patch=`. `housecarl_create_plugin`: `plugin_name=` is `patch=`. `housecarl_merge_plugins`: `output=` is
  `patch=`. `housecarl_bsa_repack`: `archive_name=` is `patch=`. `housecarl_bsa_extract`: `dest=` is
  `out_path=`. `housecarl_load_order_status`: `lookup=` is `filter=`. `housecarl_compile_script`:
  `patch_name=` is `patch=` and `output_dir=` is `out_path=`. `housecarl_decompile_script` and
  `housecarl_nif_set`: `patch_name=` is `patch=`. `housecarl_nif_inspect` and `housecarl_nif_set`: `mod=` is
  `source_provider=` — the same provider pole `housecarl_place` takes, naming whose copy of the mesh to read,
  while `source=` is only ever the plugin to read. `housecarl_write_seq`: `output_dir=` is `out_path=`, and
  its JSON response member `user_chose_output_dir` is `user_chose_out_path`. `housecarl_remove` is unchanged:
  a removal edits an artifact that already exists, so its lane is `into=`.
- **`patch=` now names the output mod FOLDER on every tool that writes one, `housecarl_merge_plugins` and
  `housecarl_bsa_repack` included, and the artifact inside takes that folder's name.** `patch="MyMerge"` on a
  merge writes `houseCARL - MyMerge\MyMerge.esp`; `patch="MyArchive"` on a repack writes
  `houseCARL - MyArchive\MyArchive.bsa`, and with `into=` the archive takes the name of the folder it lands in.
  The second knob `patch_name=` is gone from both tools, along with the `'<patch> merged'`/`'<patch> renamed'`
  and `houseCARL_Archive` folder defaults; a repack with no `patch=` names both the folder and the archive after
  the source folder. `patch=` with the `.esl` extension on a merge is still refused, because a merge does not
  constrain object ids to the light window.
- **On those two tools a colliding `patch=` is now refused by name and nothing is written, never auto-suffixed —
  the rule `housecarl_create_plugin` already followed, and what `patch=`'s own description promises.** Because
  the artifact takes the folder's name, a suffix would rename the artifact too: a merged plugin written as
  `MyMerge_001.esp` is not the name a `_DISTR.ini`, a config or a dependent's master entry resolves, and a
  `MyMerge_001.bsa` is not a name the game auto-loads. So a mod folder of that name already under your mods
  directory, or an active plugin of that basename, refuses and says which is in the way. `housecarl_bsa_repack`
  also refuses `patch=` given together with `into=` — the archive takes one folder's name and the two lanes name
  different folders — and refuses an archive already sitting at the resolved path, rather than replacing it, so
  a second repack into one folder can no longer overwrite the first archive.
- **On the tools whose `patch=` names the output mod FOLDER — `housecarl_compact_plugin`,
  `housecarl_compile_script`, `housecarl_decompile_script`, `housecarl_nif_set`, `housecarl_write_seq`,
  `housecarl_place` — an artifact spelling (`plugin_name=`, `output=`, `archive_name=`) is refused by name
  with the supported list instead of being read as the folder's name.** `plugin_name=` still reaches the
  plugin parameter on the tools that have one (on `housecarl_compact_plugin`, `source=`).
- **A 1.x parameter name is no longer mapped onto its 2.0 replacement: it is refused by name, naming the
  parameters the tool does accept.** The table that renamed `plugin=` to `source=`, `patch_name=` to `patch=`,
  `operations=` to `ops=` and the rest, and that turned the old `in_place=true` + `target="X.esp"` pair into
  `in_place="X.esp"`, is gone; so are the migration hints it attached to a retired spelling. An old spelling
  now gets the same unknown-parameter refusal as any other unrecognized argument — including when it stood in
  for a required parameter, where one sentence names both the parameter that is missing and the spelling that
  is not one. 1.x's lane flag — `in_place=true` or `in_place=false`, bare or quoted — takes one refusal by name
  saying the parameter names the file being overwritten: nothing enters the in-place lane from a call that did
  not name a file. Tolerance for an underscore or case variant of a parameter
  the tool actually declares (`form_id` for `formid`) is unchanged. The singular-for-plural bridges go with the
  table: `formid=` and `type=` no longer bind to `formids=` and `types=`, and a 2.0 word a tool does not declare
  (`patch=` on a tool that takes `into=`) is refused like any other unknown. A call to a 1.x TOOL name is still
  refused with one sentence naming its 2.0 successor and how to spell the call.
- **`housecarl_skypatcher_layer` with a `filter=` that matches no INI now says so instead of returning the
  whole-layer overview.** It answers with the filter, the match count (0 of N INIs), the type folders that are
  present, and a nearest-name suggestion where there is one, so a filter typo can no longer read as the layer's
  contents. The zero-match answer carries the scan notes (shadowed copies, undocumented subfolders) and the
  read-incomplete caveat, which are often the reason nothing matched. That answer obeys `max_chars` like every
  other one: its notes are cut with a notice saying how many of them are shown, and the caveats still render.
- **`housecarl_skypatcher_layer`'s `filter=` now selects at the type-folder level: a folder with no match is
  skipped, and a folder with one lists every file in apply order with the matching files expanded to their lines.**
  The files sorting before and after a match — which is what decides whether its writes survive — stay in the
  answer, and a matching folder that sorts late is no longer cut by `max_chars` before it is reached. Each folder's
  header says how many of its INIs matched and were expanded, so the header describes the listing under it. The cut
  notice no longer tells a caller who passed `filter=` to pass `filter=`. A blank or whitespace `filter=` is treated
  as no filter at every site, so it gives the overview instead of expanding every INI in the layer.
- **`housecarl_apply` and `housecarl_create` now refuse a FormLink pointed at a record of the wrong type.**
  Pre-flight checked that a link value parsed as a FormID and nothing more, so setting an armor's `Race` to a
  keyword was accepted and wrote a plugin that is valid on disk and wrong in game. The gate now resolves the FormID
  and compares that record's type against the link's own target, naming the field, the type given and the types
  allowed. A field whose link accepts any record, a null-clear, a FormID no plugin in the order defines, and
  removing a link already in a list are not refused.
- **A dialogue topic whose numeric `Subtype` contradicts its SNAM marker is now flagged, and the marker is named
  as the authoritative one.** The engine buckets topics by SNAM; the numeric subtype is stale on topics authored
  before the Dragonborn-era Creation Kit inserted six `FlyingMount*` values into the enum, so a vanilla `HELO`
  topic can read as `RechargeExit`. The dialogue check now warns on the disagreement, and on a non-blank marker
  houseCARL does not model. Both warnings are scoped to a pair the plugin itself states: a topic whose winner is
  force-loaded content (the base masters, Creation Club, `_ResourcePack.esl` — the implicit group
  `housecarl_load_order_status` lists) is passed over, and so is an override that carries the base record's pair
  forward unchanged, so a whole-quest check over vanilla topics stays quiet. The labels are not scoped: both
  renders show the pair (`subtype=… (stale)`, `subtype_marker=… (authoritative)`, `subtype_stale`,
  `subtype_from_marker`) on every topic. The advice follows the numbers: a stored value exactly six below the
  marker's modern index is the renumbering, and any other gap is two fields edited apart, where the warning says
  the `Subtype` edit does nothing in game until SNAM is synced to it — which is what setting `Subtype` through
  houseCARL does for you. Where a recommendation is derived from that unreliable field rather than from the base
  record's SNAM, it says so. Nothing is rewritten: no field on the record distinguishes the two numberings.

- **`dialogue-authoring` now makes a new line's own quest the default route, and appending into a vanilla
  topic the exception.** A new line on an existing NPC gets its own start-game-enabled quest at a priority
  measured above the incumbent dialogue quest's, its own topic, and the `.seq` — no vanilla record is
  touched, and the new topic preempts the vanilla lines whenever its gate passes rather than replacing them.
  Appending into an existing topic keeps its own section with the case for taking it, and both worked
  examples now carry the exemplar's `Emotion`/`EmotionValue`/`Flags`; the append example previously wrote
  neither. The default route composes its gate in the create call as typed `ConditionFloat` rows — a speaker
  check plus a row that passes only sometimes, so the vanilla greetings stay in rotation — and cloning a
  vanilla gate with the `housecarl_apply` copy zip is the option, with the wholesale-copy and alias-scoped-row
  caveats and the `op:"Remove"` call that drops a row that does not belong. The skill also says how to find
  the vanilla exemplar (`references=[<npc formid>]`, not a `Speaker` scan), that the activation greeting is
  the `HELO` subtype with no `GREE`, that a topic's `SNAM` marker is authoritative for its subtype on any
  copy where the numeric `Subtype` disagrees, and which of the two `Priority` fields carries the number you
  measured.
- **A FormID that mixes the two forms — eight runtime digits with a plugin name, `000A2C94:Skyrim.esm` — is now
  refused with the six-digit form to use (`0A2C94:Skyrim.esm`).** It read "Malformed FormKey string" before and
  named no form at all. The refusal offers that form only: the bare eight digits resolve against whatever order is
  loaded now, which can be a different plugin than the one you named.
- **A bare runtime FormID as a `where=` value — `where="ObjectEffect = 000A2C94"`, the form the console and the
  logs print — now resolves through the call's own load order and compares as the record it addresses.** It
  string-compared to a definite non-match on every record before, so the scan looked healthy and reported 0
  matches. A call with no load order to resolve it against refuses it by name instead. An entry inside a membership
  list — `where="Race in [000A2C94]"` — resolves the same way, so a list may mix the two FormID forms.
- **`format='json'` now states that a record's fields are an ordered LIST of `{path, value}`, not a map keyed by
  path.** The order is the answer's own and a path repeats under a quantified step, which a map could not hold; a
  field that read no value carries `{path, note}` instead. Key a consumer on the position, or join on `'dense'`.
- **A `where=` path that reads no value now says why per cause — unset, not a field on the record read, a
  container, a `->` link whose targets are not in this load order, or a read fault — instead of one "no readable
  value" for all five.** A null field and the other arm of a union are not read faults, and a link that is set but
  points at a disabled plugin or a missing master is not unset: its remedy is to enable the plugin, not to widen
  the scope. The counts are now named separately.
- **A FormID token now spells its plugin the way the file is spelled on disk, in every read.** A link's plugin
  used to be spelled from the master list of whatever plugin held the link, and a token you passed in was echoed
  as you typed it, so the same record could come back as `Skyrim.esm` in one read and `skyrim.esm` in another and
  a join of two outputs missed those rows. Every token now prints the load order's own spelling, and a
  `defined_in` group is labelled with that spelling instead of whichever one arrived first — the counts were
  never split, since the grouping already ignored case, but the label a caller joins on was unstable. A plugin
  the active order does not carry keeps the spelling it arrived with.
- **`open-animation-replacer` now states how a DAR `_conditions.txt` chain binds, and that the DAR weapon-type
  numbers convert unchanged.** Both were marked unverified in its reference, and the skill told you to convert
  under one reading and say which. Both are now read off OAR's own source; the reference's §8 carries the rule,
  the source files and the date they were read.
- **Two more skills are removed: `bulk-record-jobs` and `npc-appearance-copy`.** Nine skills ship now. A
  behavioural gate ran each against a control with no skill loaded on the job it exists for, and both tied: the
  same deliverable, the same errors. What each still bought is now on the tool that does the work.
  `housecarl_records`' `fields_source=` says that an NPC whose `Configuration.TemplateFlags` include `Stats`
  takes its level from its `Template`, so the level on its own row is not the one the game uses — the column the
  bulk skill never mentioned and the control found unaided — and `to_file=` states the artifact manifest's own
  accounting and the `row_count == total` check that says the file holds a complete result.
  `housecarl_copy`'s `new_editorid=` says a clone carries an NPC's inline face values by construction, so no
  separate write of them is owed, and the tool's own description says to sweep the patch with `housecarl_check`
  off-order once the FaceGen files are placed and that textures baked inside the placed mesh still resolve from
  the source mod. `facegen-diagnostics` cedes a copy and a whole-order sweep to those tools rather than to a
  skill.
- **`facegen-diagnostics`'s compatibility line now spells out Mod Organizer 2.** It read `MO2`; the line now
  matches the string every other skill carries.
- **The Codex umbrella skill is rebuilt as a router, and no longer teaches seventeen tools that do not exist.**
  Its body carried a ~39-line catalogue of the whole tool surface, half of it 1.x names the 2.0 build retired,
  under a sentence promising they "keep working" — a Codex session following it composed calls the server refuses
  by name. The catalogue is gone: what a tool takes is in that tool's own description, which the server injects.
  What is left is what only a router can do — a row per bundled skill saying which job it owns and when to load
  it, the read-before-you-write order with one worked call, the FormID form, and the three write lanes (the
  in-place one is gated by `acknowledge=` at the server, not by prose here). The description is 611 characters
  against the 1,024 ceiling it used to breach, and opens on its trigger. The CI guard that watched this file
  changed direction to match: it used to require every tool name to appear here, which is why it stayed green
  through all seventeen dead names, and now requires every `housecarl_*` name written here to be a live tool.
- **`mutagen-reference` and `papyrus-reference` now say in their frontmatter that their lookup works offline.**
  Both carried only the shared compatibility sentence — the houseCARL MCP server and a configured Mod Organizer 2
  instance — which read as gating the whole skill, including a schema or signature lookup that reads files bundled
  with the skill and never touches the load order. Each now adds one sentence saying the lookup is offline and that
  only what reads the live load order needs them. Which half of each skill is which is stated in that skill's own
  body.
- **The runtime-framework routing no longer names CID, and containers route to SkyPatcher.** The standing
  instructions and the SkyPatcher and SPID skills said items into containers belong to a Container Item
  Distributor; no such skill ships, and SkyPatcher's own container patcher does the job (`filterByContainers`
  with `addToContainers`, in the skill's `references/container.md`), and the SkyPatcher description now names
  containers, so the job is routable from a description alone. The routing now reads: a spell, perk, item,
  keyword, outfit or faction onto NPCs is SPID, best by group — faction, race, level, trait; a keyword onto
  item records is KID; a record's own fields, and an individual NPC, are SkyPatcher. Group and individual are
  a preference, not a capability line: SPID can name one NPC by EditorID or FormID, as
  `spid-authoring`'s `references/filters.md` §1 and §2 show.
- **The published tool schema now marks nested members `required`, and names the write verbs as an `enum`, so a
  client can check a nested call before sending it.** `required` and `enum` were emitted only at the top level of a
  tool's parameters; inside `apply.ops`, `create.records` and the rest, a member the server refuses a call without
  said so in its description alone, and the legal verbs on `ops[].op` were prose beside a bare `string`. Both are now
  published, generated from the shapes the server binds and the verb tables it validates against — `WriteVerbs.All`
  on `apply`, and the create surface's own set (that list minus the verb it refuses by name) on `create`. What the
  tools accept, and every description, are unchanged; a member whose legal values no table holds is left as it was
  rather than given a set invented for the schema. A verb member also accepts an explicit `null` — the server reads
  that as "none given" and uses `Set` — so `null` is in the published set beside the names.
- **An SKSE DLL whose import directory declares an address but no size now reads as UNKNOWN, not as a short
  import list.** The peek walks a DLL's import and delay-import directories bounded by the size the PE header
  declares for each. A directory with a non-zero address and a zero size read as "no such directory": its whole
  table was skipped and the walk still reported success, so what remained rendered as the complete
  `imports (N): …` and the debug-CRT verdict over that list returned a clean bill of health for a build the
  loader would refuse. It is now a parse failure like every other one in that walk, and says
  `imports: UNKNOWN`. A directory with no address at all is still genuine absence and still walks to an answer.
  The same walk had a second silent drop: an old-style delay-load entry that gives an absolute address instead of
  a relative one was skipped, again leaving a short list that read as complete. Its address is now resolved
  against the image base like the loader does, and the read says `imports: UNKNOWN` when it cannot be.
- **An SKSE DLL whose export directory declares an address but no size now has its exports read, instead of being
  reported as a bundled dependency.** The same header shape on the export side failed the other way: the peek
  answered "no exports", so a DLL that does export SKSE's entry points was named a bundled dependency DLL rather
  than a plugin, and its version and runtime-compatibility checks never ran. That walk is bounded by the counts
  inside the directory, not by the header size, so a declared address is now read whatever the size says. A
  directory with no address at all is still genuine absence and still reads as no exports.
- **A `housecarl_records` reverse lookup over several targets says which target each row hit whatever form
  answered it.** `references=["A","B"]` records per match which of the targets it links to, and the scan render
  has always shown that as `matches=`. The forms that read a body per row — `project.form='rows'`,
  `'everything'`, a `fields` read under a `plugins=` scope with a named `source=`, and a `fields` projection with
  a quantified path — render through the batch writer instead, which carried no such column, so the same
  two-target lookup could be un-merged back into per-target answers under one form and not under another. All of
  them now carry it, on text, on json, and in a `to_file=` artifact's rows. A single-target `references=` still
  adds no column, for the reason it never did: there is nothing to un-merge.
- **A polymorphic arm whose value is built by its constructor can now be composed from scratch.** Mutagen models a
  MagicEffect's plain `MagicEffectArchetype` with one constructor, `MagicEffectArchetype(TypeEnum)`, and no
  parameterless one, so `compose={"type": "MagicEffectArchetype", "fields": {"Type": "Script"}}` was accepted by
  pre-flight and then threw at apply — a Script-archetype effect could be had only by forwarding one that already
  existed. A compose now builds such a type from its own `fields`: a field naming a constructor parameter (matched
  without regard to case, so `Type` supplies the `type` parameter) is passed to the constructor and not set again
  afterwards. `ctor_args` still supplies the same values positionally. A compose that names none of them is refused
  before anything is written, naming the field to add and listing the type's constructors — as is the same value put
  in a nested `sets` entry, which runs against the already-built value and so cannot reach the constructor.

- **A compose that names a field it cannot write is refused before anything is written.** A read-only field named in
  a compose's `fields` — a condition arm's `Function`, an archetype's `AssociationKey`, and the discriminator of any
  arm that fixes one — passed pre-flight and then threw mid-apply, reported as an internal inconsistency. It is now
  refused up front, in the same words a Set on that field gets: the value is fixed by which arm was named, so drop
  the field or name a different arm. A field the type's constructor carries is still accepted, because that is the
  one the constructor writes.
- **`max_chars=` is now a ceiling on the last five `housecarl_records` text renders too.** The comparison forms
  `delta` and `tree`, the walk lane's `chain` and reverse effect-chain renders, and `info_order` tested the
  ceiling before the record, node or delta line they were about to write, so the block that crossed it went in
  whole and the truncation notice and the `spilled:` block on top of that — the shape the other renders lost in
  the change above, which named these five as the ones it did not cover. They now carry it: the notice and the
  spill block are charged before the first record is laid, every inner list holds back the room its own cut
  notice takes, and a record that would cross what is left is taken back out whole and counted. A record cut
  inside itself stays, with the cut named where the caller can see it; where there is no room even to say a
  section was cut, the whole record goes back out rather than ending in silence. Those reserves are room for
  notices a complete render never writes, so they are charged only where the whole render does not fit: an
  answer that fits inside the `max_chars` you passed comes back complete, uncut and unspilled. A `counts_only`
  census is held to the ceiling as well: it carries the header's source and selection statements whatever the
  budget, so at a `max_chars` it cannot fit in it names the number that clears it instead of coming back over
  the cap saying nothing. The `max_chars=` parameter now states the ceiling over the whole tool. As everywhere else, the result is
  untouched: what the ceiling holds back inline is complete in the artifact the response names.
- **The KID authoring skill now measures what a line reaches before the file is written.** Composing a
  `_KID.ini` gained a grounding step: the type-plus-trait predicate is counted with `housecarl_records`
  (`types`, `where`, `counts_only=true`), the count is reported with the call that produced it, and a
  census of zero — or one the user did not expect — stops the line rather than shipping it. The skill
  states the bound on that check: it proves one predicate, not KID's own evaluation order or `chance`.
  The skill also states which record field a KID trait tests is the schema's answer and points at
  `housecarl:mutagen-reference` for it, corrects the filter and trait section numbers in its grammar
  reference (filters are section 2, traits section 3), and drops a reference pointer that the packager
  deleted from every shipped copy.
- **The `mutagen-reference` skill is rebuilt against the 2.0 tool surface.** It named four tools that no longer
  exist — `housecarl_set_field`, `housecarl_bulk_apply`, `housecarl_create_record` and `housecarl_read_record` —
  so an edit composed from it spent its first call on a retired name, which the server answers with a redirect
  to the successor rather than with the edit. Addressing a field now names `housecarl_apply`'s `field_path` and
  the `op` verbs each cardinality accepts, authoring a record is `housecarl_create`, reading one is
  `housecarl_records`, and taking a field's value from a plugin you name rather than from the load-order winner
  is `op='CopyFrom'` with `from_source`. The body is about a quarter shorter and names every file it ships under
  `references/`, each with the condition to open it, so the route from the body to a schema block no longer has
  an undeclared leg. Two things it taught that were wrong are gone: the Mutagen version it pinned, which nothing
  in the skill maintained — the reference regenerates with the library, and the warning for an absent type now
  says so without a number — and the claim that giving a parent a child record, or dropping one, has no home.
  `housecarl_create`'s `parent` and `housecarl_remove`'s `formids` both express it; what stays is the narrower
  rule, that a write at a sub-struct field holding an owned child record is refused and the child is edited by
  its own FormID. The shards
  themselves are unchanged: they are still generated by construction from the record library.
- **A SkyPatcher INI can be checked before it is placed in a mod.** `housecarl_records`'s overlay pole takes a
  draft file: `source={"overlay": "skypatcher", "state": "post", "ini": "<absolute path to a draft .ini>",
  "subfolder": "weapon"}` reads the record as the game would see it once that draft is placed — the live layer
  plus the draft, sorted into its type folder by filename among the live files. `subfolder` may be omitted when
  the draft's parent directory is already the type folder, and the response says the folder was taken from
  there. The same pole is legal as `versus=`, so the draft's post state against the plain post state is the
  draft's own effect and nothing else. An undocumented subfolder, a draft whose filename is already placed in
  that folder (which would shadow or be shadowed depending on mod order), and `state: "pre"` with a draft are
  each refused by name — as are a draft that is itself one of the layer's placed files, whose lines would
  replay twice, and `ini`/`subfolder` passed on a `{"file"}` pole, where they would otherwise be dropped and
  that plugin's own record would read as the draft's post state. A refusal is the call's on every form the
  pole takes, so `counts_only` cannot report it as an error count with the reason nowhere.
  The draft rides the `formids=` lane; the scan lane still refuses an overlay pole for
  the reason it already gives. Like the rest of the INI layer, a draft sits outside the epoch fingerprint, and
  the response names it on the source arm. Every warning the replay produces for a draft's line — an unknown
  key, an op with no field mapping, a filter it cannot evaluate — now renders beside the answer with the
  draft's path as the file name, as it does for a placed INI's lines, on every form that takes the pole.
  A draft SkyPatcher would not read once placed — one whose filename gates on a plugin that is not in the
  order, or one in a type switched off in `SkyPatcher.ini`'s `[Patcher]` section — applies nothing, so the
  post state is the plain winner and the response says which of the two it was.
- **The `skypatcher-authoring` skill is rewritten, and it now checks a draft INI before you place it.** Its
  verify step named a tool that does not exist (`housecarl_skypatcher_read`), so following it produced a failed
  call; the step now uses `housecarl_records` — the target set and every address proved before a line is
  written, the draft file read through the overlay pole's `ini` draft form, and the placed file checked with
  `housecarl_skypatcher_layer` and `housecarl_skse findings='config'`. The record-type router moved out of
  `references/index.jsonl` and into the skill body, so every reference file is one hop from it; the reference
  files are flat under `references/`, the file-and-folder half of the grammar reference is now its own
  `placement-and-conflicts.md`, and the four worked examples carried over from the source articles with the
  wrong record type's filter are marked as such where they sit. The description states the SkyPatcher version
  the grammar is derived from and that distribution — forms onto NPCs, keywords onto items, items into
  containers — is a different framework's job.
- **The `dialogue-authoring` skill is rebuilt against the 2.0 tools.** Every call it teaches is one that
  exists: `housecarl_create`, `housecarl_apply`, `housecarl_records`, `housecarl_check`, `housecarl_remove`.
  The commonest job — one line into an existing topic — is now the first thing it says and takes two calls,
  because `parent` resolves an existing topic's FormID. Three facts it had wrong or missing are corrected:
  the first-condition-wins rule holds for a topic whose lines are told apart by their conditions and is
  scoped away from generic greetings, where how the engine picks is stated as unknown; the merged INFO order
  is read with `housecarl_records project={"form":"info_order"}`, not from a check; and `Speaker` must be set
  in the create call for the `.fuz` path to be computed. The dialogue check needs the plugin enabled first
  (issue #615), so the skill names the off-order `errors`/`scripts` sweep as the pre-enable substitute rather
  than claiming coverage it does not have. The player-topic semantics and the write-side recipes move to
  `references/`, and the body is half its former size.
- **Three skills are removed: `biped-slot-reference`, `papyrus-optimization` and `tool-output-awareness`.**
  Eleven skills ship now. `biped-slot-reference` said slot N is `FirstPersonFlags` bit N−30; the server's own
  output already decodes a `BodyTemplate.FirstPersonFlags` value into its slot numbers, so that fact stays.
  `papyrus-optimization` leaves nothing behind — its script-cost review was no better than the review you get
  without it. `tool-output-awareness`'s rule — never copy a record or asset path a generated tool re-derives —
  and its list of the plugins that produce them move into the server's own instructions, which every session
  reads (a separate change in this release), so it now holds for a copied NPC without any skill being loaded.

- **`papyrus-reference` no longer gates an SKSE-plugin function on a DLL filename, and its corpus reads
  cleanly.** The index's `requires_plugin` is now stated as an indicative hint: the filename it carries differs
  between builds (`PapyrusUtilSE.dll` against an AE install's `PapyrusUtil.dll`), so matching it against the
  load order refused a plugin that was present and working. The availability question goes to `housecarl_skse`
  with `findings='pairing'`, whose own bound — a declaration is not a runtime guarantee — the skill now states
  where it makes the call. The skill also names `housecarl_compile_script` as the check behind "never invent a
  signature", carries the eight silent-biter rules in its body behind the conditions that should send you to
  them, and says outright that base-class events on `Form.psc` are missing from the corpus, so a miss there is
  reported as a hole rather than as an absence from Papyrus. The tier itself is now read off a row's `source`
  rather than off the presence of `requires_plugin`, because several SKSE-plugin sources carry that key on no
  row and reading its absence as vanilla reported a third-party function as always installed. The lookup greps
  the index case-insensitively — Papyrus is case-insensitive, so a call site's `Debug.notification` missed the
  corpus's `Notification` and read as absence — and breaks a `qualified` tie on `source`, preferring the SKSE
  row and saying so when the two declarations differ on whether a parameter is required. In the corpus itself,
  32 vanilla files that carried no entry are gone, and every reference file over 100 lines gained a
  `## Contents` table listing only headings that head a section, with the index's line ranges re-derived so
  every lookup still lands on its own block. The skill states that bound where it describes the fallback read,
  along with the two hand-authored files that no index row reaches.

- **`facegen-diagnostics` leads with the mesh-versus-tint pair diff, and drives the 2.0 tools.** The flow now
  opens by resolving the head `.nif` and the face `.dds` for one NPC in a single `housecarl_asset_status`
  call and branching on the two winners; the record comparison it used to open with is the second step,
  reached when the pair is clean. Five tool names the old body named do not exist on this server, and the
  reads and writes it drives are `housecarl_records`, `housecarl_apply`, `housecarl_place` and
  `housecarl_forward`. A console-printed FormID is no longer a dead end: the read tools take the runtime
  form, though a console click still selects the placed reference rather than the base actor, and
  `housecarl_apply` refuses the runtime form. The mesh-side repairs move to a second bundled reference,
  the whole-order sweep is one spilled `housecarl_records` call, and `housecarl_check` has no facegen finding
  family — the body says so where the sweep is described.

- **Setup now removes skill folders a previous install left behind, and says which ones.** It used to copy over
  an existing install without deleting anything, so a skill dropped from the package survived the upgrade and
  kept loading. `~/.claude/skills/housecarl/skills/` is houseCARL's own, so anything there that this package
  does not ship goes. `~/.agents/skills/` (the Codex location) is shared with other agents' skills, so setup
  takes back only the folder names it recorded installing — and it starts recording them in this version, which
  means a Codex install made before it still has `biped-slot-reference/`, `papyrus-optimization/`,
  `tool-output-awareness/`, `bulk-record-jobs/` and `npc-appearance-copy/` there; delete those five folders by
  hand once. Removing a folder is cleanup, not
  part of the install: one that will not delete — a read-only file inside it, a file open in an editor — leaves
  the install to finish and register as usual, and setup names the folder at the end for you to delete by hand.
  A package with no `skills` folder at all is a broken download, not a version that ships no skills: setup
  refuses it rather than reading it as "remove every skill installed".
- **The standing instructions now carry three cross-cutting facts, and nine parameter descriptions say what
  they were missing.** The instructions every session is given state which runtime framework owns a job
  (SPID / KID / CID / SkyPatcher), that nothing houseCARL writes wins until the mod is enabled in MO2 — a new
  mod folder loads last, while a write into an existing mod keeps that mod's priority and may still need
  sorting — and that generated output — a Reqtificator, DynDOLOD, ParallaxGen, Synthesis or xLODGen product —
  is never copied into an authored patch, while a mod that only carries a generator's name (a "… Resources"
  or "… Fixes" companion, a downloaded patch) is an input and is patched normally. The parameters gain the
  semantics they alone can state: `housecarl_apply`'s
  `ops=` on what `Remove` clears, on the cardinality pre-flight, and on `from_source=`; `housecarl_forward`'s
  `source=` on forwarding from the authored plugin when a generated one wins; `housecarl_create`'s `records=`
  on the Creation Kit bookkeeping it auto-fills; `housecarl_check`'s `findings=` on the dialogue family
  flagging rather than rewriting; `housecarl_records`' `where=`, `project=` and `fields_source=` on the
  FormLink wire token, the flag `has` test, aggregate's uncapped count and the scoped-versus-winner display
  pole; and `housecarl_write_seq`'s `into=` on the byte-identical skip its `output_dir=` sibling states. The
  two read-back parameters now carry the same enabling sentence the instructions do, bound and all: a new mod
  loads last, so enabling is the step, while a write into an existing mod keeps that mod's priority.

- **The Codex umbrella skill now ships under a `skills/` root in the package.** In the release zip it is
  `houseCARL/codex/skills/housecarl/` where it was `houseCARL/codex/housecarl/` — the shape Codex expects, a
  skill directory that is an immediate child of `skills/`. The installer places it in the same place it always
  did (`~/.agents/skills/housecarl`), so an install run from `houseCARL-Setup.exe` is unchanged; a copy taken by
  hand out of the zip comes from the new path.
- **`housecarl_decompile_script` now reconstructs a short-circuit (`&&` / `||`) whose value is a call argument
  followed by another argument.** The arguments after it evaluate before the call, so the false-path jump lands on
  the next argument's first instruction rather than on the call itself; the reader took only the jump-lands-on-the-
  consumer form, read the rest as a plain `if`, and promoted the condition temp to a named local — which then made
  a later arm of the same expression emit statements and fail the whole function to a raw-bytecode comment block.
  The expression now comes back whole, and because the CK compiler itself emits this form, the optimizer-compiled
  ("Caprica class") note it used to trigger no longer fires on it. An arm that genuinely evaluates a statement
  still fails loud, and the failure now names the statement.
- **`housecarl_create` in place now refuses an editorid the target plugin already defines, instead of re-creating
  that record.** A create whose editorid collides used to rebuild the existing record fresh at its own FormID from
  the call's spec, discarding everything else it held — and reported it afterwards, once the record was already gone.
  In place the file is one you own and the name is likelier one you did not know was taken, so the whole call is now
  refused before anything is written, naming each colliding record, its FormID, and its type. An interior cell is held
  to the same check, which its own duplicate guard was not: that one saw only other cells, and only an exact-case name. Pass `replace=true` to
  get the rebuild anyway — over a collision an overwrite can settle; a name the target holds on a record of another
  type, on two records at once, on an override it carries, or on a record with child records under it (a dialogue
  topic's lines, a worldspace's cells, which a rebuild would take with it) is refused either way, and the refusal says
  so instead of offering `replace=`. `replace=` is refused off the in-place lane, for the reason its own description gives. The `into=`
  lane is unchanged: regenerating a houseCARL patch re-creates its own record at a stable FormID, which is what makes
  a re-run idempotent.

- **A `housecarl_records` `formids=` read is now held to the render bound on every form that reads a body, and
  says what those bodies cost.** `summary` and `aggregate` read a body per id on this lane exactly as `fields`,
  `rows` and `everything` do — one cheap leaf off each — but only the last three were measured against the bound,
  so a list that refused as `fields` ran unbounded as `summary`. All five now refuse on the same numbers, which the
  `limit=` parameter states along with the levers this lane has. And the response reports the rows it read and the
  milliseconds they took, on text and json alike. That count is the bodies actually READ, not the `limit=`/`offset=`
  window's rows and not the list's length: the ids are read before the window applies, but an id a named `source=`
  pole holds no version of, and a malformed id, refuse without a read — so a long list over a small pole reports the
  handful it read rather than dividing the clock by rows that cost nothing.

- **`project.form='identity'` is bounded too, at 40,000 FormIDs, and says what it cost.** It reads a body like the
  other five, and by the dearest route the tool has: the resolver has no record type to seek the winner by, so each
  id costs an untyped whole-plugin scan — measured at 12.5–14 ms a FormID over 3,000 ids on a 3,801-plugin order,
  against 0.05–0.07 ms for the same ids read as named fields. So it gets its own tier rather than the named-fields
  one, and its refusal names `form='summary'`, which answers the same type/editorid/winner question off a read
  gathered per plugin instead of a seek per record.

- **A `housecarl_records` walk with `counts_only=true` is bounded like its render, and the refusal says why in the
  words of the call that got it.** A walk hands its reached set to the `formids=` lane, which reads a body per id
  before it counts anything, so exempting the census left a wide walk — `walk={"max_nodes": 500000}` with a body
  form — measured by no bound at all. It now refuses on the same numbers the rendered walk does. A census renders
  nothing, so it is told what it counts and that the bodies are read before they are counted, and its lever is the
  walk (`walk.depth`, `walk.max_nodes`, fewer seeds, or `project.form='chain'`) rather than a `limit=`/`offset=`
  window over a render it never asked for. Same on a `formids=` census.

- **A write refusal labels the element in the member you wrote.** A refusal on an inline `housecarl_apply` op named
  `op[i]`, and a malformed FormID in `housecarl_forward` or `housecarl_remove` named `formid[i]` — members no
  houseCARL 2.0 tool declares, so the handle each gave you to fix pointed at nothing in the call. They now spell
  `ops[i]` and `formids[i]`. Both altitudes that can refuse an inline op are covered: the tool's own `from=` check,
  and the engine's `formid` and `field_path` checks. An op generated by the `bundle=` / `assignments=` copy zip is
  named by the pair and path it came from, as before.
- **A new plugin whose filename would shadow one your order is not loading is now refused.** A new patch name was
  checked only against the mod folders houseCARL owns and the plugins the order loads, so `patch="My Cool Patch"`
  beside someone else's switched-off mod holding `My Cool Patch.esp` minted a second plugin of that name — two
  files that can never both be active — without saying anything. The exact filename a write will create is now
  looked for across every mod folder MO2 knows (enabled, switched off, or not yet listed), the overwrite folder and
  the game's `Data` folder. The refusal is one sentence naming where it found it — the mod folder, the overwrite
  folder or the game `Data` folder — and the file inside, and it gives both readings: pass a name nothing on your
  install already uses, or enable that plugin and target it if it is the one you meant. A name you chose is never
  auto-suffixed around the collision, so a suffixed patch can no longer hide the file you may have meant.
  `housecarl_merge_plugins` is checked on its `output=` filename. `housecarl_create_plugin` is checked on
  `plugin_name=` as a BASENAME — a foreign `.esm` or `.esl` of that name refuses too, on the same ground its
  active-order check already refuses all three: a header-only trigger resolves by basename. Three things are
  unchanged: a plugin the order IS loading still gets the name auto-suffixed; a name houseCARL picked or derived for
  you still steps to the next suffix rather than failing the call, which includes the `new_editorid=` a
  `housecarl_copy` with no `patch=` falls back to; and the tools that write scripts, an archive, a mesh, loose files
  or a `.seq` are not affected, because they put no plugin on disk. `housecarl_compact_plugin` is not affected
  either — its output deliberately keeps the source's exact filename so the masters still resolve. The check runs on
  a fresh write, never on an `into=` extend, and not at all on a profile that names no mod at all (a missing
  `modlist.txt`), where an enabled mod folder and an unregistered one cannot be told apart.

- **A `housecarl_records` walk over a big selection now runs, where it used to die with an internal
  out-of-memory error.** Reading each seed's and each reached node's body walked the whole winning plugin
  looking for that one record, so the call's cost was the number of seeds times the plugin's record count: a
  template-chain walk over one large mod's NPCs ran the server out of memory. Every seed now advances one hop
  at a time and the hop's bodies come from one pass per source plugin, so a walk costs what its seeds cost.
  The one-call shape — a scan-scoped selection feeding `walk=` — and the two-step shape (`to_file=`, then
  `formids=["@<path>"]`) now both pay that, and neither is a workaround for the other. What a walk reaches is
  bounded by its own node budget, described on `walk.max_nodes`, and a seed that has spent that budget now reads
  nothing further. Any reading form that renders the reached set — `summary`, `fields`, `rows`, `everything`,
  `aggregate` — refuses up front when the set is too big to render, on the forward walk and on both reverse walks,
  naming that lane's own levers: its seeds, `walk.depth` and `walk.max_nodes` where they move it, and
  `project.form='chain'` on the two lanes chain can draw. `chain` reads no body per rendered row and is not held to
  the bound, though the walk itself still reads one per reached node whatever the form. A cancel sent by the client
  stops a walk between hops.
- **`max_chars=` is now a hard ceiling on `housecarl_records`, `housecarl_asset_status`,
  `housecarl_nif_inspect`, `housecarl_place` and `housecarl_skse`, not a test taken before the item that
  crossed it.** These renders used to check the budget and then write the next record, path, mesh or row
  whole, and to append the truncation notice, the accounting line and the `spilled:` block on top, so a
  response could come back several hundred characters past the number the caller passed. Everything written
  below the rows is now charged before the first one is laid, and an item that would cross what is left is
  not written at all: the notice says how many were held back, and one item wider than the whole budget is
  named with the `max_chars` that clears it in one step rather than dropped, wherever in the list it falls. That
  number is measured against the widest form of what did not fit, so a render whose width grows with the budget —
  a mesh's `sections=`, an alarm list that was itself cut — still clears in one raise. Every notice a
  `housecarl_skse` answer writes quotes the `max_chars` you passed, not a number short by its footer. Where a
  window put no row on the page at all, the accounting names both the cap to raise and the `offset=` that steps
  past the row that did not fit, which is the only knob that moves that case. A `housecarl_records` result the
  ceiling cuts still spills COMPLETE to its artifact — the ceiling bounds the render, never the answer. On
  `housecarl_records` this covers the scan, batch, resolve, `group_by` and `summary` renders. The other case that can come
  back over the cap is a `max_chars` too small for what a response carries whatever the budget — its header,
  the alarms it owes, its accounting — and it now says so in a sentence naming the number that clears it,
  which is how you can check. An alarm is never dropped to meet the ceiling: an archive that failed to read is
  said whatever the budget. Each tool's own `max_chars=` parameter says what its ceiling covers.
- **A `housecarl_records` scan now says what its render cost, refuses a render too big to finish, and stops
  when the client sends a cancel.** Reading a record body per rendered row used to walk the whole winning
  plugin for each one, so a projection of a few fields over a big selection could run for tens of minutes with
  nothing coming back; the bodies are now gathered a plugin at a time — on the scan render and on the
  `rows`/`everything` body lane alike, each plugin walked only for the rows the render actually shows — and the
  same catalogue renders in a fraction of the time. Every `fields`/`rows`/`everything` scan reports the rows it
  read and the milliseconds they took, on every transport including `to_file=`. A render too big to finish
  refuses up front — on a scan, on an off-order `source=` and on a `formids=` list alike — saying whether to
  name fewer fields, narrow the scan terms, pass fewer ids, take windows with `limit=`/`offset=`, or write the
  whole set with `to_file=`; the bounds — one per form, because a whole-record row costs two orders of
  magnitude more than a named-fields one — and the caveats that decide between the shapes are on the `limit=`,
  `offset=` and `to_file=` parameters. A cancel sent by the client now stops the work inside one record instead of leaving
  the server running, and a `to_file=` call stopped that way writes no artifact at all rather than a partial
  one. A client that stops waiting WITHOUT sending a cancel is not something the server can detect — nothing
  in the protocol reports it — which is what the render bound is there for.
- **A field inside a record that cannot be read now says so, instead of rendering as absent.** Reading a
  record deeply (`project.depth` of 2 or more) dropped the line for any sub-field whose read threw — what a
  truncated or badly merged plugin does to one field — so a field that could not be read looked exactly like
  a field the record does not carry. It now renders as `(unreadable: <reason>)` on its own line, naming the
  sub-field and Mutagen's own reason, and the fields beside it still read. `delta` and `tree` name it too:
  an unreadable field is reported as not compared, with the reason, and leaves the comparison incomplete, so
  a record carrying one is never called `identical`. The rest of that record still compares — only the
  unreadable path and the list it sits in drop out — and such a record is counted as neither differing nor
  identical but under its own `no_verdict` count.

- **Every tool description now fits inside the 2,048 characters Claude Code shows, and the grammar that was
  being cut off lives on the parameters it belongs to.** A description longer than that cap lost its tail on
  the way to the model, so predicate languages, source and comparison rules, refusal lists, projection forms
  and transport rules were being described in a part of the text nobody read. Twelve tools were over it —
  `housecarl_records`, `housecarl_apply`, `housecarl_check`, `housecarl_create`, `housecarl_copy`,
  `housecarl_forward`, `housecarl_merge_plugins`, `housecarl_nif_inspect`, `housecarl_nif_set`,
  `housecarl_compact_plugin`, `housecarl_place` and `housecarl_remove` — and each came under it in its own
  change. The grammar moved rather than going away: each piece landed in the description of the parameter it
  is about, which the client delivers whole however long it is — and where a description stated a rule wider
  than the code enforces, it was corrected to what the code does on the way. What stays in a tool description
  is what belongs to no single parameter: what the tool is for, the one-call composition rule, a line per axis
  naming its parameters, and the pointers to the sibling tools. `PublishedDescriptionBoundTests` holds the
  bound on the published tool list from here on, with nothing exempt, so a description cannot grow back past
  the cut without going red.

- **`spid-authoring` now covers checking that a distribution reached a live actor.** A parsed
  `_DISTR.ini` and a clean SPID log show what SPID looked up, not what an NPC received. The skill's new
  "Verifying a distribution actually happened" section says what to assert instead: SPID does not
  distribute to the player, a rule added mid-session needs a game restart because the INIs are read once
  per launch, a `Chance` below 100 or a Level Filter can skip a sampled actor by design, and a keyword
  SPID creates at runtime has no plugin FormID but is still found by name from a script. The reference corpus carries the same facts with their source. Reported and drafted by
  juggernaunt46-star (#384).
- **`housecarl_copy` names the MO2 mod folder each source resolved from, and `housecarl_copy_npc_appearance` is
  gone.** The copy readback prints the folder beside each source's plugin filename — `Donor.esp (MO2 mod folder
  "TheDonorMod")`, in double quotes, the one delimiter a Windows folder name cannot contain — so the following
  `housecarl_place` can be given the folder that actually holds the FaceGen. It is the folder name, not a path, and
  it is the name `source_provider=` takes; a source read through an override lists both arms, and the file usually
  sits beside the second. A named plugin that is ENABLED names its folder too — `Donor.esp (from the active load
  order, MO2 mod folder "TheDonorMod")` — because the placement needs it whether or not MO2 ticks the mod; only the
  bare `winner` pole is the whole order and names none. One that came out of
  MO2's overwrite or the game's `Data` folder is named as that layer rather than as a mod; a source read from a
  file outside all of them says it has no mod folder to pass on; and a real mod folder whose own name is `Data` or
  `overwrite` is named and then withdrawn in the same sentence, because those names are reserved and a placement
  handed one reads the layer instead of the mod. The 1.x standalone-appearance tool is deleted: the same job is `housecarl_copy` for the
  records (`seed_paths=`, `exclude_types=["Race:refuse"]`, `from_source=` as an ordered list) and
  `housecarl_place` for the FaceGen pair, which is the shape the `npc-appearance-copy` skill teaches. Calling the
  old name answers with that two-call shape rather than an unknown-tool error. The old tool's `new_name=` has no
  successor parameter: a clone carries the donor's display name until you set it, which is an op on `Name` in the
  same `housecarl_apply` call that copies the tint bundle.

- **A response answered off an order that lost plugins to a load failure says so.** When a plugin cannot be
  opened or parsed it is excluded from the index build, and reads after that answer off the narrowed order —
  shallower override depths, fewer touching plugins, sometimes a different winner. The epoch stamp changed, but
  a legitimate reorder changes it too, so the two were indistinguishable inside one response unless the call
  happened to name the failed plugin. Every response now carries `order_degraded: true` and one sentence saying
  how many plugins are missing, which ones, that this is a load failure rather than a reorder, and that
  `housecarl_load_order_status` gives the reason for each; the text lane appends the count beside `epoch=`.
  It does not guess whether you caused the failure — a plugin Mutagen cannot parse is not your doing, while one
  that cannot be opened usually is (the mod is off but `plugins.txt` still lists it), and the status tool says
  which applies per plugin. It rides
  beside the epoch, never inside it, so two builds that differ only in health still compare as different builds.
  A healthy order carries nothing. The sentence names up to ten plugins and counts the rest —
  `housecarl_load_order_status` lists them all. `housecarl_check` states the sentence once, at the top of the
  response, so a dialogue-only check says it too; each family carries the flag and the plugin count beside its own
  `epoch`, the same fact its text head states.
- **`housecarl_records` walks the reverse direction to any depth.** `walk={"direction":"reverse","depth":N}`
  under a reading form now answers "what points at the seeds, and what points at that" — every link at every
  hop, off the reverse-reference index, with no bounding `types=`/`plugins=` scope; the depth>1 refusal is gone.
  The response names the count reached at each hop, empty hops included, and says which hops it did not need to
  walk, so a walk that ran out of referrers reads as exhausted rather than as a silent stop. The index's own
  accounting — the one-time build cost, its per-plugin freshness key, and any plugin the walk could not read —
  rides this lane exactly as it rides `references=`. The reached set is verified against the body the walk
  judges — the load-order winner — so a record whose winner dropped the link is not reported and not expanded,
  and the walk and `references=` answer the same question the same way; the response says how many index
  candidates that check dropped, and names each cause with its own count — a winner that does not carry the
  link, a winning plugin that could not be read (a coverage gap, not a verdict), a deleted winner, or no
  resolvable winner — counting each record once however many hops name it. One record that cannot be read
  costs that record, never the walk. A hop the `walk.max_nodes` budget ended is marked as cut rather than
  reading as a hop that reached nothing, and a walk that stopped because it reached `walk.depth` with records
  still to expand says so instead of reading as a complete answer.
- **`walk.follow` is legal on `direction='reverse'`, and it is what picks the reverse walk.** `follow` names
  the edges a walk crosses, backwards as well as forwards: unset or `"*"` is the transitive walk over every
  link, `follow="Effects[].BaseEffect"` is the typed MGEF carrier walk (per-carrier magnitude/area/duration,
  `types=` narrowing the carrier types), which follows the effect link at every hop and so reaches nothing past
  hop 1 — said out loud when a depth was asked for. The form then only picks the view, as it does forward:
  `'chain'` renders the walk's rows and a reading form consumes the same reached set. No default `follow`
  implies a walk under any form: `form='chain'` on a reverse walk with `follow` unset now refuses and names
  both follows the index can serve, and says that `chain` has no per-seed path to draw for the transitive
  walk; `form='chain'` with `follow="*"` refuses as before. A reverse `chain` call — including the one the
  retired `housecarl_effect_chain` redirect teaches — therefore says `follow="Effects[].BaseEffect"`. Any
  other `follow` on reverse refuses naming the two the index can serve. A seed the carrier walk could not read
  is named under a reading form too, not only under `chain`, so an answer covering some of the seeds never
  reads as one covering all of them. `walk.max_nodes` says which reading it spends: per seed on the carrier
  walk, one shared budget across every seed and hop on the transitive walk.
- **`housecarl_records` reads the quantified step in `project.fields`.** `where=` has taken `[*count]` and the
  boolean folds for a while; the same tokens are now a projection. `project.fields=["Effects[*count]"]` renders one
  number per record — how many elements the list holds — and `["Effects[*]"]` one row per element, in the same row
  shape `project.form='rows'` produces; a sub-path after the token (`"Effects[*].Data.Magnitude"`) renders that leaf
  per element instead. Under `format='dense'` the extra rows repeat the record's identity columns, and an
  unquantified column repeats its own cell beside them. `[*any]`/`[*all]`/`[*none]` fold to a boolean, which is not
  a row, and stay refused here by name. A quantifier on a step that is not a list fails that record with one
  sentence naming the path, what the step actually holds, and the two ways to read it. An EMPTY list answers with
  its own summary line under the caller's spelling, so it can never be mistaken for a path that was not asked for,
  and a read the engine cut short says so beside the shortened rows. Under `format='dense'` a row is keyed by the
  element's own key — its index in a positional list, its dict key in a dict, so a package's `Data` arms keyed 2
  and 7 are two rows and not eight — and a sub-path an element does not carry leaves that row's cell empty rather
  than shifting the next element's value onto it. The ceiling is checked per row, `rows_rendered` counts them, and
  two different lists in one call are refused by name, since one row cannot be an element of both.

- **The dialogue check stamps the build it read, and says what that stamp does not cover.** `housecarl_check
  findings=["dialogue"]` was the one family answering with no freshness claim at all. It now carries `epoch` — the
  record build every seed was validated against, one pinned build for the whole call — beside
  `epoch_covers_all_inputs: false` and `epoch_uncovered`, which names the verdicts read off disk rather than off the
  record index: voiced lines (.fuz on disk), the result-script .pex chain, and .seq coverage and staleness. The text
  render states the same stamp and the same three classes on its own line. Compare two responses' `epoch` to know
  whether the record half changed between them; the named classes are outside that comparison. A call whose every seed
  was a dialogue view (DLVW) or branch (DLBR) reads nothing off disk, so it stamps `epoch_covers_all_inputs: true` and
  names no classes. A dialogue-only call refused because every seed was unresolvable carries the bare `epoch` — the
  build it was decided against — as the errors and scripts families' post-index refusals do; a call with no `seeds=` is
  refused on the arguments alone before any build is read, and names none, as theirs do not.

- **`housecarl_asset_status` and `housecarl_place` take `format='json'`.** Both answered text only, so a caller
  reading them from a script parsed prose. The json document carries the same data as the text render: for
  `asset_status`, the build-level caveats, one row per path with its winner and full provider chain, and the same
  eight accounting counters the text line states, under one `accounting` object; for `place`, the same
  `accounting` object plus `placed`/`failed`, one row per destination with its source and the
  current VFS winner, and the "a placed file does not win until you enable and sort the mod" step in band. A
  provider is `{name, kind}` — the name alone is what `place`'s `source_provider=` takes, so nothing has to be
  parsed back off the printed token. A whole-call refusal answers a json caller as a document, and a document
  that hits `max_chars` drops trailing rows, stays valid JSON, and says so — `max_chars` bounds the build-level
  caveats as well as the rows, each of which carries a `<name>_omitted` count of what was cut, and the first row
  always renders, so a small `max_chars` still answers the path that was asked about.

- **`housecarl_place` no longer tells you to sort above a winner it did not name.** When `max_chars` cut every row
  that had a current winner, the enable-and-sort step still said "above the current winner(s) listed above" while
  the render listed none. It now says the rows were cut and to raise `max_chars` to see which mods they name.

- **`housecarl_merge_plugins` now carries a donor's light (ESL) flag onto the merged plugin where it is valid to.**
  The flag is carried when every donor was light and every merged object id landed inside the light window
  `0x800–0xFFF`; the report says the output is light, so it need not be opened to find out. Otherwise the flag is
  dropped and the report names which of the two conditions failed — a full donor in the set, or a merged id outside
  the window — and then says whether `housecarl_compact_plugin` can still make it light: it can, by renumbering every
  id into the window, unless the merged plugin defines more records than that window holds, in which case the report
  says compact would refuse rather than pointing at it. Master (ESM) status and the header Author/Description are
  still never carried, and each drop is still stated.
- **`housecarl_load_order_status` reports a plugin's LOCALIZED header flag** when `lookup=` names a plugin, active or
  inactive (a mod folder has no header and gets no line). A localized plugin's text lives in separate `.STRINGS` files, which is what an in-place
  write to it is refused over, so the refusal is visible before a job runs into it. Three answers, not two: a header
  houseCARL could not read is reported as unknown rather than as "not localized".
- **`housecarl_asset_status` prints provider names the way the rest of the asset surface does** — inside double
  quotes, a character a Windows folder or file name cannot contain, with `(loose)` / `(BSA)` outside them. A mod
  called `Face Extras (SE)` now reads back whole, and the printed token is the token `housecarl_place_asset`'s
  `source_provider=` accepts.
- **A record that owns exactly one child can now be given one, and an owned child can be deleted.** A cell's
  terrain (`Landscape`) and a worldspace's top cell are single owned child records, and neither end of their life
  worked: a cell that carried no terrain could not be given any, because `housecarl_create`'s `parent=` only
  reached child *collections*; and `housecarl_remove` on such a record silently dropped nothing, because Mutagen's
  removal routes by group and a single owned child sits in none. Both now work on the record axis, with no new
  tool: `housecarl_create` with `parent=` and `collection=` the slot's name authors one where the parent has none,
  and `housecarl_remove` with the child's own FormID deletes one. A slot that already holds a child refuses rather
  than overwriting the record that is there — decided from the parent's real record, not from the copy the patch is
  building. A cell under a worldspace has two routes — its single top cell (`collection='TopCell'`), or an exterior
  cell in the block tree (`grid=`) — so that one asks which you meant instead of guessing. A cell authored through
  the top-cell slot is refused when the patch already carries a cell with that editorid, the same refusal the other
  two cell routes give. Deleting a child that
  carries records of its own refuses until you name those too, so the removal report accounts for every record it
  drops. The field-level refusals that used to end at "this is an open gap" now name these calls.
- **Two refusals about a collection element now name the call that works.** Editing one element of a polymorphic
  collection — an AI package's `Data`, a record's conditions, a script's VMAD properties — used to take several
  tries, because each refusal was correct about what was wrong and silent about what to do instead. Reaching
  through an element to a field whose arms disagree on shape (`Data[7].Data`) still refuses to guess the arm, but
  it now prints the container call to make once you have read it: the field's own path, the key you typed, and the
  verbs that collection takes. Bracketing an element at the end of a path (`Data[7]`) prints the same path and key.
  Which verbs get named comes from the collection's own shape, so a dict caller is never offered `SetAtIndex`, and
  a key the collection cannot actually be indexed by (`Data[notasbyte]`) is not handed back as a call to make — on
  the direct/CLI lane too, where the engine raises the same refusal. Every verb named alongside a key consumes it,
  so a list caller who bracketed an existing element is not led with the append that would leave it untouched; and a
  collection whose elements are owned child records (`Cell.Persistent`) is sent to the record axis rather than handed
  a container call no verb takes. Inside
  a `compose=`'s nested `sets`, the path is named in the `path` slot it belongs to rather than `field_path`.
- **`references=` no longer needs a bounding `types=`/`plugins=` scope.** "Who references X" over the whole order
  was refused, so the answer had to be assembled from a scope guess per plugin. It is now one call:
  `records references=["0006BBD3:Skyrim.esm"]`. The first such call builds a reverse-reference index — one
  whole-order link-walk, the same walk the dangling sweep runs (measured on a 3,801-plugin order: 24.4 s, 14.7M
  target→referencer pairs, ~200 MB held) — and the response says what that build cost and carries the index's own
  freshness key. The index is kept per plugin and keyed on that plugin's path and last-write time, so a plugin you
  change rebuilds only its own slice (an unchanged order re-checks in milliseconds), and it is never answered from
  bodies it was not computed from. Nothing else is unbounded: a `where=` or `editorid_contains=` with no scope is
  still refused, naming the bound. A bounded `references=` is unchanged and still cheaper — it builds no index.
  The index is kept for as long as the load order it was built from, including across a plugin being ticked or
  re-sorted in MO2, so that walk is paid once and not once per touch. `project.group_by='type'` composes with it:
  the index hands the scan a universe of records whose bodies are read, which is what names each match's type.

- **The orphan sweep: `references=["!XXXXXX:Plugin.esp"]` with no scope now asks which records nothing in the
  order references.** A negated `references=` under a `types=`/`plugins=` scope is unchanged — records in that
  scope that do not link the target. With no scope at all the universe becomes every record nothing references,
  and the named target then excludes any of those that link it; the response states which question it answered.
  The sweep is refused in combination with `form='delta'`/`'tree'`/`'info_order'`, which would compare every one
  of those records — run it as a plain scan with `to_file=` and re-enter the artifact instead; an in-order
  `source=` plugin is a scope like any other, so a negated `references=` under one is that plugin's records and
  those forms compose with it. Where a plugin cannot be read, the sweep says it is OVER-inclusive by whatever that
  plugin references — a record only it links is listed as an orphan — which is the opposite of what an unreadable
  plugin does to the positive question, and the response says which of the two it is telling you.

- **A path can now step to the record that CONTAINS this one, with `*parent`.** DIAL→INFO, CELL→REFR/ACHR and
  WRLD→CELL ownership is group nesting rather than a form link, so `references=` correctly returns nothing for it
  and the child's own body names no owner — there was no way back from an INFO to its topic, or from a crash log's
  placed reference to its cell. `*parent` is one step on the paths that already exist: `where=["*parent.EditorID =
  GreetingsTopic"]`, `project={"form":"fields","fields":["*parent.EditorID"]}`, and a walk's `seed_paths`/`follow`.
  It leads a path and it chains, so `*parent.*parent` reaches a placed reference's worldspace, and everything below
  the hop — `editorid`, `winner`, `formid` membership, leaves, quantified steps — reads the containing record with
  no separate spelling. `fields=` takes it on every form that reads through the load order, the comparison forms
  `delta` and `tree` included, so the same spelling works wherever `fields=` does bar the out-of-order arm named
  below; and a child-bearing field reached through the hop carries the same "other plugins declare children here
  and this read did not open them" note that reading it on the container directly does, so the two spellings of one
  question cannot disagree. A record a patch DELETED still answers the question — the hop reads its identity, not its
  body — which is the crash-log case exactly, since patches delete placed references constantly. A `*parent` after
  a field step, carrying a quantifier, or with nothing after it refuses by name, in the same words on every surface
  that takes a path; a record nothing contains is stated as such, naming the properties containment runs from,
  never returned as an empty answer; and over an out-of-load-order file (`source=`), where the containment of the
  file's own records was never indexed, `*parent` refuses rather than answering from the active order's map. The
  parent set is Mutagen's own containment walk, captured at index build, so a Mutagen version that adds a
  child-bearing container grows `*parent`'s reach with no further change. Index build costs about 0.3 s more over a
  3,800-plugin order, and `housecarl_load_order_status` now reports how many child records the map holds, so its
  size is stated rather than discovered.
- **A `where=` path step can now quantify a list, so "does ANY element match?" is one call.** Four tokens go in the
  step where the list binds: `Conditions[*any].Data.Function = IsGuard` (some element), `[*all]` (every one, and
  vacuously true on an empty list), `[*none]` (absence, proved — `Effects[*none].BaseEffect->editorid startswith REQ_`),
  and `[*count]`, which yields the number of elements for a numeric or membership comparison (`Effects[*count] > 2`).
  A quantified step composes with the `->` link step and with another quantified step, at the cost the tool
  description declares (per-candidate work times list length, and one winner fetch per element under `->`). The bare
  `[*]` is the element SET and is refused in `where=`, naming the three fold tokens; a quantifier on `editorid`,
  `winner` or `formid` refuses by name, since a record has one identity rather than a list of them; a quantifier pointed at a field
  that is not a list — a scalar, a dict, a raw byte block — refuses the call by naming the step's real cardinality
  wherever `types=` says which record type it lands on, and where the scope cannot say (no `types=`, or a mixed one)
  the scan's accounting names what that step read instead; either way, never a silent non-match. An absent list reads as EMPTY, and so does one whose parent substruct
  is absent, so `VirtualMachineAdapter.Scripts[*count] = 0` finds the records that carry no script at all; where an
  element cannot be judged, the fold reports no verdict rather than claiming one. Reaching a list with a dotted
  segment still refuses, and its remedy now offers the quantified spelling alongside the bracketed index.
  `project.fields` does not take these tokens yet and refuses them by name.
- **`where=` gains the two exclusion folds of `has`, and `references=` gains a negated entry.**
  `BodyTemplate.FirstPersonFlags has_any Head,Hands` is true when at least one operand bit is set and `has_none` when
  none is, beside the existing `has` (every operand bit set). The operand names flag bits — a flag name, a
  comma-separated list of them, or a bit mask (`0xC000`) — never a biped slot number. A `!` before a `references=` entry inverts it —
  `references=["!XXXXXX:A.esm"]` keeps only the records that do NOT reference that target — and plain and negated
  entries in one call compose by AND. The sigil takes the `@file` spelling the plain entry takes, so
  `references=["!@C:/work/targets.jsonl"]` excludes every target a list file or result artifact names. The negated
  form takes the same bounding `types=`/`plugins=`/`formids=` scope the plain form takes.
- **`housecarl_nexus_check_updates` no longer calls a REMOVED file current.** A file the author withdrew
  (category `REMOVED` or `DELETED`) used to fall through the retired-category set and render
  `'name' v1 [REMOVED] — current`, a line contradicting itself. It is now its own verdict, FILE-REMOVED, with its own
  group and its own count in the summary: the row says the file is no longer offered and to read the page for why
  before installing anything in its place. Where a live file with that exact name is still on the page it is named
  as a lead, not as the replacement — and a withdrawn file is never offered as the replacement for a retired one.
  An unfamiliar category is still treated as live and printed as-is, unchanged. The summary counts now read in the
  order the groups print — most actionable first — so the two halves of a report never disagree about what to look at.

- **A plugin edit that leaves the file's timestamp alone is no longer invisible.** The read cache's freshness key was
  the last-write time alone, so an edit landing inside the filesystem's timestamp granularity — or one whose tool
  restored the timestamp it found — served stale parsed state with nothing saying so. The key now carries the file's
  length beside its last-write, and so does the epoch fingerprint, so both the rebuild check and the coverage stamp
  see that edit. An edit that changes neither term is still invisible; the known write-during-rebuild race is
  unchanged, and both bounds are stated at `ComputeEpoch`.

- **Result artifacts written by an earlier houseCARL need re-running once after this release.** The epoch a
  `to_file=` artifact carries is the fingerprint of the build that produced it, and adding the length term changed
  how that fingerprint is computed — so an artifact from before this release no longer matches, even over a load
  order nothing touched. Re-entering one (`formids=@your.jsonl`) is refused as before, but the refusal now says the
  formula changed with the upgrade rather than claiming your load order did; the fix either way is to re-run the
  query that produced the file.

- **`housecarl_check`'s scripts family now sweeps a plugin that is on disk but not in the active load order.**
  A `plugins=` name the order does not hold is located on disk and swept from its own file, exactly as the errors
  family already does it, so a fresh patch's script-property bindings can be checked before it is enabled. Both
  swept families now take one `plugins=` list whole, and each names the file it swept off-order in its own section;
  the response no longer says the scripts family did not sweep it. `exclude=` scopes the off-order file the same
  way it scopes an active one, and the epoch stamp says it does not cover a file located outside the index. Each
  attached script's `.pex` is still read from the active order, so a script that ships only inside the
  not-yet-enabled mod is reported UNVERIFIABLE — the same answer an uncompiled script gets, never a clean pass.
  `format="json"` carries that same caveat as `off_order_coverage`, beside the roster it qualifies.

- **The scripts family now collapses a repeated "could not verify" note.** An unreadable script class produces the
  same note on every record that attaches it, and those notes sit outside `limit=`; a mod whose whole `Scripts/`
  folder is out of the VFS could therefore fill the listing with one sentence and push the unbound findings past
  `max_chars`. The first record carrying a class's note lists it, the repeats are counted, and the head says how
  many were collapsed. The unverifiable total still counts every one of them. A note that names no script class —
  an attachment whose adapter carries no class name at all — is never collapsed: the record is the only identity
  that defect has, so every record carrying one is listed.

- **A `plugins=` name found neither in the active order nor on disk keeps its did-you-mean.** The refusal that says
  both halves now ends with the near-miss suggestion, so a typo or a guessed `.esp`/`.esl` extension names the
  plugin you meant.
- **An `Add` that appends an element the list already carried now says so on that op's line.** It still appends —
  the verb is unchanged — but a duplicating add and a clean one printed the same longer list, so neither the
  response nor the read-back could tell them apart, and a bulk run repeated the duplicate across every record.
  The op line now carries `duplicate: …`, and `format='json'` carries it as `apply_note`; a dry run says it before
  anything is written. `compose=` and `composes=` elements are compared too — a duplicated condition row, container
  entry or leveled-list entry is named the same way, counted over the batch. A `composes=` batch that repeats an
  element of its own says that as its own clause, apart from what the list already carried.
- **A write that grows an existing plugin's master header now emits the same re-sort note on every lane that opens
  one — a create in place or with `into=`, and an apply or forward extending a patch with `into=`.** A record or
  edit whose link points into a plugin the file did not already master adds that master, and the file will not load
  until the order is re-sorted; those lanes said nothing, so the only line about re-sorting was the mod-folder line's
  "only if a winner changed", which is not this case. A dry run of any of them says what the real write would add.

- **A `types=` filter naming one arm of an abstract record group — `GlobalShort`, `GlobalFloat`, `GameSettingInt` and
  every other Mutagen arm — now answers over that arm alone.** It returned the whole group instead: the plugin
  enumeration seeks the record group, which for these types holds every arm of it, and the scans trusted the seek.
  Nothing said the filter had widened, so a count taken over one arm was a count over all of them. This covers
  `housecarl_check_errors` with `type=` too, on an active plugin and on an off-order file alike — its findings and its
  per-plugin tallies were the whole group's, and with a group name resolving to several arms each record was walked
  once per arm. Check an answer you took before this by re-running the same call and comparing the totals; the group's
  own name (`GLOB`, `GMST`) still returns every arm, as it always did.
- **A `plugins=`-scoped `fields` scan written with `to_file=` now carries the scoped-vs-winner note in its manifest.**
  The rows hold each match's scoped plugin's own field values, and the three inline transports all say so; the
  artifact said nothing, so a value read back out of the file later — a defining esp's damage rather than the live
  winner's — came with nothing attached naming which body it was. The note is the same sentence the inline renders
  state, on line 1 of the file.
- **`housecarl_skse` now carries the same transport every other tool has: `format='json'`, `limit=`/`offset=` paging,
  and an in-band accounting line on every answer.** `format='json'` returns the machine-readable twin of whichever
  family ran — the same census, the same rows, the same numbers, in named fields, plus the family that ran and the two
  that did not (the text footer's prose cannot ride a json document). `limit=`/`offset=` page the family's row list:
  the DLLs for `findings='inventory'` (with `filter=`, its DLL and config matches), the native-declaring classes for
  `'pairing'`, the config files for `'config'`. The census above the rows states the whole population the answer is
  about — the layer, or, under `filter=`, the filter's matches — while the rows below it are the window; a count a
  filter cannot scope (the inventory's uncategorized-file total, the pairing's `.pex` scan) is left out of a filtered
  answer rather than stated for the whole layer beside numbers that are not. Every answer now carries
  `total / rendered / skipped / capped / truncated / offset / remaining / notes`, so what a window or a cap left out
  is a number rather than a silence. It closes the render: on the text lane the one-line family footer still follows
  it, on the json lane the `accounting` object is the document's last member. An unrecognized `format=` is refused
  naming the two the tool renders, and a negative `limit=`/`offset=` is refused naming both. Text output with neither knob passed is unchanged
  apart from that accounting line. `max_chars` bounds the json document the way it bounds the text render:
  what it cuts from a list the accounting does not count — one config's references, the inventory's config folders,
  the pairing's unreadable `.pex` entries — is named on the spot as `references_truncated`,
  `config_folders_truncated` and `unreadable_pex_truncated`.
- **`housecarl_records` gains `project.form='rows'` — a list field read as ONE LINE PER ELEMENT.**
  `project={"form":"rows","fields":["Conditions"]}` renders each element on its own line: the element's type,
  then every sub-field the read found — the function, the operator, the value, the `Or` flag, the run-on — with
  absent optionals omitted. Auditing a 40-row condition stack is one call instead of an index
  probe per row, and the same call works on any list (`["Effects"]`, `["Perks"]`), not just conditions. An
  indexed path (`["Conditions[0]"]`) folds that one element; a field that is not a list is refused per record,
  naming the field, rather than answered with the `fields` form. Reads
  the caller's field paths like the `fields` form and takes the same `depth=` (default 4 here, and `depth=1` is
  refused because it would collapse the list to a count); `resolve_names` annotates a link inside the row.
  Only an ABSENT optional is dropped: a declared-but-null link stays (an empty slot is a fact, and the
  None-property diagnostics read it), and the list's own header keeps its true count. Under `format='json'` a row
  is one entry carrying its folded leaves as `cells`, each with its own value, `link` and count — the values are
  never handed over as a sentence to parse.
- **A broad `where_source=winner` scan is no longer slower the more records it considers.** Deciding the match on
  the live winner used to re-read each candidate's winner by walking that plugin's whole record list, once per
  candidate, so a post-patch audit over a large master could spend minutes doing nothing but re-reading. The winner
  bodies are now gathered a chunk of candidates at a time — one pass per winner plugin in the chunk — and a
  candidate the scoped plugin itself wins is not re-read at all, since the body the scan already streamed IS the
  winner's. So the cost is bounded by the load order instead of by the number of candidates, and the scan holds one
  chunk of bodies at a time rather than one per candidate. On a synthetic order of one 19,200-record master and
  nine plugins, an audit of every record the master touches went from 34 s to 0.4 s, against the 0.2 s the same
  scan costs with `where_source` left at its default. Same matches, same rows.
- **A `where_source=winner` scan now says WHY a winner plugin did not give up its record.** A plugin another
  program is holding open reports that, with the error underneath it and the plugin named once as a coverage gap,
  instead of every one of its records reading as a winner the index named that did not re-resolve — a different
  problem, and not the one the user can act on. A plugin that opens but whose records cannot be read to the end —
  it changed on disk since the load order was indexed — reports that instead, and is not described as held open by
  a program that is holding nothing. Either way the gap is one plugin's: the rest of the scan still answers.

- **Reading a cell's `Persistent`/`Temporary` — or a topic's `Responses`, or a worldspace's `SubCells` — now
  states the additive union the game assembles, not just the read body's own list.** These children are declared
  per plugin and the engine assembles a parent's from every plugin that declares any, so a cell whose winner is
  an occlusion or lighting patch used to read as empty when the game fills it with hundreds of references. The
  field's value is unchanged — it is still that body's own list, in its own order, which is what a write
  addresses by index — and the union sits beside it: how many distinct children the order declares, which
  plugins contribute how many, and how much of it this body carries. A child two plugins both declare counts
  once. On `Worldspace.SubCells` the value counts the worldspace's BLOCKS and its children are the cells under
  them, so the note names that unit instead of setting the two numbers beside each other as if they matched. In json the union also carries a SAMPLE of the member FormIDs — up to 100, and fewer when `max_chars`
  is tight, with `members_omitted` counting the rest — so a short union can be read straight back through
  `formids=` and a long one still says how much it left out. A field whose child is SINGULAR (`Cell.Landscape`,
  `Worldspace.TopCell`) is not a union — those declarers override one record — so it says which plugin's copy is
  live instead. A plugin whose body could not be read is named beside the union, never absorbed into it.
  `project={"form":"tree"}` still names which provider declares what.
- **The union is stated on reads that NAME the records** — `formids=`, whether one or a batch. A scan
  (`types=`, `plugins=`, `references=`) discovers its own row count, so opening a body per touching plugin per
  row would be a cost nobody asked for: a scan still flags such a field, saying other plugins touch the record
  and their declarations were not read, and names the `formids=` lane that assembles the union.
- **A record body is now fetched from a named plugin by a typed group seek rather than a scan of the whole
  plugin.** Finding one cell no longer steps over every placed reference in the plugin, which is what makes the
  union above affordable on every read; the conflict tree takes the same path. Measured on a synthetic order of
  one 20k-record master and nine 2k plugins, ten touchers of one cell: 80 ms of body fetches became 4 ms.
- **An `into=` that names no houseCARL patch, or names a folder houseCARL does not own, now tells you what to try.**
  Each refusal is one sentence: what went wrong, then the nearest houseCARL-owned patches to extend instead, named
  as `into=` spellings (at most three, nearest what you typed first, with a count of the ones the cap left out so the
  three do not read as the whole inventory), and the calling tool's own fresh-patch parameter. Nearest is measured
  even where the name-suggester vouches for nothing, so the three are never whichever names happen to sort first.
  Every spelling offered is one that resolves back to the patch it stands for — a folder holding two
  plugins is offered by a plugin, not by a folder name the next call would refuse — and the record lane leaves out
  folders holding no plugin, which it could not extend. Where houseCARL owns patches but no single `into=` spelling
  reaches any of them, the refusal says how many there are and to rename one in MO2, instead of saying it owns none;
  where a mod folder could not be read while the patches were being counted, no candidate is offered at all rather
  than the half the scan reached, and the refusal says the scan failed rather than that houseCARL owns no patch — a
  claim it could not have established. `housecarl_remove` cannot create a patch, so on an install owning none yet it
  now names the writes that can make one instead of stopping at what went wrong. The fresh-patch remedy says to drop
  `into=` as well as which parameter to pass: every lane takes the extend branch whenever `into=` is set, so merely
  adding the parameter to the failed call returns the same refusal.
  Naming a mod folder houseCARL does not own is still refused with the originals untouched; that refusal does not
  hand back the name you passed, since a patch minted under that stem would sit beside the foreign plugin of the
  same name. The name you pass `patch=` next is checked against that plugin — see the entry on a new plugin whose
  filename would shadow one the order is not loading.

- **`housecarl_load_order_status` now names the running server's build in its header** — a `server:` line carrying
  the informational version the binary embeds (the release version `build-plugin.ps1` stamps from `plugin.json`,
  then `+` and the full commit sha: `1.9.5-dev+e942910…`), so checking that the installed houseCARL is the build you expect no longer means
  reading `ProductVersion` off `housecarl-mcp.exe`. The line leads every answer the tool gives, including the
  setup prompt a server with no MO2 instance configured returns. A binary built without that stamp reports the
  same `0.0.0-dev` the MCP handshake reports, plus a short `(no build stamp)` clause, rather than printing a blank.
- **The provider names `housecarl_nif_inspect` and `housecarl_nif_set` print are now the names their `mod=`
  accepts.** A chain read `ModA (loose) > Base.bsa (BSA)`, and passing `ModA (loose)` straight back refused; the
  names are now printed inside double quotes — a character a Windows folder or file name cannot contain — with the
  kind outside them, so a name with a space, an apostrophe or parentheses copies back verbatim. Both tools take
  the name through the same source policy `housecarl_place_asset`'s `source_provider=` uses.

- **Naming a MOD now reaches that mod's own root archives, not only its loose files — for a mod MO2 is loading as
  well as one it is not.** `mod=` and `source_provider=` previously reached an enabled mod's loose files only, so a
  donor whose mesh lives inside its own `.bsa` had to be addressed by the archive's filename instead, and the same
  folder switched off was reachable by its mod name. Both spellings now work either way. On the NIF tools the named
  provider is also answered before the ABSENT check, so a donor outside the active set produces a refusal that names
  the mod and says where houseCARL looked, rather than reporting the mesh as absent. When bytes do come from a copy
  the game is not loading, the response says so and says which of the two reasons it is — the mod is not enabled, or
  the archive is one no active plugin binds — on `housecarl_place_asset` as well as on the NIF tools, and `nif_set`'s
  `in_place` lane refuses such a copy, because its handshake is written about the winning file.

- **A `mod=` answer no longer suppresses the caveats and the branches the same answer gets without one.** `mod=` is
  answered before the ABSENT check (see the entry above), which left three sentences reachable only through it and
  therefore never reached. `housecarl_nif_inspect` with the `*winner` pole over a path nothing active provides now
  carries the same "this build's scan was incomplete" hedges the plain ABSENT does. `housecarl_nif_set` writing a
  copy read from a mod nothing else duplicates now says nothing else provides the path and names the folder to
  enable, instead of telling you to sort above a winner that does not exist. And the "read out of a root archive the
  engine does not load" sentence is now stated for an archive read only, not for a loose file found in the same
  enabled folder.

- **`housecarl_nif_inspect` takes `npc=`: NPC FormIDs whose FaceGen head mesh houseCARL derives and reads.** Each
  FormID becomes the `facegeom` `.nif` path its FormKey defines — the folder is the plugin that defines the NPC,
  never the load-order winner — and joins the same batch as any `mesh_paths` in the call. One of the two is
  required.

- **`housecarl_nif_set`'s `set_path` now swaps a header string as well as a texture slot, so a material (`.bgsm`),
  a `.tri` or a physics-xml reference can be rewritten.** Pass `target=` the string exactly as
  `sections=strings` prints it (matching is case-sensitive) and no `texture_slot`. A string that is a shape's or
  node's name is refused there and sent to `rename_shape` / `rename_node`, which carry the rename-onto-an-existing-
  name guard. Both verification gates apply as they do to every other op.
- **`housecarl_asset_status` now takes `under=`, a Data-relative directory or glob, and answers for every file the
  load order provides beneath it — loose and BSA alike, with the winner and provider chain per file.** One call over
  `meshes/actors/character/facegendata/facegeom/<Master>` replaces the whole path list a facegen sweep used to spell
  out. `*` matches within a path segment, `?` one character in a segment, `**` across separators; `asset_paths=` and
  `under=` compose in one call, and a duplicate path is not resolved twice. A selector that matches nothing says so
  rather than passing as an empty sweep; a glob with no folder in front of it is refused rather than sweeping the
  whole load order; and a drive-rooted or `..`-escaping selector is refused by name, the same gate every asset path
  passes. A wildcard-free selector that names a FILE the load order provides is answered as that one path, with a note
  saying so, rather than reported as a folder nothing provides. Every path in the answer spells the selector's folder
  one way, whether the file came from a loose mod or an archive.

- **Every `housecarl_asset_status` response now ends with a structured `[accounting]` line — `total`, `rendered`,
  `skipped`, `capped`, `truncated`, `offset`, `remaining`, `notes`.** A consumer keying results by path can compare the
  numbers instead of parsing the prose cut notice. Each omission is counted once by its own cause: `skipped` is what
  `offset=` stepped over, `capped` what `limit=` left behind, `truncated` what `max_chars` cut — so the four and
  `rendered` sum to `total`. Room for the line is reserved out of `max_chars` before the paths render, so it fits
  inside the cap instead of past it. `limit=` and `offset=` page a large sweep, and the accounting names the next page
  as both a `limit=` and an `offset=` — counted off what was rendered, so following it stays paged and shows every path
  exactly once. Notes about `under=` selectors are cut at `max_chars` like the other alarm blocks, so a call carrying
  thousands of selectors cannot write megabytes of them.
- **`housecarl_place_asset` and `housecarl_bulk_place_asset` are replaced by one tool, `housecarl_place`.** One call
  places any number of files into one houseCARL mod folder: `assets=` is the set of destinations, each addressed by
  `path=` or by an NPC `formid=`, each free to name its own `source=` and `source_provider=`, with `source_provider=`
  and `kind=` also settable once for the whole set. A `formid` with no `kind` places both FaceGen files at any set
  size, which the single tool refused. The new folder is named with `patch=`; `into=` extends an existing houseCARL
  patch. Every response carries the counts it rendered. The two old names answer with the migration and place
  nothing.

- **Every file-placing lane's `into=` refusal now names the parameter that names the folder, and its own default
  folder name.** `housecarl_place`, `housecarl_compile_script`, `housecarl_decompile_script`, `housecarl_nif_set`,
  `housecarl_write_seq` and `housecarl_bsa_repack` each pass their own naming to the shared refusal, so a caller who
  guessed a folder name that does not exist is told how to create it under a name they choose rather than only to
  omit `into=`. On `housecarl_bsa_repack` the sentence names `patch_name=` and says that `patch=` there names the
  archive instead.
- **`housecarl_skse_inventory`, `housecarl_native_pairing_audit` and `housecarl_skse_config_audit` are now one tool,
  `housecarl_skse`, with `findings=` picking the family: `inventory` (the default), `pairing` or `config`.** The three
  answered different questions about the same layer and each carried the same "what the file declares, never what the
  DLL does" ceiling; it is now written once on the merged tool, with each family's own detail on `findings=`. `filter=`
  and `max_chars=` mean what they meant, `peek=` still belongs to the inventory family and is refused rather than
  ignored on the other two, and a call runs one family — every response names the family it ran and the spelling of
  the two it did not. The three old names return a one-line redirect naming the `findings=` value that replaces them.

- **The pairing family now reports a debug-built DLL that loads on your own machine.** Reaching a `[LOADS]` verdict
  while the DLL imports the debug C runtime means that runtime resolved here — so it loads for you and fails with
  error 126 for anyone without it. The verdict is unchanged, because it does load here; what is new is that the DLL
  line says who it will not load for — on a `[VERIFY]` line as well as a `[LOADS]` one — and that a class whose every
  loading DLL is debug-built is a finding of its own in the default view rather than a name in the healthy roster, so
  the summary no longer reports a clean bill of health over it. A class that also has a clean DLL that loads stays
  healthy: that DLL implements it for everyone. The inventory family already flagged this, so the two families no
  longer disagree about the same file.
- **A localized plugin whose text lives in the game's `Data` folder now reads its names and descriptions even when a
  `.bsa` sits beside it.** houseCARL pointed the strings lookup at game-Data only when the plugin's own folder carried
  no strings source, and it answered that with "is there a `Strings\` folder" plus "is there any `.bsa`" — so an
  archive holding only meshes and textures, and a shared `Strings\` folder holding only a neighbouring plugin's tables,
  both suppressed the lookup and every localized value read back empty. The question is now asked about the named
  plugin: a loose table matching its name, or an archive beside it that embeds one. This reaches every read houseCARL
  does, including the copies `housecarl_merge_plugins` and `housecarl_compact_plugin` write.

- **`housecarl_merge_plugins` and `housecarl_compact_plugin` now refuse a localized plugin whose `.STRINGS` houseCARL
  cannot find anywhere.** Such a plugin reads every name, description and message as empty, and both verbs wrote those
  blanks into the output and reported an ordinary success. The refusal names the plugin, says what reads empty, and
  says the tables may be somewhere it cannot see from the plugin's own folder — a translation mod that is not enabled,
  or content whose archive is in another mod folder. Nothing is written. A plugin whose strings do resolve is
  unaffected.

- **`housecarl_merge_plugins` now states that it de-localizes a localized donor.** The merged plugin is never flagged
  localized, so a donor's text is written into it inline: the donor's `.STRINGS` files no longer describe the output,
  and any language they shipped that this read did not resolve is not in it. The report names each donor houseCARL
  read and found flagged. `housecarl_compact_plugin`'s new-file lane already said this.

- **`housecarl_merge_plugins` now finds plugins that only DECLARE a donor as a master.** The safety scan read record
  links and record identity and never opened a header, so a compat patch that lists a donor as a master while
  referencing none of its records was reported as no dependent at all — and stopped loading, for want of a master, as
  soon as the donor was deactivated. Those plugins are now named with what they declare and what to do about it, and
  the pass line says what the scan does and does not read. `housecarl_compact_plugin` does not report them: its output
  keeps the source's basename, so a declarer's master is still there.

- **A localized plugin in a mod folder houseCARL cannot list is no longer described as having no strings anywhere.**
  The folder's "could not be listed" answer was read and then dropped, so a plugin whose tables sit in a `.bsa` in
  that folder was refused with a sentence saying there is no archive beside it, and a remedy telling the modder to go
  and find the tables. Such a plugin now classifies as its own shape: the refusal says the folder could not be read,
  and the remedy names that folder — close whatever holds it open, or fix its permissions. The refusal itself is
  unchanged in outcome; what changed is that it no longer claims an absence nothing checked.

- **`housecarl_merge_plugins`'s `.esl` refusal no longer states a reason that is false for a light donor.** It said a
  merge keeps the donors' object ids where they already are; a merge renumbers cross-donor collisions and ids below
  the write floor, and renaming an already-light plugin — a single-donor merge — has ids that are all inside the light
  window anyway. The refusal now says what the merge does not do (it never constrains object ids to the light window)
  and points at `housecarl_compact_plugin`, which does.
- **A record that resolves nowhere now says whether its PLUGIN is in the load order.** One sentence used to serve
  two opposite causes — a plugin that is not installed, and an installed plugin that has no such record — so telling
  them apart took a second call. A present plugin is now named as present, with the wrong-edition cause (an
  ESL-flagged edition compacts its records into 0x800+) and the call that lists what it does define; an absent one
  keeps the load-order explanation it always had. The same repair reaches the unresolved-link annotation, which used
  to assert `target not in the active order` when the plugin usually is.
- **A record that resolves nowhere now says which of the three causes it is, in every form that reads records.**
  One sentence used to serve a plugin that is not installed, a plugin excluded this session, and an installed plugin
  that has no such record, so telling them apart took a second call. A present plugin is now named as present, with
  the call that lists what it does define. The wrong-edition cause — an ESL-flagged edition compacts its records
  into 0x800+ — is stated where the load order says that plugin is light-flagged, and not otherwise, because 0x800
  is also where a plain full master's own records start. An absent plugin keeps its load-order explanation, and
  drops the check-the-filename hint when a real cause follows. The identity, tree, `info_order`, walk-seed and
  comparison-pole forms all emit that one sentence, where each used to compose its own `not present in the active
  order`; so does the unresolved-link annotation.

- **A `where=` predicate whose path hops through a list is now told what will actually fix it, checked against the
  element type.** `where=["Effects.Data.Magnitude > 0"]` is a correct field reached by a path missing its brackets,
  and it was reported as a mistyped field name. The note now resolves the trailing segment against the collection's
  element type: where it is a field there, the exact bracketed path is printed, whole — the rest of the path is
  carried into it (`Effects[0].Data.Magnitude`), so the printed spelling is one a caller can paste back; where it is not,
  it says the segment is not a field on that element type and offers the nearest real field, rather than asserting a
  bracket that would not help. `where=`'s own description also states that a wildcard over a list is not built.

- **`housecarl_records` remedies now name levers the call actually accepts.** The `everything` form no longer
  offers `project.fields=`, which that form refuses by name; a capped walk names `walk.max_nodes` rather than
  `limit=`, which windows the seeds and would have changed nothing; an in-order `project.group_by='type'` without a
  body-bearing scope refuses in this tool's own spelling, while the off-order file scan — where the file's own
  records are the universe — keeps the refusal it already had; and a summary row labels the override depth
  `override_depth=`, no longer colliding with `project.depth=`. `project.form='chain'` is described as the form it
  now is, rather than as refused until it lands.

- **`apply` and `create` name the file in every refusal about a list read from `@<path>`.** Two of the four
  post-read refusals — an empty array and a null element — reported the parameter with nothing saying the content
  came from disk.

- **`housecarl_asset_status` under a `max_chars` its header and alarms already fill now renders the first path's
  answer instead of cutting to none.** `housecarl_nif_inspect` already did; both tools now render through one batch
  skeleton, so the first item always answers and the omitted-count cut reads the same in both.

- **A runtime FormID (`FExxxYYY` / `XX######`) is now read-only: the write verbs refuse one and hand back the
  `XXXXXX:Plugin.esp` form to use in its place.** A runtime FormID names a slot in the load order as it stands, so
  a re-sort between the parse and the write would point the same eight digits at a different record; the plugin form
  cannot move that way. The refusal names the translated form, so it can be pasted straight back into the call.
  Reading by a runtime FormID is unchanged, and the doors that refuse are the ones the write verbs parse their
  targets through — see `FormIdDoor.ForWrite`.

- **`housecarl_bsa_repack` now refuses when BSArch exits with an error, and no longer fails a fast pack for no
  stated reason.** BSArch can abort partway and still leave a scratch archive behind; if that scratch happened to
  declare the same file count the source offered, the repack placed it over the existing archive and reported
  success. A non-zero exit is now a failed pack whatever it left on disk, and the refusal names the exit code and
  what BSArch printed. Separately, the check that the scratch came from this run compared a filesystem write stamp
  against a finer-grained clock, so a pack that finished inside one filesystem tick could be discarded with an empty
  message; the run's own success now decides, and the scratch is still cleared before the run (a stuck one refuses
  up front) so a previous run's bytes cannot ship as this one's.

- **`housecarl_records` with `source={"file", "mod"}` now reads the copy in the named mod folder, even when that
  filename is active in the load order.** Several mod folders can ship the same plugin filename (an ESP replacer),
  and MO2 serves one of them; naming a folder addresses that folder's file. When the named copy is not the one the
  game loads, the response says so and names the mod folder that provides the served copy. A folder that does not
  carry the filename is refused as before, and the plain-filename and direct-path forms are unchanged.
  Two copies of one filename can now sit on opposite sides of a comparison, so: `form=tree` treats a provider node
  as the reference only when the reference resolved in the load order, and both renders name the off-order side's
  mod folder on the delta line when the two sides share a filename. A `versus="previous_provider"` against an
  off-order `source=` is refused once for the call, before any record is read, instead of once per record.

- **A FormID from the game, a log or a crash log now works as an input, and comes back as an output.**
  Wherever a FormID is read, houseCARL now also takes the runtime form the game, the
  console, Papyrus logs, SKSE logs and crash logs print: eight hex digits and no plugin name — `FExxxYYY` for a light plugin,
  `XX######` for a full one, with or without a leading `0x`. It is resolved against the load order as it
  stands at the call (the light index moves whenever the order does, so nothing is cached), and the answer
  names the plugin it resolved to. Every rendered record now carries its runtime FormID beside the
  `XXXXXX:Plugin.esp` form — `runtime=` in the text lanes, `runtime_formid` in json and in the scan's dense
  columns and spilled artifacts — so a record read here can be carried straight back to the console or xEdit.
  A record in a plugin flagged light but never compacted, whose object ID is above the ESL window, gets a
  sentence saying so where the form would have been rather than a form that names its in-window neighbour
  too. An index no active plugin occupies is refused by
  name, and so is an `FF` dynamic form, which exists only in a save game. The `XXXXXX:Plugin.esp` form is
  unchanged, and stays the way to read a plugin that is not active. A `where=` operand compared against a field
  holds numbers and enum names too, so it takes the plugin-qualified form only; the `formid in [...]` list takes
  both.

- **`THIRD-PARTY-NOTICES.txt` lists what the plugin actually bundles.** The component tables are now written
  by the build from the publish output, so the names and versions in the file are the ones in `server/`. The
  file no longer lists five packages that do not ship (`System.Threading.Tasks.Extensions`,
  `Microsoft.Win32.Registry`, `Microsoft.NETCore.Platforms`, `System.Security.AccessControl`,
  `System.Security.Principal.Windows`), and the entries are ordered by name. The GPLv3 section 6
  corresponding-source line is written the same way, from the Mutagen version that ships and the commit
  recorded for it in `packaging/notices-mutagen-commits.json`, so it cannot name a release the plugin does
  not bundle. The licence texts stay hand-authored; see the markers in the file for which parts are which.

- **A whole-order scan names a plugin it could not read.** `housecarl_records` and
  `housecarl_cross_plugin_query` scanning by type, `housecarl_effect_chain`, `housecarl_validate_dialogue` on a
  quest, and the `housecarl_skypatcher_layer` no-op scan all stream the load order's winning records. A plugin
  that opened when the order was indexed but cannot be opened now — held open by xEdit, MO2 or the running
  game, with its last-write time unchanged so nothing rebuilds — used to be skipped without a word, and every
  record it wins was missing from an answer that read as a complete scan. Each of those tools now names the
  plugin and the reason, and states that records it wins are missing; the scan still covers the rest of the
  order. The sentences that would contradict that — "this quest owns NO dialogue topics", "applied by no
  SPEL/ENCH/ALCH/SCRL/INGR in the active order", and the paged header's "NO records match at any offset; check
  the filter, not the paging" — are replaced with what the scan can actually claim, which is what it found in
  the plugins it could read. A file lock is also no longer reported as a quest CK-parity finding: it has its
  own line in the text response and its own `scan_gaps` key in the json one, so a quest whose ANAM and
  objective FNAMs are correct still gets its parity verdict. A SkyPatcher post-state read (`source={"overlay": "skypatcher", "state": "post"}`) of a record whose
  replay resolves an EditorID against such a plugin now refuses by name rather than replaying against a lookup
  table it knows is short; a record the layer addresses by FormID is unaffected.

- **`housecarl_bsa_repack` reports how many files it packed, and says which it left out.** BSArch archives
  only files under a subfolder, so loose files sitting at the source folder's root were dropped and the tool
  still reported a plain "packed <name>". The source is now counted before the pack: the success line says
  "packed N file(s) into <name>", and root-level files get a sentence naming how many were left out and what
  to do about them, on the failed pack as well as the successful one. The produced archive's own file count is
  read back and checked against the source the same way `housecarl_bsa_list` and `housecarl_bsa_extract` check
  theirs; a disagreement refuses with both numbers and leaves any existing archive untouched. That read-back
  works on `.bsa` headers, so the `fo4`, `fo4dds`, `sf1`, `sf1dds` and `tes3` formats write an archive whose
  contents houseCARL cannot count — those packs report no count and say so instead of claiming one. A `.bsa`
  whose header could not be read is placed with a WARNING that its contents were not checked, rather than the
  format sentence. The count leaves out what BSArch itself drops — every `*.db` file (a `Thumbs.db` in a
  textures folder, say) and every file with no extension — so a source holding those still packs. A source
  folder that cannot be fully listed (a subfolder the process may not read) packs unchecked with a sentence
  saying so, instead of refusing the pack.

- **`housecarl_compact_plugin` and `housecarl_merge_plugins` name a plugin they could not read.** The
  external-reference pass that runs before a renumber used to skip a plugin it could not open while still
  counting it as scanned, so a plugin held open by xEdit, MO2 or the running game could make the pass report
  a coverage it did not have. Such a plugin is now named in the report, with the reason it could not be read,
  and is no longer counted in the scanned total. The two reasons get their own sentence: a plugin that could
  not be OPENED gets the close-the-program-holding-it remedy; a plugin that opened and then faulted part way
  through gets the exception it faulted with, and no advice to close programs that are holding nothing.

- **`housecarl_compact_plugin` refuses the in-place lane when it could not read a plugin.** Compacting in
  place — overwriting the target, or rewriting its referencers with `repoint_externals` — needs the
  external-reference pass to have covered the order, and there is no backup and no review step in that lane.
  A run whose pass could not read a plugin through is now refused, naming the plugin and the reason, before
  anything is written and whatever `acknowledge` says; the remedy is to resolve that, or to compact into a new
  plugin instead. The new-plugin lane is unchanged and still reports the same plugin as a note.

- **`housecarl_records project={"form": "tree"}` states which plugins declare child records.** For a record
  whose type owns children — a cell's placed references, a topic's INFO lines, a worldspace's cells — the tree
  now states, per child-bearing field, which providers declare content there (naming them for a COLLECTION
  field, counting them for a SINGULAR one, e.g. Cell.Landscape), and states in its own words when none do. It
  reads the provider bodies the tree already fetched, so it adds no fetch. The default read
  is unchanged: it still says other plugins touch the record and their declarations were not read, and its note
  points here. The bound is the field set: the record type's own child-bearing set (reflection over the type),
  not the narrower set the default read's own note is restricted to — the block covers every child-bearing
  field of the type, sole-provider records included, where the default read's note has nothing to say at all.
  `fields=` narrows the block as it narrows the rest of the response: naming a child-bearing field keeps that
  field's line, and a path inside one (`fields=["Temporary[0]"]`) drops the block entirely, the same way the
  default read's own note declines to annotate a bracketed path.
  Check it: run the tree form on a cell and read the block above the diff.

- **`housecarl_check` is callable. It was not before.** The merged derived-findings sweep — the errors,
  scripts and dialogue families under one `findings=` vocabulary — shipped in the source on 2026-08-21 but
  was never registered on the MCP surface, so no client could reach it: the tool was declared on its method
  while the class holding it was not marked as a tool type, and the server registers only marked types.
  Nothing about the tool itself changed. Check it from your client's tool list: `housecarl_check` is present.

- **Six 1.x write tools are gone: `housecarl_set_field`, `housecarl_bulk_apply`, `housecarl_create_record`,
  `housecarl_bulk_create`, `housecarl_remove_record` and `housecarl_forward_record`.** Their capability is on
  `housecarl_apply` (both field-edit tools), `housecarl_create` (both create tools), `housecarl_remove` and
  `housecarl_forward`, where one op or one record is a set of one. They are deleted rather than deprecated, on
  the maintainer's ruling that a 1.x tool whose capability the finished 2.0 surface covers goes at 2.0.0 with no
  deprecation window, in the release that ships its replacement. Calling a deleted name does not fail blank: the
  server answers with the successor and the parameter migration for that tool — what `from_file=` and
  `operations=` and the `target=`+`in_place=true` pair are called now.
  Check it from your client's tool list: the six names are absent and the four successors are present.

- **Refusals and remedies across the surface name a tool you can actually call.** Sentences left behind by the
  deletion above told you to reach for a tool that is no longer there — among them the record-axis refusal that
  answers an attempt to add a child record into a parent's list, the create refusal for a record type with no
  top-level group, the dialogue-view and subtype-marker repair advice, and the `housecarl_records` line saying
  where authoring goes. Each names its successor now, and where the spelling moved as well as the name it gives
  the new spelling: `create`'s `parent=` and `collection=` are members of a `records=` element, not top-level
  arguments.

- **The tool schemas houseCARL publishes no longer contain a `$ref`, so a provider that rejects recursive
  schemas can load the server.** Every tool that takes a composed struct declared a nested shape referring
  back to itself — how a JSON Schema generator spells a recursive type. Providers that validate the tool list
  strictly reject recursion and refuse the *whole* server at connect time, with an error
  (`Recursive JSON schemas are not currently supported`) that names neither houseCARL nor a tool, so the only
  way through was turning the MCP server off for that model. The nested shape is now written out concretely to
  a bounded depth and then closed with a node that keeps the type but stops constraining what is inside it, and
  says so in its own description. What the tools accept is unchanged — nothing reads the nested part of a
  published schema, so rewriting it cannot move an acceptance decision.
  Check it from your client's tool list: no houseCARL schema carries a `$ref`.

- **`housecarl_records` truncation and expansion notices name that tool's own parameters — on the forms and
  lanes listed here.** When a read hit `max_chars`, the notice told you to narrow with `fields=` and lower
  `depth=`; on that tool those are spelled `project.fields=` and `project.depth=`, so following the advice
  as written got you a refusal. A collapsed container cell said `pass depth=2 to expand` for the same
  reason, including under `source=` and the SkyPatcher post view, which read through a separate path. The
  scoped-vs-winner note told you to pass `winner_fields=true`; that parameter was renamed on this tool and
  is `fields_source="winner"`. A scan's cut told you to drop `conflict_tree`, which this tool has no
  parameter for in any spelling, and then to drop `project.fields=`, which the `fields` form refuses to run
  without — it now points at dropping `project=` for summary rows, which works, and it says so only when
  the call passed a `project=` block to drop: a scan that passed none is already reading the summary rows
  that clause points at, and is told to lower `limit=` or raise `max_chars` instead. A cut over records read
  in a batch told you to `request fewer formids` whether or not you had passed any; where the rows came from
  a scan it names `limit=` now, which is what windows that response. The selector itself was
  spelled two ways depending on which renderer composed the sentence, and is now always `project.fields=`.

  **What this covers:** the `fields`, `tree` and `delta` forms and the `summary` form's scan cut, the
  collapsed-container hint on every `source=` lane, and the scoped-vs-winner note — on `format="text"` and
  `"json"`, with the container hint additionally covered on `"dense"` and in `to_file=` artifact rows. The
  cut's own selection and slim-down clauses are covered on `"text"` alone, because that is the only format
  that writes them: `"json"` and `"dense"` report a cut as data rather than as a sentence. **What it does
  not:** the `everything` form still names `project.fields=`, which that form refuses, and a walk or chain
  response still says `raise limit=` for a bound that `walk.max_nodes` controls. Both are filed and unfixed
  here.

  The 1.x read tools' notices are unchanged; they were already naming their own parameters. Check it by
  starving a read — a few `formids=` with `project={"form":"fields","fields":[…]}` and `max_chars=220` —
  and reading the notice back.

- **A read tool asked for json now refuses in json.** Reads that take `format="json"` previously answered
  some refusals with a plain sentence instead of a json document, so a caller parsing the response had to
  handle two shapes depending on which rule it broke. Those refusals are now one document — `ok:false` plus
  the `error` sentence, and the build stamp where the refusal consulted one. A row that failed inside a call
  that succeeded is not a refusal and keeps its own `error` field, with no `ok`: that is how a served answer
  is told from a refused one. The refusals still outside this shape are the tools with no json format, the
  `format='dense'` refusals, and an unreadable `format=` itself, which cannot know the shape you wanted —
  plus an internal failure or an unconfigured instance, which are not refusals of your call. Which refusals
  are in and which are out is enforced by `refusal-completeness-guard`, which derives the covered surface
  rather than working from a list.

- **`housecarl_records` with `counts_only=true` renames one json field: `ok` is now `resolved`.** The census
  reported `{count, ok, errors}` with `ok` holding the number of inputs that resolved — the same key the
  refusal shape above uses to mean "this call was refused", in a different type. A caller reading the
  response as a refusal check saw `"ok": 0` on a served census where nothing resolved. The field pairs with
  `errors` beside it now. The `ok:false` refusal discriminant is unchanged, and the text render still says
  `ok=`. **If you parse the json census, update the field name.**

- **Two read tools refuse an unreadable `format=` before anything else.** `housecarl_batch_record_detail`
  and `housecarl_resolve` checked for an empty `formids=` first, which meant that one refusal could not be
  a json document however you asked for it. The transport is settled first now. If a call breaks both rules
  at once — an unreadable `format=` *and* an empty `formids=` — you are told about the `format=` where you
  used to be told about the `formids=`. Apart from that ordering, text output is unchanged.

- **houseCARL no longer edits a localized plugin in place, and now tells you where that plugin's text
  actually lives.** A localized plugin keeps its text in separate `.STRINGS`/`.DLSTRINGS`/`.ILSTRINGS`
  files and carries only indices into them. houseCARL previously committed such a plugin without the
  tables its own serialize had produced, so values landed on records they did not belong to; it has been
  refusing these writes since, and that refusal is now the settled behaviour rather than a stopgap —
  houseCARL cannot swap a plugin and its tables as one operation, so it does not rewrite one on your own
  file. The refusal names the arrangement your plugin is in: a complete set of `.STRINGS` files beside it,
  a language missing one of its three files, files present both beside the plugin and in `Data\Strings`,
  files inside a `.bsa` (saying whether that archive sits beside the plugin or in your game folder), files
  resolving from `Data\Strings` alone, and files houseCARL cannot find at all — which says it could not
  find them, not that they do not exist, because Mod Organizer merges mod folders at runtime and houseCARL
  reads them as they sit on disk. To edit a localized plugin, use the default lane and write to a new
  plugin. The lanes this covers are the ones whose own `in_place=` description now says so.

- **A plugin houseCARL could not open at all is refused too, and told apart from a localized one.** When
  the file is locked by another program at the moment houseCARL looks — Mod Organizer refreshing, an
  antivirus scan, xEdit, the running game — or the path names no file, houseCARL used to treat it as not
  localized and write anyway. It now refuses, and it says only what happened: it could not read the file,
  so it will not write to a destination it cannot classify. It does not tell you the plugin is localized,
  does not describe `.STRINGS` files it never saw, and does not point you at the new-plugin lane, which
  reads the same file and fails the same way. The remedy it gives is the one that matches: find what has
  the file open, or check the path, and retry.

- **`housecarl_compact_plugin`'s external-referencer refusal no longer sends you down a route that will
  refuse.** It ends by telling you to re-run with `repoint_externals=true`; when houseCARL cannot rewrite
  one of those referencers, that re-run was always going to be refused. The refusal now says so up front,
  counting and naming the referencers it cannot rewrite — separately for the ones flagged localized and
  the ones it could not read — and giving a reason for one of each, so a referencer it could not open is
  not reported as a localized one.

- **List fields gain an `InsertAtIndex` op: put a new element AT a position instead of only at the end.**
  `key=` is the position to insert at and every element from there on shifts right by one; the list's own
  length is a legal index and appends, so `InsertAtIndex` at `count` is `Add`. It builds the element exactly
  as `Add` and `SetAtIndex` do — `compose=` for a modeled element (a condition row, a leveled-list entry),
  `value=` for a plain one — and it is available on `housecarl_apply` and `housecarl_create`, and on every
  other op or verb parameter that already takes `Add` and `SetAtIndex`.
  This is what a position-contiguous run needs: a CTDA `Or` flag chains a row to the row after it, so adding
  an arm to an existing OR-group means landing the row inside the run — an `Add` puts it at the end, where it
  becomes a separate AND-group that can only narrow the gate, and the alternatives were re-transcribing every
  row with `ReplaceAll` or overwriting an existing arm with `SetAtIndex`. An index past the append slot is
  refused with the bound it may use; the verbs that address an element that already exists keep their own,
  narrower bound. `composes=` (many elements in one op) stays `Add`/`ReplaceAll` and says so.

- **A refusal that suggests another verb now suggests one that works on *your* field.** Six refusal messages
  named verbs from a list written beside them, and the list did not know which field you were editing: a
  `Merge` on a dict of modeled entries (`Package.Data`) was answered with "InsertAtIndex to insert AT an
  index", and following that returns `InsertAtIndex is only valid on list; 'Data' is dict`. Those messages now
  derive the verbs they offer from the field's own shape — its cardinality, and whether its elements are
  plain values, built from parts, or child records — so a dict is never offered an index verb, a list is never
  offered `Merge`, and a collection of child records is pointed at the record axis instead of at a verb that
  will refuse. `composes=` reaches a field ahead of those checks and is answered from the same classification,
  so it describes a collection of child records the way the verbs do rather than calling its elements coercible.
  Each suggested verb also states the input it needs (`compose=`, `values=`, `key=`), which the
  old messages left you to infer. What a message names is checked against what the write pre-flight actually
  accepts, for every collection field in the record library, in both directions.

- **The bundled `mutagen-reference` now describes Mutagen 0.54.4** (was 0.53.1). Four record shapes are
  described differently than before, so a patch written against the old reference should be re-checked:
  `LandscapeVertexHeightMap.HeightMap` is a signed 8-bit height map (`ReadOnlyArray2d<SByte>`), not unsigned;
  `Race.BehaviorGraph` and `BodyData.Model` name their own model types (`ModelBehavior`, `ModelBodyTexture`)
  instead of the shared `Model`, with the same fields and the same writability; and
  `FindMatchingRefFromEvent.EventData` reads as the typed `GetEventDataConditionData.EventMember` enum instead
  of raw bytes, so a condition on it can be written by name. Three enums gain values: `Scene.Flag` gains
  `ShowAllText`, `GameRelease` gains `Fallout3`, `FalloutNV` and `EnderalSEGog`, and `SkyrimRelease` gains
  `EnderalSEGog`. Nothing the reference described before was removed: no type, field, enum value or union
  arm, and no field that was writable became read-only. `/housecarl:mutagen-reference` is the surface that
  changed; the reference states what it covers.

- **A plugin whose `PKCU` data-input count disagrees with the inputs it carries is no longer excluded from a
  session.** Mutagen 0.54.4 reads that mismatch instead of failing on it, so the plugin loads and its records
  resolve. Plugins carrying a record Mutagen still cannot parse are excluded exactly as before;
  `housecarl_load_order_status` lists which plugins were excluded this session and why, so you can check
  whether a plugin you expected to be missing still is.

- **New: `housecarl_check` — one sweep, several finding families.** It merges `housecarl_check_errors`,
  `housecarl_validate_scripts` and `housecarl_validate_dialogue`'s findings behind one `findings=` vocabulary:
  whole families (`errors`, `scripts`, `dialogue`) or the classes inside them (`dangling`, `missing_masters`;
  `unbound_object`, `unbound_scalar`, `unbound`, `bound_null`). Naming several runs each, and the response is
  sectioned per family with that family's own totals, its own accounting and its own boundary. All three older
  tools stay registered and unchanged, so nothing you call today moves.
  `findings=` omitted runs the **errors family alone**, and the response states which families it ANSWERS for,
  which selected families refused, which registered families it never ran, and the exact `findings=` spelling
  that adds each of those. It cannot default to every family: an unscoped scripts sweep took ~8 minutes on a
  3800-plugin order.
  `max_chars` is DIVIDED among the families that ran and their parts rather than spent in series. Spent in
  series on that same order at the defaults, a second family inherited 400 characters of an 80,000 budget —
  the errors listing alone came to 79,600. The division is max-min fair over what each part actually needs,
  measured before anything is written: a part that needs less than an even share takes only what it needs and
  the rest goes to the parts that want more. Two things follow, and both are held by CI. Raising `max_chars`
  can never render LESS of anything. And a call whose whole answer fits inside `max_chars` renders all of it and
  reports no cut — before this, a merged call whose two families came to 47,251 characters stopped at 49,440 of
  an 80,000 default, dropped 5 of 40 record sections, said it was truncated, told you to raise `max_chars=`, and
  left 30,560 characters unspent.
  `exclude=` now scopes every SWEPT family, including the script sweep, which never had it. `plugins=` naming a
  file that is on disk but not in the active load order is still swept by the errors family; the scripts
  family has no off-order lane and the response says, in that family's own section, which files it did not
  sweep and why.

- **New: `findings=['dialogue']` validates the dialogue graph over topics and quests you NAME.** It carries
  `housecarl_validate_dialogue`'s findings — quest and branch wiring, LinkTo and previous-link targets, silent
  voiced lines, result scripts that will not fire, malformed conditions, CK-parity subrecords, and a
  start-game-enabled quest's `.seq` coverage. `seeds=` takes a DIAL (one topic), a QUST (every topic that quest
  owns), or a DLVW/DLBR (a record-level CK-parity check), and `limit=` caps how many seeds one call expands.
  This family is **seeded, not swept**: `plugins=`, `type=`, `formids=`, `editorid_contains=` and `exclude=`
  scope the other two and do not narrow it, the response says so in its own section, and a seed must resolve in
  the active load order. `findings=['dialogue']` with no `seeds=` is **refused** rather than widened to the
  whole order, and the refusal states the bound it was measured against and spells the call that works. A seed
  that resolves to nothing is named with the reason, under `counts_only=true` as well.
  The effective merged INFO order — which line the game reaches first — is **not** here; the family's boundary
  says where it lives. `housecarl_validate_dialogue` stays registered and unchanged.

- **Fixed: `housecarl_check` no longer reports a cut it did not make when a plugin cannot be parsed.** The
  excluded-plugin roster was written after each family's accounting, so every family reported none of the roster
  rows rendered, said the roster had been cut, and set `truncated` — on responses carrying the whole roster, in
  both formats. The roster now reads above the family sections, where the scope sentence it belongs to is, and
  the room it needs is held back rather than taken from the findings.

- **Fixed: a family that cannot run no longer refuses the whole call.** `exclude=` is applied against each
  family's own scope, and the script sweep is handed only the plugins that are in the active load order. So
  naming a plugin that is on disk but out of the order and excluding the active one emptied the script sweep's
  scope, and the whole call came back "exclude= removed every plugin this sweep would have covered — narrow
  exclude=, or widen plugins=" — throwing away a completed errors sweep and printing a remedy that was wrong for
  the family that had answered. A refusal is now the whole call's answer only when EVERY family you selected
  refused, which is what a malformed `type=` or FormID does; anything narrower is reported in that family's own
  section, beside the families that answered.

- **Fixed: `findings=['dialogue']` states that a quest's own CK-parity check passed.** It reported the quest's
  `NextAliasID` (ANAM) and objective `Flags` (FNAM) subrecords only when something was WRONG with them, so a
  quest whose parity was fine said nothing at all and you could not tell a check that ran and passed from one
  that never ran. `housecarl_validate_dialogue` has always stated it; both now say it from one sentence.

- **Fixed: a `DLVW` or `DLBR` seed states its verdict, and the dialogue boundary claims only the checks that
  ran.** Those two record types own no INFO list, so a record-level CK-parity check is the whole of what
  `findings=['dialogue']` can do with them. The seed rendered its head and nothing else when that check PASSED —
  you could not tell it from a check that never ran — while the family's closing boundary went on to assert
  branch and quest wiring, LinkTo and previous-link targets, `.fuz` files, result scripts and conditions, none of
  which had anything to run against. A passing view or branch now carries its own OK line naming the subrecords
  its kind is checked for, `housecarl_validate_dialogue` and `housecarl_check` state it from one sentence, and
  where every seed a call reached was one of those two kinds the boundary says so and names none of the rest. A
  call that also reached a quest or a topic keeps the wide boundary — it is true of that response — and the
  record-level seed carries its own scope note under it. In `format='json'` each seed gains `checks_run`
  (`record_parity`, `topic_graph`), because an empty `input_issues` alone cannot tell a check that ran and passed
  from one that never ran.

- **Fixed: the dialogue family says what it reached, in its own units, and one word means one thing.** Its scope
  note claimed "it validated exactly the N seed(s) given in `seeds=`" using the number you NAMED, so a call whose
  `limit=` stopped it short claimed a completeness the accounting three lines below denied. It now uses four words
  for four populations, everywhere it states them: seeds **named** (what you wrote in `seeds=`), **reached** (what
  the `limit=` budget let it try), **validated** (reached seeds that produced a report) and **unreachable**
  (reached seeds that produced a named reason instead). The scope note says how many it REACHED — that number
  counts the seeds which came back with a reason, so under "validated" it contradicted the `[X] … NOT validated`
  rows in the same section — and the counts line states validated against reached rather than as a bare number.
  Its own truncation was reported as "plugin section(s) were rendered" — the errors family's wording, for a family
  that never opens a plugin — and now counts seed sections.

- **Changed: `format='json'` states each family's totals in the family object and what the response carried of
  them in that family's `accounting` — no number in both.** The dialogue family object now carries
  `seeds_named`, `seeds_reached`, `seeds_validated`, `seeds_unreachable_total`, `topics_found` and
  `findings_found`, in every mode including `counts_only=true`; its `accounting` carries only
  `seeds_not_reached_by_budget`, `limit`, `dialogue_topics_rendered`, `seeds_unreachable_named`, `rendered` and
  `truncated`. What this replaces: `topics_validated` was written TWICE into the same family object — once by the
  family and once by its accounting — so which value you got depended on your json parser; `seeds_named` and the
  topic and finding totals each had a second spelling one level down; and the whole seed block was gated on the
  topic listing, so a `counts_only` call whose seed budget had cut it said nothing about that in json while the
  text render said it. If you read `topics_validated`, read `topics_found`; if you read
  `accounting.seeds_named` / `accounting.seeds_reached` / `accounting.seeds_unreachable_total` /
  `accounting.dialogue_topics_found` / `accounting.dialogue_findings_found`, read the family-level
  `seeds_named` / `seeds_reached` / `seeds_unreachable_total` / `topics_found` / `findings_found`.

- **Changed: `format='json'` names the three states a family can be in, not two.** `families_ran` now lists the
  families this response ANSWERS for; it was filled from what you SELECTED, so a family whose whole section was a
  refusal appeared there and a consumer reading it as "these have findings" got a false negative it could not
  detect. `families_refused` is new and carries each refused family with its ground. `families_not_run` is now
  `families_not_selected`, which is what it always held.

- **Fixed: a `counts_only=true` dialogue response no longer carries an empty `seeds` array.** The array was
  opened outside the mode's own gate, so the one mode whose whole claim is that it renders no rows carried
  `"seeds": []` beside a non-zero `seeds_validated`. Both sibling families already gated their row arrays this
  way. The `seeds_unreachable` roster is still written in both modes, by design — a seed nobody could reach
  bounds the answer rather than sitting inside it.

- **Fixed: `housecarl_check` says which files a family did not sweep even when that family refused.** The
  off-order sentence — "the scripts family did NOT sweep X: that plugin is on disk but not in the active load
  order" — was written only where the scripts family had run and answered. So on a call naming two plugins where
  the scripts family refused over the second, nothing said why the first was never in its scope either, while the
  tool's own parameter text promises the response says so per family. It is now stated above whatever that
  family goes on to say, refusal included, in both formats.

- **Fixed: `housecarl_check` checks the narrowing parameters every family shares before it runs any of them.**
  `type=`, `formids=` and `exclude=` were parsed inside the two SWEEP families, and those only run when you select
  them — so `findings=['dialogue']`, the one family none of those parameters scope, accepted `type="NOTATYPE"`, a
  malformed FormID token and an `exclude=` value that is neither a filename nor a group, and answered as though
  nothing were wrong. Each now refuses the call by name, in both formats. A blank or whitespace-only entry in
  `plugins=` is refused too: it was dropped before the tool decided whether your scope had resolved to anything, so
  `plugins=['  ']` swept the WHOLE order — the ~8-minute unscoped scripts sweep above — with `plugins=` silently
  discarded. `housecarl_check_errors`, `housecarl_validate_scripts` and `housecarl_validate_dialogue` already
  refused these; this is `housecarl_check` refusing them at the same point.
  What did NOT move: `exclude=` naming a real filename that a family's own scope does not contain is still that
  family's refusal, in that family's section, because each family's scope differs and raising it would refuse a
  call another family can answer.

- **Fixed: `housecarl_check` no longer discards a refusal it holds.** A call refused as a whole only when EVERY
  selected family refused, and it then returned the FIRST family's reason. With `findings=['errors','dialogue']`,
  an `exclude=` that emptied the errors scope and no `seeds=`, both families refused for different reasons and
  you were told only about `exclude=` — so you fixed that, called again, and met the dialogue reason. Both
  answers were true; the response was one reason short of what it had. A call now collapses to a single error
  exactly when every refusing family gives the SAME reason; different reasons are rendered as sections, each
  carrying its own. A call selecting one family is unchanged: one family has one reason, so it still collapses.

- **Fixed: `format='json'` sizes each family's accounting at the depth it writes it at.** The accounting's room
  was reserved by serialising it into a bare document, then written inside `families.<family>` two levels
  further in — and an indented document pays two spaces a line per level, so the reserve was short by that
  indentation on every line of every accounting: roughly 500 bytes across three families with a ten-row roster.
  The reserve also did not measure the four dialogue seed fields at all. Both were absorbed by slack rather than
  overrunning, which is exactly why they are measured now.

- **Fixed: `housecarl_validate_scripts` stays inside its own `max_chars`.** On a 3800-plugin order at the
  defaults it returned 80,673 characters against its 80,000 cap and said nothing about it: the record loop
  stopped at the cap, and then the truncation marker and the boundary footer were appended anyway. Both are
  now held back out of `max_chars` before the listing is built, so the response ends inside its cap — the same
  order and the same defaults now return 79,784. The response also gains the accounting `housecarl_check_errors`
  already had: how many of the record sections the sweep found appear above, how many of the findings the
  `limit=` budget admitted (with the true totals restated per class), and which knob moves each.

- **Fixed: `housecarl_validate_scripts` with `format='json'` applies `max_chars` to its record roster.** The
  roster was written outside the budget entirely, so a `max_chars` you passed did not bound it. Each record is
  now measured before it is written, and the document states how many of them it carries.

- **Fixed: `format='json'` sizes every row it writes, at the depth it writes it at.** Dangling entries,
  `counts_only` histogram rows and excluded-roster rows were offered to the budget at a declared size of zero or
  measured two nesting levels shallower than they are written — an indented document pays two spaces a line per
  level, so the shortfall grew with the row. A response could therefore land over the `max_chars` you passed:
  measured, `housecarl_check` returned 6,246 characters against an allowed 5,709. Every row is now measured as
  the document will encode it, including its indentation and the separator it owes for following another row, so
  a response ends inside its cap and the cut it reports is the cut it made.

- **Changed: `format='json'` no longer writes accounting counts for subjects a response does not have.**
  `accounting.excluded_plugins_total` / `_named`, `accounting.unread_plugins_total` / `_named` and
  `accounting.dangling_missing_by_source` / `_total` were written on every response, so a response that could
  not have any of them reported `0` and an empty list — the same "looked, found none" reading the fields beside
  them already avoid by being present only where their subject is. They now follow that rule too. Where you will
  see it: `findings=['missing_masters']` lists no dangling references, so it carries no dangling-by-source
  roster; a `counts_only=true` response carries none either; and on `housecarl_check` a family refused before it
  ran — `findings=['dialogue']` with no `seeds=` — now states its refusal and the `max_chars` it was given, and
  nothing about a plugin scope it does not have. The text render already said nothing there, so this is the two
  formats agreeing rather than a new claim. If you read one of these fields unconditionally, check it is present
  first: absent means this response has no such subject, which `accounting.listing` and the family's own counts
  already tell you.

- **Fixed: `housecarl_check_errors` now says how many findings its answer is missing, and stays inside
  `max_chars`.** The response used to describe what it left out from two separate places, in two different
  units: the listing budget said how many refs `limit=` never listed, and a truncation notice said how many
  plugin sections `max_chars` dropped. Neither could see the other, so neither answered "how many of these can
  I actually see" — on a 3800-plugin order at the defaults the two together reported 3996 not listed and 554
  of 1000 shown, while 554 of 4996 was the answer. There is now one line, and it states that number first,
  then splits it by cause and names the knob that moves each. Two things follow from computing it after the
  response is built rather than where a loop stops. A cut landing inside the LAST report section used to print
  nothing at all — no notice, and the response ran past `max_chars` while doing it; it is now reported like any
  other. And `format='json'` used to check its budget once per plugin, so a single plugin with more findings
  than the cap could hold wrote all of them: one real plugin returned 202,425 characters against an 80,000 cap
  and reported `truncated: false`, which was true, because the cap had not been applied. The check is now per
  finding.
  The accounting and the boundary footer are held back out of `max_chars` before the listing is built, so
  neither is appended past it. That costs the listing a little of its room: on a 3800-plugin order at the
  defaults the response lists 538 findings and ends just inside 80,000 characters. There are two cases
  where a response is still longer than the `max_chars` you gave it. One is a `max_chars` too small to hold what the
  response must carry whatever the budget — its header, that accounting, the closing line for anything it cut short,
  the boundary; there the response says so, states its own length including the sentence saying it, and names the
  number that clears it. That number is the smallest `max_chars` the response fits in, within a few characters:
  setting `max_chars` to it clears the notice, and it is measured off what the response actually carries rather than
  counting the notice itself or a lane's spare room. On a 3800-plugin order, `counts_only=true` at `max_chars=1200`
  returns 1,540 characters and names 1,277; that call returns 1,269. The other is a `format='json'` response running
  over by one body unit
  whose size is not known before it is written; it now says THAT instead — the fixed-part explanation is false
  there, and it was the one every overrun got. Every other part of the answer is now inside the cap: the two
  `counts_only=true` histograms (which took `limit=` as their only bound, so a wide tally could run many times past
  the `max_chars` it was given), the list of plugins whose records could not be read, and the list of plugins that
  could not be parsed — the last of which `format='json'` wrote with no bound at all. A `counts_only=true` histogram
  can lose its ROWS to `max_chars`, but never the line saying how many are missing and which knob moves them: that
  line is held back out of `max_chars` alongside the accounting, so the pressure that dropped the rows cannot drop
  the report of it, and an axis with nothing to tally says that instead of nothing at all. Each axis holds back its
  own line — 145 and 144 characters, plus 77 for the mode note the first axis carries — which is body room its rows
  do not get; an axis that turns out to have nothing to say gives that room back, so on a 3800-plugin order at the
  defaults, where both axes render whole, the response is the same 10,530 characters it was before. A
  `counts_only=true` response with nothing to account for — nothing unread, nothing unparseable, no listing — no
  longer holds room for the accounting line either, because that lane cannot write one; measured on a two-axis
  result of that shape, 186 characters go back to the histograms, worth three rows at a cap that bites. A response
  whose sweep DID have something to account for reserves what it always did. The two
  `counts_only=true` axes are cut independently: `limit=` stopping the by-TARGET axis no longer stops the by-SOURCE
  one, which used to render none of its rows under a "raise `max_chars=`" that would not have moved them. In
  `format='json'` each histogram object now carries `cut_by` — `"limit"`, `"max_chars"`, or `null` where the axis
  is whole — so the two formats name the same cause for the same result. A `format='json'` response exactly one
  character past its cap also now reports the overrun; the length it compared was short by the cost of closing the
  document, so the smallest overrun there is was the one that said nothing.
  A report section is now emitted whole or not at all: what a section says besides its dangling entries — a
  scan error, the masters it declares that are missing, how many records could not be read — is a finding in
  its own right, and used to be dropped a line at a time with nothing recording it. The two things a cut can
  drop are a whole section and a single finding, and the line above states both — including on
  `findings=["missing_masters"]`, which lists no dangling refs at all and so makes no claim about them, but
  still says how many plugin sections of how many it rendered.

- **Changed: `housecarl_check_errors`'s `format='json'` names the plugins that lost findings in one place, and names
  ten of them.** The top-level `dangling_not_listed_by_source` object is gone; the same roster is now
  `accounting.dangling_missing_by_source`, beside the counts it belongs to;
  `accounting.dangling_missing_by_source_total` states how many source plugins there were in all. It carries the
  ten with the most findings, where the field it replaces carried two hundred. Both changes follow from the
  accounting being held back out of `max_chars` before the response is built: a field written from a second
  source could disagree with the counts beside it, and a two-hundred-row roster cannot be held back — measured
  on a sweep whose findings come from two hundred plugins, reserving two hundred rows raises what a
  `format='json'` response must carry whatever the budget from 2,812 characters to 20,864, which is room taken
  from every response whether or not anything was dropped. Ten is what the text render has always named. If
  you were reading the wider list, read
  `accounting.dangling_missing_by_source_total` for the count and re-run with `plugins=` to get the rest.

- **New: `exclude=` on `housecarl_check_errors` leaves plugins out of the sweep.** Pass plugin filenames with
  their extension, or a group name: `base_masters` (the five the game ships with) or `implicit` (every plugin
  the order force-loads because `plugins.txt` does not list it — this is where Creation Club plugins and
  `_ResourcePack.esl` are, and it includes the base masters). An excluded plugin is not walked, does not spend
  `limit=`, and is in no total; the response says the scope was narrowed. What the response calls the vanilla
  BASELINE does not change with it — that stays the base-master set Mutagen defines, whatever you exclude.
  A value that is neither a filename nor a group name, a filename YOU NAMED that nothing in scope matches, and
  an exclusion that removes everything are each refused before the sweep runs, and each refusal names what it
  expected. A group is a filter rather than a claim, so a group whose members are not all in your scope is not
  an error — `plugins=` narrowed to one plugin with `exclude=["base_masters"]` drops whichever base masters are
  there and says nothing about the rest, and the count the response states is what YOUR scope lost, not how many
  plugins the group name stands for. If the MO2 profile's plugin list cannot be read, `implicit` cannot be worked
  out at all and a call that asked for that group is refused rather than quietly excluding nothing; a call that
  named plugins instead is unaffected, because those need no profile read.

- **Changed: `housecarl_validate_scripts`'s TEXT response says what a `max_chars` cut dropped from its
  excluded-plugin list.** In that render the list is now charged to `max_chars` like the rest of the response, so
  a tight one can cut it short or drop it whole. Where that happens the response says which list did not fit and
  how many plugins the index could not parse are therefore unnamed — the count is the ones it did NOT name, so a
  response that named some of them says so, instead of a bare "truncated" marker under a heading that may itself
  be gone. `format='json'` is unchanged here: its copy of that list is not charged to `max_chars`, and this entry
  makes no claim about it.

- **New: `source_provider=` reaches a mod MO2 is not currently loading.** `housecarl_place_asset` and
  `housecarl_bulk_place_asset` resolve a named provider against the mods MO2 loads, and — when no provider of that
  name is among them — against the MO2 mod folder of that name on disk: the loose file first, then that folder's own
  archives. So the copy inside a mod you have switched off can be placed by naming it, without switching it on. This
  is the same rule the plugin side already follows, where naming a plugin resolves it whether or not it is ticked.
  A read served that way says so in the result, naming the mod it came from. Naming is what reaches it: with
  `source_provider=` omitted, resolution still sees only the mods MO2 loads, `*winner` is still the winner among
  those, and a contention list still names only those — so a mod you did not name cannot be read, be reported as the
  winner, or appear as a copy to choose between. A name that supplies the path in neither place is refused, and the
  refusal says which places were looked in and names the other providers when there are any: whether the name is one
  the active order already provides files under, whether there is no mod folder of that name, whether the folder was
  searched and holds no copy, whether something in it could not be read (an unknown, not an absence), or whether the
  name is path-shaped and so is not looked for on disk at all.
  For a mod MO2 *is* loading nothing changes, including how you reach a file inside its archive: that is the
  archive's own filename, as before, and `housecarl_asset_status` lists it under that name.
  `housecarl_asset_status` answers for the mods MO2 loads, so a path only a switched-off mod provides reads as
  absent there while remaining placeable by naming that mod — the `source_provider=` description and the
  `housecarl_copy` asset readback both say so.

- **Fixed: a refused in-place call no longer spends your one-time confirmation.** The in-place lanes ask you to
  confirm the first time they touch a given file, and remember the answer. That confirmation used to be recorded when
  you passed `acknowledge=true`, before the write was attempted — so a call that was then refused, and wrote nothing,
  had already spent it. Removing a record the target does not carry, editing one it does not define, forwarding from
  a source that does not have it, creating a record that links to a plugin you have not enabled: each of these is
  refused with your file untouched, and each used to bank the confirmation for that plugin. The next in-place write
  to it — the first one that actually rewrote your original — then went ahead with no prompt. The confirmation is now
  recorded after the write lands, in every in-place lane (`housecarl_apply`, `housecarl_create`, `housecarl_remove`,
  `housecarl_forward`, their 1.x spellings, and `housecarl_nif_set`), so no refusal can spend it. What each
  confirmation covers is unchanged: for the plugin lanes it is the whole plugin and it is shared between them — see
  the `housecarl_remove` entry below for what that means when you follow a refusal into the in-place lane — while
  `housecarl_nif_set` confirms one mesh file, separately. If houseCARL cannot save the confirmation it says so, and
  asks again on the next in-place call. (#378)

- **Fixed: `housecarl_remove` told you to create a patch it cannot create.** Naming a patch that does not exist —
  `housecarl_remove(..., into="My Patch.esp")`, or `housecarl_remove_record(..., patch="My Patch.esp")` on the 1.x
  spelling — is refused, and that refusal ended "Omit into= to create it fresh, or check the name." Doing that got
  you a second refusal: removal has no fresh-patch lane at all, because it only drops a record the patch itself
  already carries. The refusal now says that instead, and names the lane a removal does have —
  `in_place="<plugin filename>"` on `housecarl_remove`, `target=<plugin filename>` +
  `in_place=true` on the 1.x `housecarl_remove_record`, each tool naming the lane it declares. Know what that lane
  costs before you follow the suggestion: it rewrites your original file, with no houseCARL backup or undo, and its
  one-time confirmation is per plugin and shared with the other in-place lanes — so if you have already acknowledged
  that plugin, in any lane or any earlier session, the write happens with no further prompt. See the in-place entry
  below for what that lane refuses. Every write tool that *can* create a patch still says so, each on its own
  behalf. (#356)

- **The record-editing lanes now refuse a localized plugin in place instead of scrambling its text.** Editing,
  removing from, creating into, or forwarding into an existing plugin **in place** re-serializes that whole plugin —
  `housecarl_apply`, `housecarl_create`, `housecarl_remove` and `housecarl_forward` with `in_place="X.esp"` (and
  their 1.x spellings `housecarl_set_field` / `housecarl_bulk_apply` / `housecarl_create_record` /
  `housecarl_bulk_create` / `housecarl_remove_record` / `housecarl_forward_record` with `in_place=true`), plus
  `housecarl_compact_plugin`'s rewrite of external referencers under `repoint_externals=true`. A plugin flagged
  *localized* keeps its names and descriptions in separate `.STRINGS` files and carries only numbers pointing into
  them; the re-serialize renumbers those pointers, houseCARL saved only the plugin, and the rewritten plugin then
  read its text against the old, unchanged `.STRINGS`. Values came back attached to the wrong records — a weapon
  showing a book's name — with the tool reporting success. Not every value: in the measured case some records kept
  their text, some went blank, and others picked up a different record's, which is worse than a clean break, because
  spot-checking a few records can leave you thinking the file is fine. It did not need anything unusual about where
  the strings lived, either: a plugin whose `.STRINGS` sit right beside it, reading correctly everywhere else, was
  corrupted the same way.

  These lanes now stop before writing anything and tell you the plugin is localized, why houseCARL will not re-emit
  it, and what to do instead where there is something to do. Nothing is written or staged. A plugin whose header
  cannot be read at that moment (a lock from MO2 or xEdit, say) is treated as not-localized, so the call proceeds and
  is refused at the write instead, with a message that does not name this lane's remedy; the file is untouched either
  way, and neither refusal costs you a confirmation (see the consent entry above). A dry run gives the same refusal
  the real call does, rather than reporting an edit that would then be refused.
  `housecarl_compact_plugin` checks the referencers it would rewrite *before* it compacts
  anything, so it refuses up front rather than renumbering your plugin and then stopping partway through the plugins
  that point at it — and it refuses before asking you to confirm the rewrite, instead of after.

  **`housecarl_compact_plugin(in_place=true)` refuses a localized plugin too**, for a different reason. A compaction
  does not re-serialize your plugin, it builds a fresh one and writes that over the original — so it never hits the
  check above, and what it would produce is a **non-localized** plugin carrying whichever language resolved when
  houseCARL read it, with the mod's `.STRINGS` set left describing nothing and any other language it shipped gone.
  If the strings resolved nowhere at all (see the bound described below), blanks get baked in instead. Neither is
  something to do silently to a file with no review step and no undo, so that lane now refuses up front and points at
  the new-file lane, which now says the same thing in its own report rather than only when you are refused.
  Compacting to a new plugin keeps your text wherever houseCARL can resolve your strings — see the bound below; its
  output is not localized either, so read it before you enable it.

  Writing a NEW plugin is otherwise unaffected: the default patch lane, `housecarl_merge_plugins`, and
  `housecarl_compact_plugin`'s default new-file lane all build their output fresh with the text stored inside the
  plugin, and leave your original alone. (Extending an existing patch with `into=` does re-serialize that patch, so
  it is in-place in this sense — but it only ever targets a folder houseCARL owns, and houseCARL does not author
  localized plugins.) The refusal fires on any plugin carrying the localized header flag. Which of your plugins
  carry it depends on your install: the official masters always do, and translated releases commonly do, because
  that is what the translation toolchain emits. No houseCARL tool reports the flag today, so there is currently no
  way to answer "will this hit me?" from inside houseCARL — xEdit shows it on the file header.

  Making these lanes rewrite a localized plugin *correctly* is a larger change — it decides what an in-place edit is
  allowed to write besides the plugin file itself — and is being designed separately. Until then houseCARL refuses
  rather than corrupt a file it cannot faithfully re-emit.

- **`housecarl_merge_plugins` and `housecarl_compact_plugin` now say what they cost your runtime config files.**
  Neither verb reads SPID, KID, SkyPatcher or Open Animation Replacer configs, and neither rewrites them — but both
  can invalidate lines in them, and nothing said so. Merge now states that a line naming a donor stops matching once
  you deactivate that donor at the swap. Compact states the half that applies to it: the plugin name survives a
  compaction, so what breaks is a line addressing a record by an object id the compaction moved, once the compacted
  plugin is the one loading.

  Both sentences deliberately describe only what the operation did, and say nothing about how any of those config
  formats are written. Earlier drafts tried to be helpful about the syntax and got it wrong twice — the four systems
  share neither a file format nor a way of naming a record, and each attempt would have sent you looking for something
  three of them never contain. What the reports owe you is what *they* changed; the bundled skills are where the
  grammars live. (#364)

- **Fixed: `housecarl_merge_plugins` and `housecarl_compact_plugin` blanked every localized name and description.**
  Both verbs opened their donor / source plugins with an overlay that looks for `Strings\` only in the plugin's own
  folder. A localized plugin whose `.STRINGS` are served from elsewhere — the common case, where a cleaned or
  translated master's strings live in the game's `Data` folder rather than in the mod folder MO2 resolves the plugin
  to — therefore read every `FULL` and `DESC` as empty, and the merged or compacted output was written with those
  blanks baked in. Nothing failed and nothing warned: the result loaded, and the loss was visible only in game or by
  diffing. Both opens now go through the same strings-aware path the rest of houseCARL reads with, which falls back to
  the game `Data` folder when the plugin's own folder carries no strings source, and leaves plugins that do carry one
  untouched.

  That redirect has a bound worth knowing, because it decides whether this fix reaches your case: it applies only when
  the plugin's own folder carries no strings source at all, and **any** `.bsa` sitting beside the plugin counts as one
  — whatever that archive actually holds. A localized plugin in a mod folder that ships an asset-only `.bsa`, with its
  `.STRINGS` served from elsewhere, is therefore still read the old way and still writes blanks. So is a plugin whose
  strings are in neither place.

  Both of those cases are unchanged by this fix. A third — `housecarl_compact_plugin` rewriting each **external
  referencer** under `in_place=true` + `repoint_externals=true`, over a plugin the user never asked to compact — is
  no longer reachable: that whole operation is now refused up front when any referencer is localized (see the
  in-place entry above). (#362)

- **`housecarl_merge_plugins` now accepts a single donor, which renames a plugin.** Merging one plugin into a new
  name was refused ("merge needs at least TWO distinct donor plugins"), and no other tool renames one, so a
  mis-named patch could only be fixed by replaying every edit into a freshly named plugin. There was never anything
  behind that refusal: with one donor the collision set is simply empty, and the machinery a rename needs is the
  machinery a merge already runs — every donor record moves to the output's identity, and the facegen, voice, and
  `.seq` files follow the plugin **name** that forms part of their paths. Passing one donor now does exactly that,
  keeping every object id already inside the writable range — an id below the `0x800` floor still renumbers, which
  nothing can collide with either, and the per-donor line reports it — and the report calls it a rename rather than a
  merge "from 1 donors". Zero donors still
  refuses, and the refusal names both shapes. The list of donors is a set, so a plugin named twice is one donor —
  also a rename.

  The costs of renaming are inherent, so they are reported rather than refused: the renamed plugin arrives in a new
  mod folder beside the original, and the swap instruction applies unchanged — deactivate the old **plugin**, but keep
  its mod **folder** enabled, because the renamed records still load that mod's *loose* meshes, textures and scripts
  by path. Anything the donor ships inside a **`.bsa`** is the exception, and the report says so: an archive stops
  loading once its same-named plugin is deactivated, so extract it into the mod folder with `housecarl_bsa_extract`
  or keep it loading behind a same-named dummy plugin from `housecarl_create_plugin`. Any save that referenced the old
  plugin name will not survive — the existing saves warning — and any plugin that references or overrides the donor,
  **its own patches included**, is named in the warnings with the remedy.

  The report now says what is true **of the operation you actually got**, because it decides which one that was in
  one place. A rename names only the renumber cause that can apply to a single donor, since nothing can collide with
  it; it leads its warnings with the remedy that keeps the result a rename — re-point the affected plugin, or rebuild
  it — and offers combining second, because adding that plugin as a donor produces a combined plugin instead; and its
  new mod folder is named `<output> renamed` rather than `<output> merged`. Renaming a plugin that originates no
  records of its own, which is what most mis-named patches are, says exactly that instead of claiming records took a
  new identity.

  Losses that were previously silent are now stated, for merges of any size, because the merged plugin is built with a
  fresh header and nothing in a donor's header comes along. **Light (ESL) status is not carried** — counted by the
  header flag *or* an `.esl` extension, since the engine treats the extension as light either way — so the output takes
  a full load-order slot where a light donor took none. The report says so and names `housecarl_compact_plugin` along
  with its cost, that it renumbers object ids from `0x800` upward and so moves the ids just reported as kept; where
  that note appears, the closing "want it light?" line steps aside, so the recommendation you read carries its cost.
  **Master status is not carried either** — counted by the flag or an `.esm` extension — so an esmified donor comes
  back as a plain plugin and sorts in the plugin block. **Nor are the header Author and Description.** Those last two
  are stated with no remedy offered, because the tool surface has none. (#345)

- **Fixed: on a large load order, a mod's broken references could vanish from `housecarl_check_errors` entirely.**
  The dangling-reference listing budget (`limit=`, default 1000) is one counter spent plugin by plugin in load order,
  and the base-game masters sit at index 0. A plugin whose findings collected an empty list was then dropped from the
  report altogether, so its broken references were not merely buried — they were unreachable, and the only trace was a
  global "capped at limit" line that named no plugin. The budget is now spent on every other plugin **before** the
  base-game masters, whose dangling references are permanent vanilla leftovers no load order can fix, and a capped
  listing now says how many plugins lost entries, names the ones that lost the most with a count each, and states
  how many it did not name.

  Each sentence about something you cannot see reports **only what its own layer dropped**, because there are two
  independent cuts and adding them together would be wrong. The capped line's subject is always the listing budget
  ("the listing budget (`limit=`) omitted N dangling ref(s)"). Separately, when a response is too long for
  `max_chars`, the truncation notice now says how many plugin sections of how many went unrendered and that the last
  one may be partial — previously it said only that something had been cut, so a plugin whose findings the response
  dropped for length left no trace at all. In `format='json'`, `plugins_with_findings` sits beside `rendered` and
  `truncated`, so a consumer can compute the dropped count exactly.

  The response also splits the dangling total ("N of M come from the base-game masters ...; K from the rest"), and
  `counts_only=true` adds a **by-SOURCE-plugin** histogram beside the existing by-TARGET one: the target axis names the
  absent dependency behind a wall of findings, the source axis answers how much of the wall is vanilla and how much
  your mods introduced. Baseline means Mutagen's own base-master set — Skyrim, Update, Dawnguard, HearthFires,
  Dragonborn — and the response names them rather than leaving "base-game" to interpretation; Creation Club plugins are
  not in that set and still count as part of your load order.

  On a very large order this frees the budget without making every finding listable: measured on a 3800-plugin order,
  the base masters account for 398 of 4996 dangling references. That is what the named omissions and the source
  histogram are for — they tell you which plugin to scope `plugins=` to next, instead of leaving you to guess that
  anything was missing at all. Scoping to one plugin re-spends the whole budget on it, which lists its set in full
  unless that one set is itself larger than `limit=`.

- **Fixed: the refusal for "no such patch to extend" now says how to give a new patch a name.** Guessing
  `into="My Cool Patch.esp"` for a patch you have not created yet is refused, correctly — but the only remedy it
  offered was to omit `into=` and create the patch fresh, which is precisely the call that produces a generically
  named `Patch.esp`. `patch=`, the parameter that names a new patch, was documented only in the parameter list
  itself and in no workflow doc you would read first. The refusal now hands back the call you meant, with your own
  guessed name already in it — `pass patch="My Cool Patch"` — and says what omitting it costs. This matters more
  than a wording nit because there is no rename primitive: the name you get on the first write is the name you
  keep. `patch=` is now documented as well, in the core workflow beside `into=`.

  It offers the name without promising the filename, because houseCARL auto-suffixes a name that is already taken —
  either by a mod folder it already made under that name, or by an active plugin. **Read the patch name back off
  the response**; both names the sentence mentions carry that qualifier, the one you choose and the `Patch` default.

  The rule for which tools say it: exactly those whose `patch=` names a **new** patch defaulting to `Patch` — the
  field-write, record-creation and forward lanes. Everywhere else the shorter, always-true remedy stands, because
  the naming sentence would be false there: a removal edits a patch that already exists and cannot create one; a
  closure copy or an appearance copy names its fresh patch after the new EditorID; and the tools that place a file
  into a patch folder each default to their own stem, never to `Patch` — with `bsa_repack` a further case, where
  `patch=` names the `.bsa` itself rather than the mod folder.

- **Fixed: reading a cell's placed references could report an empty cell the game fills.** Placed references, a
  topic's INFO lines and a worldspace's cells are declared **per plugin**, and the game assembles a parent's
  children from every plugin that declares them. So a plugin that overrides a cell for an unrelated reason —
  occlusion planes, lighting, music — carries no references and deletes none either, yet reading that winner's
  `Persistent` / `Temporary` showed you its own empty list with nothing to suggest otherwise. Anyone auditing
  "what is in this cell" through the winner got a plausible, confident, wrong answer: on one order, Dawnstar's
  exterior cell read 0 references at its winner while the game loads the 201 that `Skyrim.esm` declares.

  `housecarl_read_record`, `housecarl_batch_record_detail` and `housecarl_cross_plugin_query` now say so, in two
  tiers. **A load-order read** of a field that owns child records notes how many other plugins touch that record
  and that this read did not open them — free, because it comes from the load-order index rather than from opening
  anything. (Two lanes deliberately stay silent, because a load-order statement would be wrong there: a read
  scoped to a file outside the load order, and the SkyPatcher overlay pole.) **`conflict_tree=true`**, which already fetches every touching plugin's body, additionally **names
  which of them declare content** for each field, at no extra cost. The split is deliberate: naming the plugins
  requires reading their bodies, and doing that on every read took a single Dawnstar cell read from 27 ms to
  588 ms, a worldspace read to 2.5 seconds, and a whole-order cell catalogue past ten minutes.

  What is annotated comes from the same list the write surface uses to preserve children — a cell's `Persistent`,
  `Temporary`, `Landscape` and `NavigationMeshes`, a topic's `Responses`, a worldspace's cells — never a
  hand-kept set of cell fields, and it costs nothing on a read of any other record type. Two kinds of child field
  get two different statements, because two different things are true of them: `Persistent`, `Temporary`,
  `NavigationMeshes`, `Responses` and a worldspace's cells hold **many** children and are merged from every plugin
  that declares any, while `Landscape` and `TopCell` hold **one** record that plugins override — for those, other
  plugins carrying one does not mean a bigger total, it means load order decides which you get, and that the child
  exists even though the body you are reading has none. A plugin that merely touches the parent without declaring
  children is never named, including a worldspace override carrying block scaffolding but no cells. Reading a
  specific plugin's version is annotated too, because that body is not the whole set either — the plugins **above**
  it declare children it cannot see. The value itself is untouched: the annotation sits beside it, and a write can
  still reuse the token verbatim. A `to_file=` artifact carries the note on its rows and the sentence explaining it
  on the manifest line, so a catalogue you re-open next week still says what it means.

  Note what this is not — houseCARL does not yet have a read that answers "what is actually live in this cell"
  (every child at its own winner, minus the deleted and disabled ones); that is separate work, and this annotation
  deliberately promises nothing about it.

- **`housecarl_copy`** — copy a record together with the records it depends on (its link closure) into a patch under new FormIDs, so the result no longer masters the plugin you copied from. The walk starts from the link-bearing fields you name (`seed_paths=`) and is bounded by the record types you exclude (`exclude_types=`), so the tool stays generic and the domain knowledge is yours to supply. `from_source=` is an ordered list of sources tried first-hit-wins — `winner` for the load order's winning version, or a plugin filename, active or sitting in a disabled mod — and the result names which source produced each copied record. Destination is either an existing record (`target=`) or a fresh clone (`new_editorid=`), whose remaining links into the source are stripped and reported by name — including when clearing one takes a whole property with it. When nothing is being copied away from at all — the source and every named source are base-game masters — the result is reported as an appearance transplant rather than a standalone-ization, because an always-loaded master is not being removed from anything. An off-order link the finished patch still carries is refused, and the refusal names which cause: your own `Type:stop`, a field `seed_paths` never named, or a record an earlier call left in the patch you are extending.

- **New skill: `npc-appearance-copy`** — the domain half of `housecarl_copy` for NPC faces, carried as data and flow rather than as tool code: which four link-bearing fields seed the walk, why a Race is excluded rather than walked into, which inline fields (tints, morphs, `TextureLighting`, weight) ride `housecarl_apply`'s copy zip instead, and how the FaceGen mesh + tint are placed under the new FormID from the **named donor** rather than the VFS winner. Also states the two things the split costs: three calls means three refusal surfaces, and a donor sitting in a disabled MO2 mod is a records-only job until its files can be named.

- **Fixed: the record reference called two owned child records FormLinks.** `Cell.Landscape` and
  `Worldspace.TopCell` hold a record outright — the cell owns its landscape, the worldspace owns its top cell — but
  the schema the `mutagen-reference` skill serves classified both as links to one. Following that, you would have
  set a FormID on a field that holds a whole record: accepted at the pre-flight check, then thrown at write time.
  Both now read as what they are, pointing at the child's own record entry, and every way of writing *at* the field
  answers in one voice that names it a record: a FormID, a composed value, a list of composed values, clearing it,
  and copying it across from another plugin. To edit the child, address **that record by its own FormID** — which
  works, and is what the refusals tell you. Three things worth knowing, because they are what the old classification
  hid. A patch's override of a parent does **not** bring the parent's child records with it, so a path *through* the
  parent finds nothing there even when the original carries one. Clearing the field would have deleted the whole
  child record and everything under it — a worldspace's top cell takes its persistent references with it — with no
  element named, where the list form of the same family makes you name which child by index. And copying the field
  from another plugin would have written *that* plugin's record, with its own FormID and its own children, in as
  this parent's child; to carry a child record across, `housecarl_forward_record` takes it directly. Giving a parent
  a child it does not have, and deleting one outright, are both open gaps — the refusals say so and point at the
  issue rather than pretending a way exists.

  The classifier confused the two because a record identifies itself (FormID plus type) exactly the way a link
  identifies its target. A build check now compares the classification the generator produces against the
  independent walk that preserves child records across a record replace, over every record type the library models
  — so the two can no longer disagree about which fields own a record. A second check lists every write verb against
  this shape with the answer it must give, so a verb cannot be left behind again.

- **Fixed: several list inputs didn't name every member of the object they take.** `housecarl_bulk_apply`'s `operations=` didn't mention `composes` or `from_plugin`; `housecarl_bulk_create`'s `records=` didn't mention `grid`; the `operations=` on both create tools didn't mention `composes`; the `sets=` list inside a `compose=` named two of its five members; and `housecarl_bulk_place_asset`'s `assets=` didn't mention `source_provider` (the member's own description was published all along, so it was discoverable — just not where you'd look for the element shape). Every one of these worked already; the gap was in what you were told. Separately, `source_provider` now spells out that it applies with **no** `source=` as well: there it says whose copy of the *destination* path to place, and is what resolves the contention an omitted source is otherwise refused for.

  Behind it, each documented element shape is now checked against the names the wire really binds: every name a shape lists must exist, and every member must be listed by some shape that carries its type. A member cannot be added, or a wire name misspelled, without a red build. Restatements of a shape elsewhere — in a tool's own prose, or in a refusal — are not read by that check, and neither is the case of a member documented on one carrier of a type but not another.

*Accumulating notes for the next cut — not yet released; `plugin.json` still reads the last shipped version.*

**Added: `housecarl_place_asset` can now place a copy from one path under a different name, and say whose copy to
take.** `source=` accepts a Data-relative path — the same kind of path `housecarl_asset_status` reports on — and
resolves it through the virtual file system, so the source no longer has to be a full path typed out from your
drive. Because the source and the destination are separate inputs, a source that differs from the destination is a
**rename**: one file's bytes land under another file's name, which is what carrying a baked FaceGen head onto a
different NPC's FormID path actually is. The new `source_provider=` says *whose* copy to read: `*winner` for
whichever copy currently wins, or a mod folder / BSA filename on its own. The `*` is part of the token, and it is
there so the two never collide — `*` is illegal in a Windows folder name, so a bare name always means a provider of
that name and a mod actually called `winner` stays reachable. Naming a mod means that mod: if it doesn't supply the
path, the call is refused rather than quietly served from somewhere else. Naming nothing keeps the old behaviour —
the sole provider, refused when several contend — except that the refusal now lists the providers by NAME rather
than by on-disk path, each in double quotes, and what's inside the quotes is exactly what you pass back.

**Fixed: the text and JSON responses to a write can no longer say different things.** Every write tool renders its
result twice — once as text, once as `format="json"` — and the two renders were maintained separately, so a warning
or a piece of advice could be corrected on one and left stale on the other. Nine sentences had already drifted that
way. The most consequential: the JSON note about creating an exterior cell had lost the clause saying a grid
collision is *engine* behaviour, so it read like something you could retry your way out of; a cut report block told
you "do not re-issue the write" on one transport and the more specific, actually-correct "do not re-issue the create —
that allocates the records again" on the other; and `write_seq`'s JSON standing-limit note had dropped the pointer to
`housecarl_validate_dialogue`, which is the half telling you what to do next. Every sentence named in the PR's inventory now has one
source that both transports read, so a correction reaches both or neither; the inventory also names what is left and
why. Wording is otherwise unchanged, except where the two copies already disagreed — those are resolved to the fuller
and truer reading.

**Fixed: a large `apply` no longer overflows its text response without saying so.** Its JSON twin has always dropped
trailing rows at `max_chars` and set `truncated`, but the text render listed every edit and let the host cut the
oversized response out of band — the silent cut `max_chars` exists to prevent, on the one write verb whose row list
was still unbounded. It now stops with the same explicit notice its four sibling renders carry. A truncated dry run
also no longer describes itself as a completed write.

**Fixed: forwarding a record no longer deletes the records nested under it (#324).** When `forward` targeted a record
the destination *already carried*, it replaced it by dropping the whole record and copying the source body in — and
the drop took the record's child group with it. Any dialogue line under a forwarded topic, or placed reference under
a forwarded cell, was destroyed, and the call reported success. The `in_place=` lane was the worse half: it deleted
those records out of your own plugin, on the lane that keeps no backup. The children are now lifted off before the
replace and re-attached after it, so a forward changes the record's *fields* and leaves what is nested under it
alone. Nothing about the forward semantic changes: the source's own children still stay in the source's plugin,
which is what lets a patched topic not fight another mod's added lines. If houseCARL ever cannot account for every
child across the replace, it refuses and writes nothing rather than emit a plugin it knows is short a record.

**Fixed: an in-place edit's "what landed" line is now read off the written file (#308).** The verify prints under a
banner saying every edited record was re-read off the file on disk — but the per-op half of each line ("`Add Ranks:
now 1 (+1)`") was read from memory *before* the file was written. When a composed structure exists in memory and
serializes to nothing — a Faction `Rank` composed with no fields is the reported case — the plugin didn't grow, the
list stayed empty, and the call still reported the addition as landed; it cost the reporter three more debugging
rounds on a live mod. That clause now comes off the re-opened file — for the op that last touched a given field in
the call; an earlier op on the same field is marked as the applied edit's own reading, because the file holds the
state after all of them and cannot answer for a middle one.

**houseCARL shows you both readings; it does not rule on them.** You get what the edit did in memory and what the file
says, and where the file could not answer, the response tells you which reading you are looking at. It deliberately
stops short of declaring "this op did not land" — deciding that means telling a real difference from a harmless one
(a percentage that rounds when saved, an internal type name, an empty field versus a missing one), and every version
of that judgement we built ended up accusing writes that had in fact landed. In JSON: `landed` (memory),
`landed_on_disk` (the file), and `landed_source` — `written_file`, `superseded` (a later op in the same call wrote
that field), `no_answer` (the file was re-read and didn't yield it), or `not_checked` (this lane runs no per-op file
check), plus `verify_ran` on the response. And the specific call that caused the bug is now
**refused before anything is written**, naming the fields that would give the structure content — a compose you gave
nothing to, whose every settable field is empty, cannot land, so houseCARL no longer pretends it did. **One shape that
used to work is refused with it:** composing an empty value and then filling its fields in a *later op of the same
call*. The check runs as the value is built and cannot see the ops after it, and the lane is all-or-nothing, so the
whole call is refused — the message says so and points at the one-op form (compose it *with* its fields), which cannot
half-land either way.

**Reads show the modelled type name for a sub-structure, never Mutagen's internal one.** A field like a weapon's
`BasicStats` read off a plugin on disk rendered as `[WeaponBasicStatsBinaryOverlay]` — the class houseCARL happens to
load — while the same field read from a record being edited said `[WeaponBasicStats]`. Same field, two names, and one
of them is an implementation detail. It now always reads `[WeaponBasicStats]`, in every read tool and in the in-place
write verify (where the two used to appear in a single response, two lines apart, looking like a disagreement).

**Fixed: adding a record inside an existing cell (or topic) no longer drags in the mod that wins it (#300).** Placing
a new reference into a vanilla cell pulled the cell's *load-order winner* into your patch — so a lighting overhaul
became a master your two new refs never needed, and the patch carried a frozen copy of that mod's lighting. Sorted
below the lighting mod, your patch then re-asserted those stale values, and would keep re-asserting them after the
mod updated. houseCARL now hosts the new child in the parent's **defining** plugin's version: no extra master, no
copied-in content from a mod you weren't patching. A placed reference lives in the cell's child group and survives
the cell record losing, so nothing about it needed the winner. Which plugin hosted the child is now reported per
created record (`parent: …`, `parent_host` in JSON) — including the two cases where the definer genuinely can't
answer (an injected record, or a plugin this session had to exclude), where the winner is still used and says so.

**Which shape you get is a decision, and houseCARL no longer makes it for you.** The host is a full record override and
still conflicts at record level, so wherever your patch out-ranks the mod that currently wins that cell or topic, the
parent resolves to the *defining* plugin's fields rather than that mod's. That is the **residual** shape: your patch
carries your child and a host lean enough to lose harmlessly.

Both shapes are legitimate and which one is right depends entirely on what the patch is for. A patch meant to *win* —
"patch this mod for my load order" — wants the winner's content carried forward, resolved. A patch meant to **feed**
one — "make this sit before the Reqtificator / Synthesis output" — must not master those, must not forward their
records, and must not bake in what they would regenerate. Same call, opposite right answers.

So this is now the base you build from rather than an answer imposed on you: the residual is what you get when nothing
else is said, because you can build the inlined shape deliberately, and you cannot cleanly subtract the winner's content
once it is baked in. The response **tells you** which mod currently wins that parent and which way the record will
resolve, so the choice is in front of you at write time. Whichever way you sort, the new child is carried.

**Building the inlined shape.** Forward the winner's version of the parent into a patch, then create into that patch —
your new record is hosted in the forwarded body, and you get both. Either order works: forwarding onto a parent a
patch already holds keeps the records nested under it (that order used to destroy them, which is the `forward` fix
above in this same release). The write response names the remedy too.

**Fixed: a full path to an *active* plugin is no longer treated as an off-order file (#321).** `housecarl_apply`'s
`CopyFrom` decided "is this source in the load order?" by looking up the name it was given, and a full path never
matches a filename — so `from_source=C:\…\SomeMod\Bar.esp` pointing at a plugin your order is actively serving read
the file directly and described the source as not in your load order. Usually that was only a wrong label; under a
profile switch, where the same filename is served by a different mod folder, it was a wrong *body*. `housecarl_forward` has had the rule since its own fix — a path that names the exact file your
order loads is that plugin — and `CopyFrom` now shares it. A path to a same-named *backup* still reads
off-order, as it should: the test is the file, not the name.

**`housecarl_write_seq` can finally put the `.seq` in the mod's own folder — `output_dir=` (#312).** Editing a
plugin **in place** left the two halves in different mods: the `.esp` in the mod's own folder, the `.seq` in a
freshly cut `houseCARL - houseCARL_SEQ_00N`, with `into=` unable to name a folder houseCARL didn't create. Every
regeneration then meant hand-comparing the temp output against the mod's live `Seq\` copy and deleting the
folder. `output_dir=` takes the mod-folder root and appends `SEQ\` — the same contract `housecarl_compile_script`'s
`output_dir=` already uses, including the don't-double-it guard, no houseCARL folder cut, your folder never touched
by cleanup, and a warning when the destination isn't somewhere the game actually reads SEQ files from (your MO2
mods folder, the overwrite folder, or the game's Data). It wins over `patch=`/`into=`, and says so rather than
quietly ignoring them. If a `.seq` was already at that path it is overwritten with no backup, and the response now
says `replaced` rather than `wrote`.

**The MO2 overwrite folder now counts as a place the game loads from.** `housecarl_compile_script`'s `output_dir=`
warned that a `.pex` landing in your overwrite folder wouldn't deploy. It does — MO2 maps overwrite onto the game's
Data at top priority, and it's where xEdit/CK/Synthesis output lands — so that warning was a false alarm. It no
longer fires there, and `housecarl_write_seq`'s new `output_dir=` shares the corrected rule rather than inheriting
the old one. Sharing the rule also fixed a second `compile_script` bug on the way past: `output_dir=C:\` (a bare
drive root) produced the drive-*relative* `C:Scripts`, so the `.pex` landed in whatever the working directory
happened to be on that drive. (The rule is otherwise unchanged and
still exact: a mod's own `Scripts\`/`SEQ\`, the overwrite folder, or the game's `Data\` — a *nested* path inside a
mod still warns, because MO2 would deploy it to `Data\<Sub>\…` where nothing loads it.)

**…and regenerating an unchanged `.seq` now writes nothing.** When a lane names the destination (`output_dir=`,
`into=`, or the plugin's own houseCARL folder) and it already holds exactly the bytes houseCARL would write, the
file is left alone and the response says `unchanged` (`written: false` in JSON) instead of churning the file.
Re-running after every in-place edit — which is the point of the tool — is now free. A skipped write still stamps
the file's timestamp forward when it was older than the plugin, so `housecarl_validate_dialogue`'s SEQ staleness
check keeps agreeing with it.

**Fixed: one broken plugin in your load order no longer breaks every write.** If a plugin houseCARL cannot open
sat in your active order — a truncated download, a half-copied mod folder, an interrupted xEdit save — then
*every* write failed, including writes that had nothing to do with it, with an opaque message that read like a
disk fault. Reads were never affected. Now writes that don't reference that plugin's records just work.

A write that genuinely *does* need it (its records can still be reached through a plugin that overrides them) is
refused **naming it as the cause**, with what to do — instead of the previous engine-level error. And if the
unopenable plugin is `Skyrim.esm` or `Update.esm` — the two masters every written plugin must list — nothing is
written at all until you repair it, rather than a plugin landing on disk without them.

**New tools: `housecarl_create`, `housecarl_remove`, `housecarl_forward` — the rest of the 2.0 write surface
(W3 PR 2).** The same shape `housecarl_apply` introduced — *what changes* × *where it lands* × *how it reads
back* — now covers authoring, removal and whole-record overrides.

- **`housecarl_create`** replaces `create_record` + `bulk_create`. `records=[{record_type, editorid, ops?,
  parent?, collection?, grid?}]` — **one record is a set of one**, so the single-record call is the degenerate
  case and the nested one-shot (a dialogue topic *and* its lines, a cell *and* its placed refs) needs no second
  tool: parent a spec on an **earlier sibling's editorid**, and reference one from a FormLink value as
  `'@editorid'`. `ops=` is `apply`'s op shape minus `formid` (a new record's id is allocated and reported back);
  the members a create *cannot* have — `formid`, `from`, `from_source` — are refused **by name** with what to do
  instead, rather than dropped. `records=` also takes `"@<absolute path>"`. Creating dialogue lines still
  reports **voice coverage** and **result-script binding**, and creating cells still reports the world content
  houseCARL does not author — now as typed data in `format="json"` too, not only prose.
- **`housecarl_remove`** replaces `remove_record` and is **plural**: `formids=` is set-valued, so dropping ten
  overrides is one call and one re-serialize instead of ten rewrites of the same file (the engine always took a
  list; only the tool surface didn't). All-or-nothing is unchanged — one target the file doesn't carry refuses
  the whole call. Its lane is **`into=`** (a houseCARL patch) or `in_place="X.esp"`: a removal edits an artifact
  that already exists, so it has no `patch=`, and naming *no* lane is refused with both spelled out.
- **`housecarl_forward`** replaces `forward_record`. `from_plugin=` is now **`source=`** — whose version to
  copy (a master reverts a record to vanilla). Unchanged otherwise: the response names
  the winner each copy will out-rank, a forward that was already winning is flagged redundant, `into=` replaces
  a FormKey the patch already carries, and `dry_run=` runs the real pipeline and stops before disk.

**`housecarl_forward` can now copy from a plugin that is NOT in your load order.** `source=` takes a **disabled
mod's plugin**, an unticked one, a folder MO2 never registered, or a full path to any copy on disk — the same
"read it wherever it lives" contract the read tools already had, and the same one `housecarl_apply`'s `CopyFrom`
already had. Re-asserting a disabled *old* patch's version of a record, or reading an old version's body to
convert it, no longer needs the mod switched back on first. Previously this was refused by name.

The response **states which copy on disk it opened** — a filename several mod folders provide identifies no
file, so it is reported rather than assumed (`format="json"`: `source_in_order` plus a `source_read` object),
along with the fact that the `epoch=` stamp fingerprints the *active* order and so does not cover that file's
content. A name several folders provide is refused naming each of them, with the full path as the fix. Two
things are still refused, by name: forwarding a record whose **origin plugin** isn't active (the patch would
need it as a master, which it cannot invent — unless that origin *is* the patch being written, since a plugin is
never its own master), and naming as `source=` the very file being written. A body that references some *other*
inactive plugin is refused **naming it**, instead of reading as a disk fault. And because a plugin's records are
keyed by its **filename**, a copy parked under a new name (`MyPatch_old.esp`) is a different plugin — that
refusal now says so rather than reporting the record as simply absent. Nothing changes for an active `source=`
— including a full path to one, which is recognised as that plugin rather than read as an outside file — and
`in_place=` is unaffected: the *target* of an in-place write must still be an active plugin.

All three take the one lane spelling (`patch=` | `into=` | `in_place="X.esp"` + `acknowledge=`, mutually
exclusive and **refused by name** when two are given) — except `housecarl_remove`, which has no `patch=` for the
reason above, so its lanes are `into=` | `in_place=`. All three also take `format="json"`, `max_chars=`, and the
`epoch=` stamp — **including the first-touch in-place consent prompt**, which previously carried none on these
lanes. In `format="json"` the `lane` field names **the parameter the call used** — `"patch" | "into" |
"in_place"` (`remove` can only report the last two), the
same three words on every write tool (`housecarl_apply` reported the `into=` lane as `"extend"`; it now says
`"into"` like its siblings), and it is correct on refusals and the consent prompt too, not only on success. The 1.x
tools are unchanged and stay registered through the build waves; from 2.0.0's clean cut a call naming one
answers with its successor spelling.

**`housecarl_write_seq` keeps its name and moves to the 2.0 vocabulary.** `plugin=` is **`source=`**, and it
now **resolves a plugin filename** across your MO2 mod folders (enabled, disabled, not-yet-listed), the
overwrite folder and game Data — an absolute path still works, and the response **states which copy it read**
(a filename several folders provide is refused, naming them). `patch_name=` is `patch=`; `format="json"` and
`max_chars=` are new. This call consults no load-order build, so it carries **no epoch — stated as a fact with
its reason** rather than left as a missing field.

**New tool: `housecarl_apply` — the 2.0 field-write surface (W3 PR 1).** One write call composes *what changes*
× *where it lands* × *how it reads back*, replacing `set_field` + `bulk_apply`. **Edits:** `ops=` is the edit
list — one op is a set of one, so the old single-field call is the degenerate case — and it takes the inline
array **or `"@<absolute path>"`**, the `@file` convention that retires `from_file=` along with its
inline-vs-file mutual exclusion. Both lanes now read through the same strict parser, so an **undeclared op
member is refused by name inline too** (the SDK's binder silently *drops* one, which in a large generated batch
sends every downstream refusal chasing the wrong op); a 1.x spelling inside an op — `verb`, `from_plugin` —
gets the new word in the refusal, because the alias layer only reaches top-level arguments.
**Copying a field bundle between records** is `bundle=` (the paths, uniform across pairs) × `assignments=`
(`[{target, from, from_source?}]`) — a **zip, never a product**: each target reads its own paired source, so N
targets never fan out to N×N. Everything outside the bundle is untouched *by construction*, `from_source`
defaults to the source record's load-order winner, and a cross-record pair must be the same record type
(refused by name at pre-flight, with every bad pair reported at once). It composes with `ops=` in one call.
**One lane spelling:** a new patch (`patch=`), `into=` an existing one, or **`in_place="X.esp"` — the string
names the file being overwritten**, replacing the old `target=` + `in_place=true` pair. The three destinations
are mutually exclusive and **naming two is refused by name**, as is `acknowledge=` without a lane (1.x silently
ignored `patch_name=` under `into=`). `dry_run=`, the one-time in-place consent handshake, and the
all-or-nothing pre-flight are unchanged. **Transport:** `readback=`, `max_chars=`, `format="json"` (the same
data machine-readable — a refusal is a document too, and the consent prompt is its own flag rather than an
error), and **every write response now carries `epoch=`**, the identity of the index build its winners were
resolved from. `set_field` / `bulk_apply` are unchanged and stay registered through the build waves; from
2.0.0's clean cut a call naming one answers with its successor `housecarl_apply` spelling.

**Fixed: `CopyFrom` never worked on the in-place lane.** A legal `verb="CopyFrom"` edit with `in_place` resolved
no source record and fell through to the verb engine, which has no CopyFrom branch — so it failed as *"pre-flight
accepted it but the apply threw"*, reporting a missing capability as an internal fault. The in-place lane now
resolves copy sources under the same contract as the patch lane (active-order and off-order alike), and copying a
record's own field onto itself is refused as the no-op it is.

**`housecarl_records` completed: the comparison and traversal forms, every SOURCE pole, and the full SELECT
composition (W2 PR 2).** Every staging refusal from the core wave is now a capability. **Comparisons:**
`project={"form": "delta"}` diffs the SUBJECT (`source=`) against a REFERENCE (`versus=`) and returns only what
differs — `versus="previous_provider"` answers *what did this plugin change relative to what sat beneath it*
(measured FROM the subject, never from the winner; a mid-stack subject reports what outranks it as plain fact, a
defining subject refuses rather than rendering an empty diff, and a subject that doesn't touch a record refuses
naming its actual touchers); `project={"form": "tree"}` is the conflict view as a form — every provider of each
record, winner last, each diffed against the reference pole — **now with a json render and a row form, so trees
spill to artifacts like every other result**. **Traversal:** `walk=` follows record-to-record links from the
call's own selection (seed paths, a named `follow=` chain or full closure, caller-supplied stop/refuse
exclusions, recorded cycles, explicit caps); `project={"form": "chain"}` renders the paths with provenance —
and an NPC `follow="Template"` walk adds the TemplateFlags report: per inheritance category, whether the NPC's
own data is active or masked and WHICH record in the chain provides it. `walk={"direction": "reverse"}` over an
MGEF traces every SPEL/ENCH/ALCH/SCRL/INGR applying it with the matching entry's magnitude/area/duration (the
`effect_chain` job); any other reading form consumes what a walk reaches as its selection.
**`project={"form": "info_order"}`** renders a dialogue topic's effective MERGED INFO sequence across every
touching plugin — the order the game actually walks, MOVED lines annotated — with honest incompleteness
reporting when a contributor can't be read (a quest fans out by composition: `types=["DIAL"]
where=["Quest = <formid>"]`). **Poles:** `source={"overlay": "skypatcher", "state": "pre"|"post"}` reads records
around the SkyPatcher INI layer (post-state bodies for any reading form; pre-vs-post is a delta of the two
poles; INI content is declared outside the epoch fingerprint). **Composition:** `formids=` now composes with
every scan term (the identity set intersects the scan, or alone IS the scan's bound); a `plugins=` scope
combines with a named `source=` (the scope selects, the pole's version is read — untouched records counted and
named, never silently absent); and the out-of-load-order scan lane carries the complete grammar (multi-type,
the full `where=` predicate set over the file's own bodies, `references=`, windows, counts, artifacts,
comparisons). Every two-capture seam (scan→compare, walk→read, probe→scan) is epoch-compared — a load-order
change mid-call refuses loudly rather than mixing builds. The 8 absorbed 1.x read tools stay registered through
the build waves; from 2.0.0's clean cut, a call naming one answers with its successor `housecarl_records`
spelling instead of a generic unknown-tool error. Guarded by the extended `records-guard` (incl. the four
`previous_provider` probe pins) in CI; alias CENSUS re-baked (113 → 119 — `versus=`/`walk=` activate the
`plugin_a`/`plugin_b`/`mod_a`/`mod_b`/`mgef_formid`/`closure` hints).

**New tool: `housecarl_records` — the 2.0 read surface, core forms (W2 PR 1).** One read call composes *which
records* (SELECT: `formids=` incl. `@file`/artifact re-entry · set-valued `types=` · a structured `plugins=` scope
with `defined_in` inside it · `conflicts_only=` · the `where=` grammar · `references=`) × *whose version* (SOURCE:
the winner by default, or `source=` naming a plugin **wherever it lives** — active in the order or sitting on disk
unticked; the response states which arm resolved, a record the plugin doesn't touch is refused naming the plugins
that DO touch it, and a plugin found in neither place is refused naming both places searched) × *what shape*
(PROJECT: a form-scoped `project=` object — `identity | summary | fields | everything | aggregate`, each
sub-parameter living only inside the form that uses it) × transport (`text`/`json`/`dense`, exact windows,
`counts_only=`, `to_file=` and auto-spill riding the W1 artifact lane). The comparison forms (`delta`/`tree`/
`chain`/`info_order`), `previous_provider`, the SkyPatcher-overlay source, and `formids=`×scan composition arrive
in W2 PR 2 — until then those spellings get a **named staging refusal** pointing at the 1.x tool that does the job
today. The 1.x read tools are unchanged and stay through the build waves (they retire at 2.0.0's clean cut).

**The `where=` grammar grows the chartered 2.0 SELECT terms — on `cross_plugin_query` too.** New everywhere the
grammar runs: `startswith`; an `editorid` term (`editorid contains/startswith/= …`, `editorid missing` — the
`editorid_contains=` job as plain grammar, live even on records whose deep body can't parse); the **`winner`
provenance term** (`where=["winner = X.esp"]` — *which records does X win*; it reads resolution, not content, and
declares its winner-resolution cost); `in`/`not in` **generalized to any scalar leaf** (`"Race in
[XXXXXX:A.esm, …]"`, enum names and numbers too, artifact `@file` lists included); and a single **`->` link step**
(`"Perks->editorid startswith REQ_NULL_"` — the predicate crosses ONE form link and tests the target's winner body,
ANY-match over list targets, wrong paths still fail loud in the accounting). A stray `conflict_tree=`/`fields=`/
`depth=`/`group_by=` on the new tool answers with the form-scoping rule by name, and the alias layer maps the 1.x
spellings (`plugin=`/`mod=`/`from_plugin=` → `source=`, `formid=` → `formids=`, `type=` → `types=`) so first
guesses bind. Guarded by the new `records-guard` in CI; alias CENSUS re-baked (99 → 113 activations, all on the
new tool).

**Big results now come back whole, as a file — truncation stops losing data on the record-bulk reads (the 2.0
artifact disposition, W1).** `cross_plugin_query`, `batch_record_detail`, and `resolve` gain the §2.1.1 artifact
lane. Pass `to_file=<absolute .jsonl path>` to write the **complete** result — never limit-windowed — as one
self-contained JSONL file (line 1 is a manifest: the query that produced it, row count and schema, per-type counts,
and the build's epoch fingerprint; then one JSON row per record, the same rows `format=json` emits), with only the
manifest rendered into context. And when an ordinary response hits its `max_chars` ceiling, the complete requested
result is now **auto-spilled** to a server-managed results folder (pruned by age after 7 days) and the response says
exactly where it went — a `spilled:` block in text, a `"spilled"` object in json/dense, always naming the file. If
the spill itself cannot be written, the response says *that* instead — a truncated response never again implies the
tail is simply gone, or silently lacks the file it promised. Artifacts **re-enter** through the existing `@file`
spelling — `formids=["@<path>"]` on `batch_record_detail`/`resolve`, `where=["formid in @<path>"]` on
`cross_plugin_query` — yielding the file's identity column ("scan once, project forever"), and re-entry is
**epoch-checked**: if the load order changed since the artifact was written, the call refuses loudly naming both
fingerprints (there is deliberately no stale-override switch; plain formid-list files keep working unchanged, and
unchanged worlds fingerprint identically across restarts, so artifacts survive them). A truncated
`conflict_tree` view is the one shape that does **not** auto-spill (its trees have no row form) — the response says
so and names the alternatives, and a spill of a `limit=`-windowed result says it holds the *window*, never claiming
the full result. Guarded by the new `artifact-guard` (59 checks) in CI.

**Fixed: `check_errors` / `validate_scripts` refusals in `format=json` returned an empty string.** Both sweeps'
json renders returned before flushing the JSON writer on their error path, so any refusal — a scope naming a plugin
not in the order, an excluded plugin, a bad filter — rendered as `""` instead of an `{"error": …}` document. Text
mode was unaffected. Latent since the json sweeps shipped; surfaced by the epoch guard's refusal-render arm and now
pinned by it.

**Every record-lane response now names the load-order build it was answered from (the 2.0 epoch fingerprint, W1).**
Each index build gets a deterministic 16-hex fingerprint of the world-state it was built from (plugin set + order +
file mtimes) — unchanged order means an identical fingerprint, across rebuilds and server restarts alike. Bulk reads
(`cross_plugin_query` in all three formats and under `group_by=`, `batch_record_detail`, `resolve`, `effect_chain`,
`check_errors`, `validate_scripts`), `read_record`, and `diff_record` carry it in-band as `epoch=<hex>` (text) or an
`"epoch"` field (json), and `load_order_status` names the current build's fingerprint on its resolver line. The
point: paged reads (`offset=` windows) that silently straddled a mid-session load-order change were previously
indistinguishable from coherent ones — now the stamps disagree and the drift is visible. Also the foundation for the
2.0 artifact disposition, whose saved result files will be validated against the live build by this fingerprint.

**Parameter-name tolerance is now dictionary-driven (the 2.0 alias layer, W0).** The shim that already fixed
first-guess parameter misses (`plugin=` for `plugins=`, `form_id` for `formid`) now works from the houseCARL 2.0
naming dictionary instead of two hard-wired synonym pairs. Visible today: several new-vocabulary spellings bind on
the current tools (`patch=` for `patch_name=`, `ops=` for `operations=`, `readback=` for `full_readback=`,
`filter=` for load-order-status's `lookup=`, `types=` for `type=`), and `remove_record` (whose parameter was
always the odd one out, bare `patch`) now binds every artifact-name spelling — `patch_name=`, `plugin_name=`,
`archive_name=`, `output=`. On tools declaring several output names, `patch=` lands on the ARTIFACT: the merged
plugin (`output`) on `merge_plugins`, the repacked archive (`archive_name`) on `bsa_repack`, the mod-folder
name elsewhere. A rename never fires into a type
mismatch: a spelling whose value can't bind to its would-be target (say, an array `types=` where a single
`type=` string is declared) keeps its own name in the refusal, alongside the tool's supported-parameter list.
Everything else in the dictionary stays dormant by construction until the 2.0 build waves rename the tools it
describes; behaviour of well-formed calls — and of every 1.x tolerated spelling, `plugin=`/`plugin_name=`
cross-bindings included — is unchanged.

**Skill descriptions no longer overflow the context budget — every one compressed and re-validated (#294).** The 13
skill descriptions cost ~12,150 characters (~3,040 est. tokens) of always-resident context in every session — about
1.5× the budget Claude Code gives the *entire* skill listing across all installed sources. Past that budget, entries
get truncated, and a truncated description routes *worse* than a short one, so the length was actively degrading the
routing it was written to improve. All 13 are rewritten to a 200–400 character target — keeping the distinctive
trigger vocabulary routing actually keys on (`_DISTR.ini`, `facegen`, `.psc`, `Occlusion.esp`) and cutting the
synonym chains and capability inventories (that content lives in the skill body, which loads on invocation and is
free). New listing cost: ~5,150 characters (~1,290 est. tokens), roughly a **1,750-token saving in every session**.
Every description was re-validated through the full trigger-reliability fan-out (283 eval queries, one fresh agent
per query against the complete new listing): 12 of 13 passed immediately; `tool-output-awareness` initially lost the
generator filenames it routes on and went through three fix iterations before passing — its final text deliberately
keeps the artifact names (`PGPatcher.esp`, `Reqtificated` patches, `NPC_Token.json`). `papyrus-reference` also gains
its first eval set. The authoring standard's length rules were amended to match, so future skills are written to the
budget instead of re-discovering it.

**`compile_script` now finds your script's dependencies itself, instead of making you list them every time (#200).**
Compiling a Papyrus script means telling the compiler every folder its dependencies' source code lives in — and it
takes the **whole list, every call**. A script built on the usual frameworks (SKSE, SkyUI, PapyrusUtil, PO3,
JContainers, RaceMenu, UIExtensions…) meant retyping eight or ten folder paths for each compile, and getting one
wrong produced an avalanche of errors that read like bugs in your code. houseCARL now **scans your enabled mods**
for the source folders they already ship and puts them on the path for you, in MO2 priority order — so a mod's own
extended copy of a script wins over the vanilla one exactly as it does everywhere else. It does **not** hand the
compiler all of them: a big modlist ships far more script folders than you'd guess (501 on a 3,617-mod order, whose
combined length a Windows command line cannot even carry), and nearly all belong to quest and follower mods shipping
their own scripts that nothing else ever calls. So houseCARL keeps the folders your script actually **references** —
by name, followed onward through those scripts, since the compiler loads your dependencies' dependencies too. In
practice that turns 501 folders into eight or ten, and it reports both numbers so a folder that was left out reads as
*dropped as unreferenced*, not *missed*. Anything the scan can't
reach (your own stubs, a dev project folder, sources you had to extract out of a BSA — the Creation Kit's compiler
cannot read archives) still goes in `import_dirs=`, and you can now **save that list under a name** with
`save_import_set=` and recall it later with `import_set=`, so it is typed once rather than once per call. Pass
`auto_imports=false` to leave your enabled mods off the import path. **The folders actually searched are now reported on every
compile** — a summary on success, the full ordered list on failure. That was previously invisible, which made the
two ways a compile goes wrong impossible to tell apart from the output: a dependency that was never on the path, and
a dependency found in the *wrong* folder because something earlier in the order shadowed it. Relatedly, a failure
that looks like missing dependencies now gives you the right next step for your situation: if the scan already ran,
it points at the causes a scan cannot fix (the mod isn't enabled, its sources are inside a BSA, or they sit one
folder deeper) rather than repeating "list every dependency".

**`validate_dialogue` now reports a topic's EFFECTIVE line order — and which mod moved a line (#275).** A dialogue
topic is a list of possible lines, and the game plays the **first** one whose conditions pass. That list is not held
by any single record: every mod that touches the topic contributes its own list, and the real order is the merge of
all of them. houseCARL could not see that order at all, so the delta that breaks dialogue was invisible — a pure
reorder changes which line answers while leaving every field identical, so no field diff can show it. The report now
prints the merged order the game actually walks, marks any line whose position **moved**, and names the mod that
moved it. The rule it makes visible: **re-listing a line appends it to the bottom** unless that mod also carries the
line's previous-line link. So a mod that touches one line of an eight-line topic can silently send it to the back,
and a broader line answers in its place. That is the shape behind the report this came from — a hireling asking 5000
gold but hiring for 79, because the "you can't afford me" refusal had stopped being the first line reached — and
behind most "my dialogue mod stopped working" complaints, where the line is still present but no longer reached in
time. Whether any given topic is affected depends on your load order: a mod that re-lists a line **and carries its
previous-line link** moves nothing, which is what a well-behaved patch does. The order is computed to match what
xEdit's INFO Order (INOM/INOA) rows show, which completes the half of this that 1.9.0 left open (that release
taught the conflict diff to stop calling a pure reorder "identical to
winner"; this one shows you the order itself). One line you may see flagged: a line whose previous-line link was
written as an explicit "I am first" marker is pinned to the **top** of the topic, and the report says so — that is
correct behaviour, not a fault, and it is often what keeps a vanilla refusal ahead of the line it guards.

**Correction — houseCARL previously said lines get dropped by a dialogue conflict. They do not (#275).** The tool
used to state that a line another mod adds but the winning topic does not re-list "is dropped in game", and advised
resolving conflicts so the winning topic carries every line. That is wrong, and the advice was for a failure mode
that does not exist. Measured on a real load order: a topic whose winning record lists **one** line plays **eight**,
and the line that misbehaved was not in the winner's list at all. Nothing is dropped by a conflict — the lines merge,
and what changes is their **order**. The footer now states the real scope: the per-line checks (voice, result script,
CK parity) audit the winning topic's list, while every contributing mod's lines appear in the effective order above.
If you previously restructured a patch to make one topic re-list every line, that was not necessary — and because
re-listing appends, it may itself have reordered them. The `dialogue-authoring` skill taught the same wrong model and
its "carry forward every line" advice; both are corrected, and the guidance is now the opposite — **list only the
lines you add or change**, and set a line's previous-line link (PNAM) when its position matters.

**`nif_set` can now write a mesh's shader lighting values — the read/write asymmetry #287 opened is closed (#291).**
A new `op=set_shader_value` sets any of the six values `nif_inspect sections=shader` reports: *glossiness, specular
strength, specular colour, emissive colour, emissive multiple,* and *alpha*. Pass `shader_value=` and `value=` — one
number for a scalar (`glossiness` `55`), three comma-separated components for a colour (`specular_color`
`1,0.5,0.25`). Colours and alpha are conventionally 0–1 rather than 0–255 — a value outside that range is still
written (the format stores the number it is given, and real meshes do carry out-of-range values), but the result
says so, which is what catches a `255,255,255` pasted out of NifSkope's colour picker. It rides the same lanes and
the same two verification gates as every other op: by default the edited mesh lands in a new MO2 mod folder with the
original untouched, and a write that did not actually persist is refused
rather than reported as success. This is the fix for an armour that reads shiny and plastic because its specular
strength came in wrong, a glow mesh whose emissive multiple is off by an order of magnitude, or a folder of BodySlide
output sharing one bad glossiness — previously NifSkope, by hand, one mesh at a time. Note it is **not** `set_alpha`,
which remains the separate `NiAlphaProperty` blend/test word; `set_shader_value alpha` is the shader's own opacity
scalar.
**It refuses rather than pretending on a block that cannot carry the value.** The library implements these six on a
`BSLightingShaderProperty` and answers them from a do-nothing stub on other shader blocks — so writing to, say, a
`BSEffectShaderProperty` would have accepted the value, reported success, and left the mesh unchanged. houseCARL
checks whether the specific block genuinely accepts the write, and where it does not, refuses and names the block
type. Which blocks those are is read out of the bundled library rather than kept as a list, so the answer tracks the
library across future updates instead of going stale — the same by-construction approach the read side already uses,
though it necessarily asks a different question, since the values are read-only on the shared interface and settable
only on the concrete block.

**The bundled mesh library moves to NiflySharp 1.1.0 — `nif_inspect` gains five shader values, and mesh reads pick up
upstream's crash/corruption fixes (#287).**
The pinned 1.0.0 was published from a commit 52 changes behind upstream, and the gap was costing two different things.
The visible one: `sections=shader` could not report *glossiness, specular strength, specular colour, emissive multiple*
or *alpha* — 1.0.0's accessors returned a constant regardless of what the mesh held, so houseCARL named them as unread
rather than print a wrong number. 1.1.0 implements all five, and they now report their real values on any **Skyrim-layout**
lighting shader. The less visible one, and the reason the bump is worth taking on its own: upstream's most recent work is a code
audit fixing *crashes, hangs, data corruption and leaks*, alongside a batch of community fixes (UV writes landing in
the wrong buffer, a file-handle leak, block-array resizing). Every mesh read and write houseCARL does now runs on that
code. Nothing in the tool surface changed shape — the shader section detects which values the library genuinely reads
by inspecting the library, so the five started reporting with no change to the reporting logic, and an effect shader
(where upstream still stubs them) correctly keeps saying so.
**One group of values is withheld on purpose, and it is a scope decision rather than a library one.** On a mesh read as another
game's layout — an unconverted Fallout 4 or Fallout 3 mesh shipped inside a Skyrim mod — houseCARL now declines *all*
the lighting values and says so. The reason is that some of these accessors read a field the other layout's stream
never carried, and answer a fixed constant rather than the mesh's own number (glossiness on a lighting shader is the
live case: it reads the same value whatever the file holds). Rather than interpret the ones that survive the layout
change and guess at the rest, the whole group is declined there. That withholds up to four values that *would* have
been correct, which is a deliberate trade — houseCARL models the Skyrim shader layout, the same reason it already
declines to name texture slots on a foreign-layout mesh. Unlike the library detection above, this half does **not**
track the bundled version; it is houseCARL's own boundary.
Parse fidelity was **re-proven, not assumed to carry over** — both versions were run back to back over the same
91,601 workspace meshes and compared file by file, not by headline percentage. **Nine meshes that houseCARL could not
read at all now read**: 1.0.0 threw on a malformed boolean byte in them, taking Glorious Doors of Skyrim, Golden
Dwemer Pipeworks and every door in Reimperialized Abandoned Prison with it. Three more that parsed but carried blocks
1.0.0 did not recognise now parse fully. The single mesh still unreadable now *refuses* cleanly instead of throwing.
**Nothing regressed**: no mesh that parsed stopped parsing, no mesh that round-tripped byte-identical stopped, and the
18,862 vanilla Bethesda meshes came out verdict-for-verdict identical on both versions.

**The two sweep tools can now be scoped, filtered, counted, and returned as JSON (#282).**
`check_errors` and `validate_scripts` had exactly one scope knob between them — `plugins=` — and on a script-heavy
plugin that was not enough to get an answer at all: ~183 scripted records render past the tool-result size cap, and
`limit=` does not help because it caps *findings*, not the record roster, so even `limit=1` still printed a header line
for all 183. Both tools now take a record scope — `type=` (applied at the record stream, so skipped records cost
nothing), `formids=`, `editorid_contains=` — plus a `findings=` class filter, `counts_only=true`, and
`format="json"`. `validate_scripts` additionally takes `property_contains=` for chasing one property across a plugin.
On `validate_scripts`, `findings=["unbound_object"]` narrows to the HIGH silent-`None` class; on `check_errors`,
`findings=["missing_masters"]` **skips the per-record link walk entirely**, turning "is any master missing anywhere in
my order" from a full sweep into a master-table read.
`counts_only=true` returns the exact totals plus a histogram and builds no per-record listing at all — unbound
properties by NAME for `validate_scripts`, dangling refs by TARGET plugin for `check_errors` (which plugin the broken
refs point *into*, i.e. the one absent dependency behind a wall of findings). It is the pass-to-pass comparison for a
multi-pass edit: did this property's count drop, and did anything new appear.
**Every number states its own scope.** A **record** scope narrows all of a sweep's counts, exactly as `plugins=` always
did, and the response says so on its own line. Nothing else carries that blanket claim, because nothing else narrows
*every* number: a `findings=` class filter self-labels instead (an excluded class reads `NOT CHECKED`), and
`property_contains=` labels the two counts it does narrow — `4 unbound matching 'MySpell'` — while records-with-scripts
and unverifiable stay plugin-wide and unlabelled, because it does not narrow them. `check_errors`' missing-master count
comes off the plugin's master *table*, so even a record scope cannot narrow it; there the response marks that one number
plugin-level explicitly rather than sweeping it into the claim.
Two things are deliberately *not* filterable: unscannable records and unverifiable script attachments always report,
under every filter — a suppressed "could not check" would read as a clean result, and an unreadable `.pex` may be the
very one declaring the property you filtered for. A finding class you excluded renders as `NOT CHECKED` (and `null` in
JSON) on **both** tools, never as a `0`; `validate_scripts` also reports `unbound_object` / `unbound_scalar`
separately, so a partial filter's count can't be mistaken for the whole unbound population.
Also fixed: the truncation notice on both tools advised *"scope `plugins=`"* — the one scope the caller had already
applied. It now names the knobs that exist.

**`nif_inspect` can read a shape's SHADER — `sections=shader`, plus named texture slots (#272).**
The one question every visual diagnosis actually asks — *how is this shape shaded, and does it emit or scatter light?*
— was unanswerable. `nif_inspect` reached the shader block only to hop to its texture set, then threw it away, so you
got slot paths and nothing about the shader itself. The new section reports, per shape: the shader block type
(`BSLightingShaderProperty` / `BSEffectShaderProperty`), the shader **type** enum (`SkinTint`, `FaceTint`, `HairTint`,
`EnvironmentMap`, `Parallax`, `MultiLayerParallax`, …), and the **SLSF1 / SLSF2 flags decoded to their names** —
`Soft_Lighting`, `Glow_Map`, `Model_Space_Normals`, `Double_Sided` and the rest. The flag names come from the mesh
library's own enums, so they are the library's coverage rather than a hand-kept bit table, and any bit no member names
is stated as an explicit `(+unknown bits 0x…)` mask instead of vanishing.
Texture slots now also carry their **semantic name** wherever the shader determines it — `tex[2] (SoftLighting)`,
`tex[6] (TintMask)`, `tex[7] (Specular)` — in `sections=paths` and `sections=shapes` too, not just the new section.
Slot 2 is glow *or* skin-subsurface *or* soft-lighting and slot 7 backlight *or* specular depending on type and flags,
so the name is derived from those, never from the index; a slot the shader doesn't determine stays a bare `tex[N]`
rather than getting a plausible wrong label, and the index is always kept (it is what `nif_set`'s `texture_slot=`
takes). Slot naming is a **Skyrim** convention, so it declines entirely on a mesh read as another game's layout —
an unconverted Fallout 4 mesh shipped inside a Skyrim mod gets bare indices, and the output says so rather than
leaving "unnamed" to read as "undetermined".
**Lighting values** — *emissive colour and multiple, glossiness, specular strength, specular colour, alpha* — are
reported for a Skyrim-layout lighting shader (see the mesh-library bump above; they were unreadable when this section
was first built, and never shipped that way). Two cases report nothing instead, each saying which it is: on an
**effect** shader the library answers them from a stub returning a constant, and on a **non-Skyrim layout** houseCARL
declines them as a matter of its own scope. Either way you get a named reason, never a number houseCARL cannot vouch
for. The first is detected from the library itself rather than a hard-coded list, so it tracks the bundled version
automatically in both directions; the second is houseCARL's own boundary and does not.

**`check_errors` and the compact/merge dependency scan now treat a deleted record the same way (#279).**
The #276 fix taught `cross_plugin_query` that a deleted record links to nothing; the two sibling walkers that ride the
same form-link enumeration — `check_errors`' dangling-reference sweep and the external-dependency scan behind
`compact_plugin` / `merge_plugins` — still walked them. Two consequences, both now fixed. A deleted record's links
were reported as findings: `check_errors` flagged one as a *dangling reference*, and the compact scan counted one as
an external *referencer*, which could refuse a compaction over a dependency that isn't live. And a deleted record with
an engine-authored malformed body threw on the walk and landed in the "could not be scanned" bucket with a raw
exception cause — the same untyped skip #276 removed, in two more places. The rule now lives in one place shared by
all three walkers, so they cannot drift apart on it again. Deliberately unchanged: the compact scan still warns about
a deleted record that *overrides* something being renumbered — that test reads the record's own identity, not its
body, and such an override is still a dependent worth naming. Surfaced by the independent review of the #276 fix.
**An asset path that's missing its `meshes\` / `textures\` root now says so, instead of a bare ABSENT (#273).**
A model path read straight off a record — `Model.File` on an NPC, ARMA, STAT — is stored relative to `meshes\`, but
every asset tool wants it Data-relative. So the *normal* way one arrives at a mesh produced a flat, hint-free
`ABSENT — no active mod or BSA provides this mesh path`: a true answer for the string as given, but a dead end unless
you already knew the convention. `nif_inspect`, `nif_set` and `asset_status` now retry the root-prefixed form and,
when it hits, name it — ``did you mean `meshes\Actors\…\wolf.nif`?``. The suggestion is **verified, not guessed**: it
comes from actually re-resolving the candidate through the same VFS, so a path it names is always one a mod or BSA
really provides, and when nothing resolves nothing is suggested. `asset_status` tries both roots (it can't know a
path's kind) and stays silent otherwise — `sound\`, `scripts\` and the rest get no lecture. The mesh tools, which
only ever deal in meshes, add one weaker note when the prefixed form misses too: it names the convention and the
form the path would take, and says plainly that form isn't provided either. Reported externally.

**`place_asset` / `bulk_place_asset` carry that same missing-root suggestion (#283).**
The fourth lane with the same dead end: asked to auto-place a path taken straight off a record, the refusal
(`nothing in the active load order provides '…'`) named no way forward. It now retries both roots and, when a real
mod or BSA provides the prefixed form, names it — the same **verified, never guessed** suggestion, so it always
points at a copy that exists and stays silent when there is nothing honest to offer. It fires only on the
auto-resolve arm: with `source=` named, a destination nothing currently provides is the normal case (you are placing
a brand-new file), not a mistake to correct. A placement batch now also answers from one pinned asset build, so two
assets in the same call can never describe two different states of the VFS. Surfaced by the independent review of
the #273 fix.

**`cross_plugin_query` no longer trips over deleted records and reports them as an unexplained skip (#276).**
A `references=` (or `where=`) scan over a load order holding *deleted* records — the wild case was deleted `Package`
records in a follower mod — ended with a raw `NullReferenceException … could not be scanned and were skipped` note.
A deleted record carries no body by engine rule, but the scan still tried to read its form links, and an
engine-authored deleted body can leave just enough behind to NullRef on that read. The skip was accounted (not
silent), but its *cause* read as a parser hole — which means a genuine match hiding in a "skipped" record looks
possible when it isn't (Q3). A deleted record is now excluded from the content filters up front: it links to nothing
live and has no field to test, so it is a clean non-match, not an unscannable skip. This also means a deleted record
that *does* parse and carries a link to the target is no longer returned by `references=` — treating a deleted record
as referencing nothing, the resolution the report itself proposed. `editorid_contains=` is unaffected (EditorID reads
from the early EDID subrecord, before the body parse that throws). Reported by DrHeisen.

**A pure list reorder no longer reads as "identical to winner" in a conflict diff (#275, partial).**
The `conflict_tree` / `diff_record` content compare is order-insensitive by design — the same relations stored in a
different order (the USSEP case that motivated it) shouldn't over-report. But for a list where order IS the
semantics — a DIAL's INFO children decide which line the game plays — folding a reorder into "no delta" is a silent
wrong answer: the record reads "identical to winner" when the very thing that changed is invisible. Now, when two
lists hold the same contents in a different order, the diff emits an explicit `Field: same N item(s), ORDER DIFFERS
from winner` note instead of silence — type-agnostic, so it fires for any reordered list (over-reporting a noise
reorder is the safe direction; silently equating a semantic one is not). No-delta renders no longer claim "list
order ignored," since order is now compared. Reported by DrHeisen. *(This closes the diff-honesty half of #275; the
larger ask — an effective, merged INFO-order view for a topic, xEdit INOM/INOA parity — remains open.)*

**A plugin addressed by its file path is no longer mislabeled off-order and disabled (#269).**
`diff_record` stamped `OUT-OF-LOAD-ORDER (direct path, disabled)` on a plugin that is enabled and winning whenever it
was passed as an absolute path instead of a filename — the diff values were right, but the provenance line said the
live file wasn't live, which is exactly the claim a diff is consulted for. Two causes, both fixed: the shared on-disk
locate asserted "not enabled" for every direct path instead of computing it, and `diff_record` routed poles by plugin
NAME only, so a path could never match the active order. Enabled-ness now comes from the same enumerator the filename
lane uses (so the two can't disagree about one file), and a path that IS the copy the order loads resolves back to its
plugin name and diffs as `active order`.

The flag a located plugin carries — what `read_plugin_file` renders as `NOT active` and `diff_record` as `disabled` —
now means one thing in every lane: **the game loads this file**. That needs both halves, and each was wrong before:

- **The right copy.** Judged by full path against the copy the install actually serves (the first hit from an enabled
  layer — the same rule that builds the real load order). An archived backup sharing a filename stays
  `OUT-OF-LOAD-ORDER`, so the old-version-vs-live diff is unchanged; a copy shadowed by a higher-priority mod is not
  called active merely because its own mod is enabled; and a plugin served from game `Data` is not called inactive
  merely because some disabled mod holds the same filename.
- **Ticked.** A plugin sitting in an *enabled mod* but *unchecked in MO2's right pane* is no longer reported as
  active — the game does not load it. Implicit base/CC masters, which are force-loaded and never listed in
  `plugins.txt`, still count as active. This half applies to the filename and `mod=` lanes too, so all three now
  state the same fact.

Reported by a houseCARL user. (The banner wording and the one-flag-many-causes question this left open are resolved by
the next entry.)

**Every "not active" now says WHY, and so does every refusal that turns one away (#271).**
`NOT active` / `disabled` named the state but never the cause — and the causes have different fixes: the plugin is
unticked in `plugins.txt`, its mod is switched off, a higher-priority mod shadows this copy, or MO2 has not registered
it. Reading `[mod 'X' (enabled); NOT active]`, you could not tell which, so the answer had to be rediscovered by hand
every time. Two things changed:

- **The located-plugin flag became two facts** — *is this the copy the install serves* and *is this plugin ticked* —
  carried separately so each renderer can explain rather than classify. `read_plugin_file`, `diff_record`'s off-order
  pole, and `copy_npc_appearance`'s donor line now state the cause, from one shared composer so they cannot drift
  apart; the JSON lane gains a `why_not_active` field beside `enabled`. A file the game *does* load now says so
  positively instead of saying nothing. Vocabulary is consistent throughout: a **mod** is enabled/disabled, a
  **plugin** is active/inactive — `diff_record` no longer calls an unticked plugin "disabled".
- **Refusals explain themselves.** A tool that reads *through* the load order still refuses on a plugin the game does
  not load — that guard is the point — but instead of a flat "not in the load order", it now says the plugin is
  installed and unticked (or that its mod is off), and points at `read_plugin_file` for a raw read. This covers
  `read_record`, `check_errors`, `validate_scripts`, `merge_plugins`, every in-place write target, and the forward
  source check. A genuine typo still gets its "did you mean" — the explanation replaces the spelling guess only when
  there is a real cause to state. The four not-loaded causes each carry their own remedy, and the two that look
  alike from outside — a mod switched **off** versus a folder MO2 has **never registered** (where there is nothing
  to switch on) — are told apart from MO2's own mod list rather than guessed.

**The `read_plugin_file` banner no longer overclaims.** It read `OUT-OF-LOAD-ORDER (raw file read; the game does not
load this file)` — true of the read, false about the file whenever the one you passed IS the live plugin. It now reads
`(raw file read — not resolved through the load order)`, which holds in every case; what the game does with the file
is stated separately, per file, with its reason. The same sentence is gone from `read_plugin_file`'s own tool
description and from `copy_npc_appearance`'s donor line, where it was asserted even for a donor the game does load.

**The Codex umbrella router now covers the whole tool surface, and a CI guard keeps it that way (Codex parity).**
The Codex packaging ships one umbrella routing skill (`plugin/codex/housecarl/SKILL.md`); it had drifted to naming
only 9 of the ~45 MCP tools and 5 of the 13 helper skills, so a Codex user asking about facegen, Nexus, BSA
archives, dialogue, SKSE audits, or plugin compaction got no routing from it. It now carries a capability-grouped
map of **all 45 tools** and routes to **all 13 helper skills** (the discrete skills themselves already install to
Codex under `~/.agents/skills/`, so this restores the router, not the skills). A new `codex-umbrella-coverage`
CI guard reflects the real `[McpServerTool]` names and the `.claude/skills/*` folders and fails if any is unrouted
by the umbrella (or explicitly allow-listed) — so the drift cannot silently recur: adding a tool or skill without
updating the Codex router turns CI red. Codex packaging + CI only; no change to Claude Code behavior.

**The `bulk-record-jobs` skill now teaches how to get a big enumeration out — paging vs. persist-to-file (#249).**
A new section distinguishes the two independent caps a bulk read hits — the row cap (`limit=` → `capped`) and the
per-call output cap (`max_chars` → `truncated`) — and names the two lanes for clearing them: `offset=` paging on
`cross_plugin_query` (deterministic tiling windows; the primary lane, previously undocumented in the skill) and, as the
complement, raising `max_chars` so an oversized result **persists to a file** to post-process with scripts instead of
reading it into context (the move that made a 7,479-NPC facegen sweep single-session — one call per plugin, a 5,118-row
JSON document). Both come with the mandatory guardrail (verify `truncated == false` and `rendered == total` in the
persisted file) and a caution that huge tool *inputs* are their own stall risk (batch to a few hundred per call).
Skill documentation only; no tool behavior changed.

**The 13 bundled skills' descriptions were trimmed to cut always-loaded startup context (#256).**
A skill's `name` + `description` frontmatter load into every session's context — they are not Tool-Search-deferrable —
and the 13 descriptions totalled ~3,650 tokens. Each carried, past its trigger surface, a trailing
"Load this before X — <counter-intuitive mechanics>" rationale and grammar detail that is already spelled out in full
in the skill body (lazy-loaded, free at rest). Those tails and the "using the bundled reference rather than invented
syntax" boilerplate were trimmed while **every "Use when…" trigger cue and every not-this-other-skill disambiguation
line was kept**, so trigger accuracy is unchanged and ~590 tokens (16%) come off the always-resident cost. Descriptions
only — no skill body, reference, or behavior changed; every trimmed frontmatter still parses (the `plugin-validate`
CI guard, which exists because a colon-space once silently dropped a whole skill, stays green).

**houseCARL's MCP server instructions now orient tool discovery across the whole surface, not just Nexus (#257).**
The server's `initialize` `instructions` blurb — always resident in the agent's context — was ~90% a Nexus how-to that
duplicated each Nexus tool's own description and named none of houseCARL's core capabilities, so an agent relying on
Tool Search had nothing telling it houseCARL could read inactive plugins, see through the SKSE/SkyPatcher runtime
layers, author dialogue, or compact/merge/decompile. It now leads with the data-layer / MO2 domain and an explicit
"reach for these tools when…" cue, then sweeps the real surface in five groups (read/query, write, fix,
reshape/drive-tools, Nexus). Per-tool parameter detail was dropped from the blurb — each tool carries its own,
fetched on demand — leaving the string broader yet slightly leaner (1,902 bytes, within the ~2 KB per-server budget)
and ordered so any truncation loses only the least load-bearing Nexus tail.

**`housecarl_nif_inspect` `sections=` now accepts the JSON-array form and fails loud on an all-unrecognized value (#247).**
Passing `sections` as a JSON array — the natural MCP way to send a list — arrived as the literal string
`["shapes","paths"]`, and, split only on comma/space, tokenized to `["shapes` / `"paths"]` (brackets and quotes glued
on), read as unrecognized, and the tool **quietly fell back to rendering the default summary** — so a batch could run
with the wrong sections while the warning scrolled off the top of a large persisted file. The tokenizer now treats
bracket and quote as delimiters too, so `["shapes","paths"]` parses; and a `sections=` in which **nothing** is
recognized is now a loud error naming the tokens, never a silent summary (a partial request still renders the valid
sections plus a warning). The unrecognized-section message — and the tool description — now also point out there is no
`textures` section: a mesh's embedded texture-set slot paths appear under `shapes` (per-shape detail) and `paths`.

**`housecarl_bulk_apply` read-back now reports the true count for a `composes=` Add of N — no more misleading `(+1)` (#259).**
Appending N elements to a list field in one op via `composes=` rendered a verify line that reported only the last element,
as if a single element was added — `✓ … Add Conditions: now 37 (+1), new [36] = [ConditionFloat]` for a six-element
compose — because the Add read-back hardcoded a `+1` delta and the single last index. The data on disk was correct (the
list total was the only clue all six landed), but the summary contradicted the op and cost real mid-session doubt. The
read-back now carries the op's appended count and reports the whole run: `now 37 (+6), new [31..36]`. A single-element
Add is unchanged (`now 29 (+1), new [28] = …`).

**A `[Flags]` enum field with unknown bits now decodes the known bits instead of collapsing to a bare decimal (#255).**
When a flags field carries a bit the record catalog doesn't name (a modded slot, or a game-version bit houseCARL's
Mutagen build predates), `.NET`'s `[Flags].ToString()` abandons the name list and renders the whole value as one
decimal — e.g. `Configuration.Flags = 2490402` on Dawnguard vampire NPCs — silently losing even the *known* bits
(gender, uniqueness, ghost state) a consumer needs. A read now appends a display-only decode of the form
`2490402   (<known flag names> (+unknown bits 0x…))` — the known bits by name, the unnamed remainder as an explicit hex
mask, so the common bits stay directly consumable and the presence of unknown bits is stated rather than hidden. The
known bits are peeled the way `[Flags].ToString()` itself names them (fully-contained members, combos before their
constituent bits), so the name slot is never itself a bare decimal. The round-trip token is unchanged (the bare decimal
still round-trips through `Enum.Parse`, so write / read-proof / diff are untouched) — the decode rides the same display
channel as the existing biped-slot annotation, which keeps its slot-number decode.

**`housecarl_read_record` / `housecarl_batch_record_detail` `depth=2` now surfaces an owned-record list element's own FormID (#252).**
A list whose elements are themselves owned records — most commonly a DIAL topic's `Responses` (each element an INFO record) —
surfaced no FormID at `depth=2`: an element rendered a bare `[DialogResponses]` (or `[DialogResponses] EditorID=…` when the INFO
carried an EditorID), never the FormKey that is an owned record's canonical identity. Mapping topics to their child INFOs meant a
second call with explicit `[i].FormKey` paths (and you couldn't enumerate those paths without first reading the element count).
The `depth=2` "index + identity" contract now holds for owned-record elements the way it already did for lone-FormLink structs
(#198): each leads with `[DialogResponses 000ABC:Plugin.esp editorid=…]` — its own FormKey, plus EditorID when present. Applies
wherever `depth=` expands (text and `format=json`).

**`Conditions[].Data` arm parameters now expand in a `Conditions` list dump (#258).** A polymorphic condition-data arm reached by
expanding a `Conditions` list stopped at its bare `[GetFactionRankConditionData]` type — its parameter fields (`Faction`, `Global`,
`Reference`, `RunOnType`, …) surfaced only when `Data` was addressed directly (`fields=["Conditions[2].Data"]`) or at an extra depth
level, so a `fields=["Conditions"] depth=3` dump silently stopped one level short of the params. The depth-floor "open one bounded
level" exception — previously VMAD-script-property-only — now also opens a condition arm's parameters, so a whole condition stack
(function + params) reads in one call at the natural depth. Bounded to one level (an arm's members are leaves/links) and
type-targeted (every other substruct still stops at the floor, unchanged).

**`housecarl_cross_plugin_query` `group_by=` now case-folds plugin keys — case-variant spellings of one plugin no
longer split into separate groups (#248).** A load-order-wide `group_by=defined_in` counted the same plugin twice when
different plugins spelled a shared master with different casing — e.g. `ccBGSSSE025-AdvDSGS.esm = 40` *and*
`ccbgssse025-advdsgs.esm = 35` as two rows — because a defining-plugin key carries each plugin's own master-list
spelling. Any consumer summing per-plugin counts silently double-grouped. Plugin filenames are case-insensitive
identifiers everywhere else in houseCARL (and in the game); group keys now match, merging the counts (first-seen casing
is displayed). The same case-fold covers `group_by=winner` for consistency (its keys come from one canonical name array,
so they don't vary in casing the way `defined_in` keys do); `group_by=type` is unaffected (record-type names never
differ only by case).

**`housecarl_cross_plugin_query` gains `where_source=winner` — filter on the live winner, not the scoped body (#233).**
Under a `plugins=` scope the body filters (`where=`, `references=`, `editorid_contains=`) decided the match against
each match's *scoped* plugin body, even with `winner_fields=true` — so a post-patch audit like "Bruma-defined NPCs
whose live winner still uses a PC-level multiplier" returned every record that *ever* had one (259), not the 82 whose
winner *still* does. `winner_fields=` only changed what was *displayed*, never what *matched*. Now `where_source=winner`
retargets the whole match onto the live load-order winner: `plugins=[…] defined_in=true where=["Configuration.Level.LevelMult >= 0"]
where_source=winner` returns exactly the winners still on the multiplier, server-side, in one call — no more scanning every
winner in the order and filtering FormKeys by hand. (It re-fetches each candidate's winner body, so a very *broad*
winner-source scan is not yet as fast as it can be — an O(order) fetch is tracked in #251; correctness is unaffected.)
It stays decoupled
from `winner_fields=` (DISPLAY), so `where_source=winner winner_fields=false` matches on the winner while showing the
scoped origin body — a real audit. Loud refusals (Q3): an unknown value names `scoped`/`winner`; `where_source=winner`
with no body filter to retarget is refused; and under a `type=`-only scope (already the winner) it's accepted with a
"redundant" note, never a silent no-op. Default (`scoped`) is unchanged.

**`housecarl_cross_plugin_query` learns `depth=` (#231).** Nested list contents were unreachable in a scan:
`fields=["Effects"]` rendered only `[list: N item(s)]`, and the workaround — hand-written bracket paths like
`Effects[2].Data.Magnitude` — meant guessing the longest list up front and eating an out-of-bounds error triple
for every shorter record (66 spells → hundreds of wasted lines, twice past the token cap). Now `depth=` rides the
scan with the same semantics as `housecarl_read_record` / `batch_record_detail`: `fields=["Effects"], depth=4`
expands every match's per-effect Data in one call — each record shows exactly its OWN elements, no index guessing,
no out-of-bounds noise — and `resolve_names=` composes with the expansion. Works in `format=text` and `json`;
`dense` refuses `depth>1` loud (its columnar cells align 1:1 with the requested paths — the container cells name
the text/json hop), and `depth=` without `fields=` is refused loud too. The old container hint ("cross_plugin_query
has no depth=; expand via batch_record_detail") is retired with the gap it described.

**`housecarl_nif_inspect` goes batch — `mesh_paths` takes one or many (#229).** The last per-file loop in a
load-order-wide dark-face scan is gone: `mesh_path` is now `mesh_paths`, an `asset_status`-style array (a single
path is simply a batch of one). One call resolves the whole flagged subset — **one load-order resolution for the
entire batch** instead of one per mesh — with results in input order, `sections=` / `mod=` / `max_chars` applying
batch-wide, and every per-path failure (ABSENT, bad path, a `mod=` that doesn't provide it, unreadable bytes, a
parse refusal) reported LOUD on **that** path without aborting the rest (Q3). The batch-level caveats (unreadable
archives, discovery warnings) render once, first, so a long batch can't truncate them away — and every ABSENT is
additionally **hedged at point of use** when the scan behind it was incomplete (`asset_status` parity: a bare
"absent" is never over-trusted just because the top-of-output alarm scrolled away). An over-cap output is cut with
the omitted-mesh count named, never silently — and `max_chars` can never starve a single-path call of its core
answer (the first mesh's resolution/error always renders). The `facegen-diagnostics` batch flow no longer needs to
sample the flagged subset — inspect all of it in one call.

**`resolve_names` / `housecarl_resolve` no longer call PlayerRef "unresolved" (#230).** The engine-implicit forms —
PlayerRef (`000014:Skyrim.esm`) and the Player base NPC (`000007:Skyrim.esm`) — are hardcoded engine references no
plugin defines, so the identity resolver flagged every condition or link pointing at them as
`unresolved: target not in the active order` (67 false suspects in one 67-record audit), while `check_errors`
correctly called the same links clean. The resolver now applies the same precise two-form exemption the integrity
sweep and dialogue lints already share: those links annotate `→ PlayerRef` / `→ Player` (winner `<engine>` in a
`housecarl_resolve` row), and any OTHER sub-0x800 form still reports unresolved — the exemption is the two known
forms, never the whole reserved range.

**`housecarl_bulk_apply` learns manifest files — `from_file=` (#224).** A big write job used to mean pasting the
whole ops array inline (the 745-record stress test generated 20 local `ops_*.json` chunk files and fed them through
piecewise). Now `from_file=<absolute path>` reads the SAME operations array as a JSON manifest on disk: generate
the manifest once, validate the **whole file** with `dry_run=true` before the first write, apply it in one call —
and re-run the same manifest to recover an interrupted write (overrides are idempotent). The parsed ops ride the
identical pipeline as inline ones (every lane and `dry_run` compose by construction; the dry-run report is
string-identical to the same ops inline). The file contract is all named refusals (Q3): `operations` XOR
`from_file`, absolute path required, invalid JSON named with line+column, a non-array root, an empty array, and —
stricter than inline binding, which silently drops unknown members — a misspelled op member (`feild_path`) is
refused **by name at its element** instead of becoming a null-field op whose downstream error points away from the
typo.

**Dry-run mode for the write tools (#225).** `housecarl_set_field`, `housecarl_bulk_apply`, and
`housecarl_forward_record` gain `dry_run=true`: the **full real write pipeline** runs — winner resolve, schema
pre-flight, every op applied to the in-memory would-be plugin, a reference-resolution check that pre-empts the
serialize's missing-master failure — and stops at the point of no return, so **nothing touches disk** (no patch
file, no mod folder, no in-place rewrite). The report says what *would* change (per-op would-be values, the
expected master set, `full_readback=true` for the full in-memory record preview), and a bad batch gets **exactly
the all-or-nothing refusal the real call would give** — so a wrong field path in a 700-op batch is caught before
the first write, not diagnosed after the last. Works on every lane: fresh patch, `into=`, and `in_place` (an
in-place dry run needs no `acknowledge` and never records consent — it's read-only; the pending consent is noted
so the real write's one-time prompt isn't a surprise).

**BSA reads move in-process — `housecarl_bsa_list` / `housecarl_bsa_extract` (#217).** Listing and extracting a
`.bsa` no longer shell out to BSArch; they read through Mutagen's own in-process BSA reader. This fixes an archive
class BSArch's *unpacker* rejected: an archive written by a non-BSArch tool could list and load in-game yet extract
to **zero files**. It also now handles **compressed** archives, and was verified byte-for-byte identical to BSArch's
own unpack (uncompressed *and* compressed). Consequences:

- **No external tool is needed to list or extract** — only `housecarl_bsa_repack` still calls BSArch, because Mutagen
  ships a BSA reader but no writer (confirmed by exhaustive reflection over its archive surface). Repack is now the
  one BSA operation that still prompts for the BSArch path.
- Extraction gains two safety properties the BSArch path never had: it is **path-traversal-guarded** (an entry
  resolving outside the destination is refused) and **content-aware/idempotent** (a byte-identical file already
  present is skipped).
- A per-entry size ceiling and a header-vs-reader file-count cross-check keep a corrupt or hostile archive to a
  **loud, named failure** rather than an out-of-memory or a silent empty extract.

**Wrong-type arguments are now named (#222).** Passing an argument of the wrong type — an object where a number
is expected, a string where a boolean is — used to surface as a raw `JsonException … BytePositionInLine: 34`: a
byte offset with no parameter name, forcing you to bisect which argument was at fault. The argument-binding shim
now catches the type mismatch *before* binding and names the offender, its expected type, and the kind received
(e.g. `parameter whose type could not be bound: conflicts_only (expects boolean, received string)`) — the same
named-and-actionable style the missing-parameter and unknown-parameter paths already use. Obvious-intent shapes
(a bare string for an array, a quoted number or boolean) are still auto-coerced, so well-formed calls are
unaffected.

**Obvious parameter aliases now bind (#221).** Tool parameters aren't uniformly named — one tool takes `plugins`,
another `plugin`, another `plugin_name` — so a first-guess miss (`form_id` for `formid`, `plugin` for a tool's
`plugins`) cost a round-trip. The argument-binding shim now recognizes an obvious synonym of a declared parameter
and renames it to the canonical one, so the call binds instead of erroring. It's deliberately conservative: it
resolves an underscore/case variant (`form_id` ≡ `formid`) or a known singular/plural synonym, and **only** when
exactly one declared, not-already-supplied parameter matches — an ambiguous or unmatched name still gets the named
unknown-parameter error, a declared parameter is never treated as an alias (a tool's real `plugin=` is untouched),
and an explicit canonical value is never overwritten. The published schema still advertises only the canonical
name.

**`cross_plugin_query` learns identity membership — `formid in` / `formid not in` a supplied list (#226).** The
reconciliation subtraction — "every record of these types in plugin X, *minus* these ~1,200 already-claimed
FormIDs" — used to run client-side over verbose enumerations because `where=` had no exclusion predicate. It now
does: `where=["formid not in [XXXXXX:A.esp, YYYYYY:B.esp]"]` (inline, comma-separated — spaces in plugin
filenames are safe, and a pasted JSON array works as-is) or `where=["formid not in @C:\\work\\claimed.txt"]` (an
absolute-path file of FormIDs, comma- or newline-separated). `formid in` is the symmetric keep-only form, and both
AND with the existing value predicates. The list is fully validated before any scan — a malformed FormID, an
unreadable or relative file path, or an empty list refuses the call by name, never a silent wrong result.

**`cross_plugin_query` learns bulk-enumeration economy — `format="dense"` + `offset=` pagination (#223).** A
whole-mod enumeration used to be the context-budget drain: `format="json"` repeated the identity envelope and a
`{path, value}` object per field on every match (~80 records per 40k chars at two fields), and with `limit` but no
offset, paging meant slicing by `editorid_contains`. Now:

- **`format="dense"`** renders one columnar document — a `columns` array once, then one positional row per match
  (`[formid, editorid, field values…]`; summary rows are `[formid, type, editorid, winner, override_depth]`; under
  a `plugins=` scope, detail rows gain a `source` column naming the body each row's values came from). Same
  read path and accounting as the other formats; a no-value field shows its note (`"(absent)"`) in-cell, a failed
  row lands in a separate `errors` array, and `resolve_names` annotations still work. In the probe's own
  measurement the same one-field query renders **2.6× smaller** than `format="json"` — and the gap widens with
  more fields.
- **`offset=`** skips the first N matches, so `offset=0/500/1000…` + `limit=` pages an enumeration in windows that
  tile exactly (scan order is deterministic while the load order is unchanged). The true total always counts all
  matches; the text header names the window and the next offset (`showing matches 501–1000; continue with
  offset=1000`), and json/dense carry `offset` in-band. Negative offsets and `offset=` under `group_by=` (a count
  table has no window) are refused by name.

- **Eleven more 1.x tools are gone — the eight read tools and the three check tools.** `housecarl_read_record`,
  `housecarl_batch_record_detail`, `housecarl_resolve`, `housecarl_cross_plugin_query`,
  `housecarl_read_plugin_file`, `housecarl_diff_record`, `housecarl_effect_chain` and
  `housecarl_skypatcher_read` are all on `housecarl_records`: one record or many is `formids=`, the shape of
  the answer is `project={"form": …}` — `identity` for the labelling read, `fields`/`everything` for a body,
  `delta` for a two-plugin comparison, `tree` for the conflict view, `chain` for an effect's carriers — and
  whose version to read is `source=`, which takes a plugin filename wherever that plugin lives, `{"file",
  "mod"}` when two mods ship the same filename, and `{"overlay": "skypatcher", "state": "pre"|"post"}` for
  the runtime view around the SkyPatcher INI layer. `housecarl_check_errors` and `housecarl_validate_scripts`
  are `housecarl_check` with `findings=["errors"]` and `findings=["scripts"]`. `housecarl_validate_dialogue`
  split: its findings are `housecarl_check findings=["dialogue"]` with the same DIAL/QUST/DLVW/DLBR FormIDs in
  `seeds=`, and the effective merged INFO order — the answer to which line plays — is
  `housecarl_records project={"form": "info_order"}`, because an ordered sequence is not a finding.

  They are deleted rather than deprecated, on the same ruling the six write tools went under: a 1.x tool whose
  capability the finished 2.0 surface covers goes at 2.0.0 with no deprecation window, in the release that
  ships its replacement. Calling a deleted name is not a dead end — the server answers with the successor and
  that tool's parameter migration, and for `housecarl_validate_dialogue` it names both destinations rather
  than sending a caller who wants the INFO order to the sweep that deliberately does not answer it.
  Check it from your client's tool list: the eleven names are absent, and `housecarl_records` and
  `housecarl_check` are present.

  One thing did not carry across at first: `housecarl_read_record conflict_tree=true` named which plugins
  declare child records in a CELL's, DIAL's or WRLD's child-bearing field. `housecarl_records` restores it —
  see the `project={"form": "tree"}` entry above, in this same section (#485).

  What does carry across is the master advisory the deleted `housecarl_read_plugin_file` printed:
  `housecarl_check findings=["missing_masters"]` now names, per unsatisfied master, whether it is not
  installed anywhere in the MO2 install (install it) or installed but not active — in a disabled mod, or
  unchecked (enable it) — in both transports: `format="text"` says which in the remedy line, and
  `format="json"` carries the second case as `installed_but_inactive_masters`, the subset of
  `missing_masters` whose file is in the install (`null` where the split was not made). The finding class,
  its count and its list are unchanged; the remedy line used to say "install/enable it" for every master at
  once, so a caller had to work out which applied. Check it by running
  `housecarl_check plugins=["<a plugin with an unsatisfied master>"] findings=["missing_masters"]`.

- **Sentences on tools that survive point at a call you can make.** Repairs the deletion above forced:
  `housecarl_write_seq`'s standing limit and its mtime-stamp note named the retired dialogue validator and
  name `housecarl_check findings=["dialogue"]` now; `housecarl_skypatcher_layer`'s description and its
  end-of-report pointer named the retired per-record reader and name the `housecarl_records` overlay pole;
  the child-record note that told you to re-read with `conflict_tree=true` in text mode names
  `project={"form": "tree"}`, which also spills to `to_file=` — the 1.x sentence said the view refused that;
  the copy tools' read-back-failed advice, the untick and not-in-order advisories, and the full-readback cut
  hint all name `housecarl_records`. An artifact's manifest records which tool wrote it, and that field named
  a retired tool for artifacts `housecarl_records` itself had written; it names `housecarl_records` now.

- **`housecarl_records` refuses `format="dense"` with a `project.depth` above 1, instead of answering at depth 1
  without saying so.** Dense rows are positional cells, one per requested field path, so depth expansion has no
  column to go in — the tool's description already said the expansion is inexpressible in that format, and the
  code accepted the pairing and dropped it. A call that used to come back as the depth-1 document now comes back
  as a refusal naming the depth you passed, and pointing at `format="text"` or `"json"` for expansion. Check it by
  asking for `format="dense"` with `project={"form":"fields","fields":[…],"depth":2}`: at depth 1 the same call is
  served unchanged, and the same depth in `"text"` is served, so the refusal is about the transport. The refusal is
  the SCAN lane's: a `formids=` read refuses dense outright, and that sentence is the complete answer there — firing
  the depth one first would tell you to drop `project.depth` and land you on a second refusal.

- **Two headers stop naming a tool that is gone.** The scan's text render opened `cross_plugin_query: N matches` and
  now opens `scan:`; the chain form's render opened `effect_chain for …` and now opens `chain for …`. The chain
  form's three refusals — not a MagicEffect, no such record, a type that is not effect-bearing — said `effect_chain`
  too, and one of them told you to reach for `cross_plugin_query references=`, a call you can no longer make; they
  name the chain form and `housecarl_records references=[…]` (bounded with `types=` or `plugins=`) now. The
  unscannable-record note that said "Inspect one with read_record" names `housecarl_records formids=[…]`.

- **`resolve_names` now names the target a container element's summary line shows.** At `project.depth=2` a list
  element renders as a one-line summary carrying its identity field, and where that field is a FormLink the line
  shows a FormID — `Effects[0] = [Effect] BaseEffect=033975:Skyrim.esm`. `resolve_names=true` annotated only a
  field's round-trip value, so the FormID on that line was left bare and the editorid was reachable only by
  re-reading at `depth=3`. It is now annotated wherever the read shows it, in the same parenthetical and the same
  `link` sibling in json, and the summary text itself is unchanged. The json summary line also carries the FormID
  it rendered as a `note_ref` sibling of its `note`, so a consumer reads it back through `formids=` without
  parsing the prose. At `depth=3` the element's own leaf is printed under the summary and both lines show the same
  FormID, so both carry the name: the annotation repeats exactly where the read repeats the FormID. The `rows` form
  is where it does not — a row that carries the element's sub-fields trims the element cell back to its bare
  `[Type]`, and the name goes out with the FormID the trim took, leaving it on the sub-field cell that still shows
  it. The element's OWN FormID — an owned child
  record's, which the summary already spells with its editorid — is not annotated with itself. An element with two
  or more FormLink fields still renders as a bare `[Type]` and so shows no FormID to annotate, for the reason it
  already gives.
- **A `project.fields` path that names no field says which kind of miss it is.** A field the record type does not
  model and a mistyped name both read as `(no field X)`, and they need opposite next moves. The note now says
  which, from the generated schema: a name Mutagen models on other types is told so, with how many and the first
  few of them, and that it is just not on this type — so `VirtualMachineAdapter` on a Spell reads as a Mutagen
  coverage limit rather than a spelling to fix. Where the record type carries a near field of its own the note
  names that too and does not call the name right: `Effect` at a SPEL is modeled elsewhere and still the caller's
  spelling of `Effects`. A name the record type spells differently only in case is called
  mistyped and given that spelling, ahead of anything else the schema carries under the casing typed — `DATA` at a
  WEAP is xEdit's spelling of the field Mutagen calls `Data`, and a real field name on `DialogResponses` besides.
  A name no modeled type carries is called mistyped and offered the nearest field on the record. Where the corpus
  is not built, or the path dead-ends on something the catalogue does not model at all (a `FormLink`, a string),
  the note stays the bare `(no field X)` it was. The `where=` lane's own accounting for the same dead-end is
  unchanged.
- **`skse-plugin-authoring` now writes both halves of a new native Papyrus function, and its reference pointers
  resolve.** The skill used to send the `.psc` declaration of a native you are inventing to `papyrus-reference`,
  which is a lookup corpus for functions that already exist and by construction holds no entry for one that does
  not; the declaration grammar and three worked cases — a global native, a latent function, and a return type that
  compiles and then silently truncates — are written in the skill beside the C++ registration. Its nine reference
  pointers are written `references/<file>.md` rather than as bare filenames, so they open as written from an
  installed plugin; the multi-runtime reference gains an "SE+AE only" route for a target with no VR in it, which
  says to tell SE from AE at runtime because a dual build defines neither `EXCLUSIVE_SKYRIM_SE` nor `_AE`; and the
  toolchain reference gains `vcpkg.json`'s `builtin-baseline`, under the condition the reference states.
- **The SPID skill's Level Filter answer is corrected, and it now measures a line's reach before writing it.**
  The skill said a Level Filter moves the line to a leveled pass that only auto-levelled NPCs receive. It does
  not: SPID checks the filter against every matching NPC's own level, and the separate pass re-evaluates only
  NPCs on a PC level multiplier as the player levels. The corrected rule, with its citations into SPID's MIT
  source, is in the skill's `references/filters.md` §3, and the skill body points there rather than restating
  it. On one live order the two populations differed by a factor of hundreds, so a line written on the old
  reading understated its own reach. The skill now names the three read-only checks that exist —
  `housecarl_records` with `counts_only=true` for the population a filter names and for how many of those are
  on a PC level multiplier, and `housecarl_asset_status` for which mod wins the placed `_DISTR.ini` — and says
  plainly that nothing reports the set a composed line reaches and nothing parses a draft `_DISTR.ini` offline.
  It also says what those counts are: `where` predicates are ANDed, so the second check carries the first
  check's predicate, and both read each record's own local data, which a template masks — SPID matches the
  resolved NPC, so a census is a floor and the skill says to quote it as one.
  It also states the version window in both directions: `references/filters.md` marks the features added in
  7.3, and `housecarl_skse` with `findings='inventory'` reads what the installed SPID DLL declares as its
  version. The EditorID caveat is new too — an EditorID is stable across merging, ESL conversion and FormID
  compaction, but not against a winning override that renames the record, which resolves to nothing silently.
- **`npc-appearance-copy` ends at a mesh that points at its own tint, and stops claiming a guard it does not
  have.** The flow was three calls and finished at the placement; it is four now, because `housecarl_place`
  renames the FaceGen file without touching the bytes inside it, so the placed head still names the *donor's*
  tint in texture slot 6 and renders correctly for exactly as long as the donor stays installed. Step 4 writes
  that repoint with `housecarl_nif_set` (`op="set_path"`, `texture_slot="6"`) and re-reads the mesh, and the
  verification list — now split into what the session can check and what only the caller can do — fails when the
  repoint has not happened. Three corrections: `housecarl_copy` does not refuse a copy from a
  `Traits`-templated donor, because a seed the source leaves unset **clears** the target's, which makes the
  `Configuration.TemplateFlags` read the only thing standing between you and a blank face reported as a
  success; the clone lane's `Race` refusal fires on a race that would have to be stripped, not on every race;
  and the provider a placement names is the one whose bytes match the record you copied, decided by inspecting
  each candidate, which for an NPC defined in `Skyrim.esm` is not the folder the FaceGen path points at. The
  four Race cases and that provider test move to `references/race-and-provider-cases.md`, the body is about a
  third shorter, and the trigger set moves to the published `evals/evals.json` shape with a without-skill arm.
- **The OAR skill is now `/housecarl:open-animation-replacer`.** It shipped as `/housecarl:oar-authoring`, and
  the old slash command no longer exists — retype it, and update anything that invokes it by name. A host that
  lists skills by name alone showed the old one as "oar", which reads as the English word rather than the mod;
  the name now says which tool it is without the description. What the skill teaches is unchanged.
- **`open-animation-replacer` names tools that exist, finds the config the game actually loads, and states what it does not
  know about DAR.** Its one delegated step named `housecarl_read_record` and `housecarl_cross_plugin_query`, neither
  of which the server publishes any more; it now resolves a condition's form with `housecarl_records`
  (`formids=` or `types=` plus `where=`, projected `{"form":"identity"}`), and says what to do instead when the
  server is not there. Locating a submod was Glob and Grep, which cannot say which mod wins a file: the first step
  and the verification step now sweep the OAR and DAR trees with `housecarl_asset_status` `under=`, which names the
  winning source per `config.json`. The reference gains the two things the DAR half was missing — a
  DAR-function → OAR-condition table, so `IsEquippedRight` → `IsEquipped` plus `"Left hand": false` is written down
  rather than inferred, and an explicit statement that **how `AND` and `OR` bind in a mixed `_conditions.txt` chain
  is unsettled**: convert under one reading, say which in the submod's `description`, and say what the other would
  have meant. A second worked example converts a real DAR folder end to end. The trigger set moves to the published
  `evals/evals.json` shape with a without-skill arm; the unreferenced `references/index.jsonl` is gone, and every
  file the skill ships is named in its body.

## 1.9.0 — 2026-07-17

houseCARL's view of the **SKSE-plugin layer** grows from *inventory* into *diagnosis*: two new audit tools
that catch a broken native pairing or a dead config reference statically — before the game fails silently on
it — completing the SKSE layer-visibility ladder (tiers A→D, #199). **Two new tools (→ 45), no new skills
(still 13).**

**SKSE layer diagnosis — two new audit tools**

- **`housecarl_native_pairing_audit` — the native functions your scripts declare vs the DLLs that must
  implement them.** A native Papyrus function is one thing declared in two files that ship and fail
  independently: a `.pex` class flags the function, and an SKSE DLL registers the implementation at runtime.
  When the halves don't meet, the engine logs a cryptic "unable to bind" and the calls silently no-op. This
  scans the winning copy of every compiled script (loose + BSA) and pairs each native-declaring class to the
  DLLs its mod ships under `SKSE\Plugins`, leading with the findings: **PAIRED-BUT-DEAD** — scripts installed,
  but every candidate DLL statically will not load (wrong game runtime for a version-locked plugin, BSA-only,
  shipped in a subfolder, 32-bit, unreadable, or built against the debug CRT) — and **UNPAIRED** — no DLL in
  sight, a VERIFY flag, typically a declaration copy of a framework you don't have. It keeps the engine
  baseline honest by construction (a class carried by an official archive is the engine's, even when an SKSE
  loose override wins the file), and answers "is the pairing plausible and healthy", never "does the DLL
  register exactly these functions" — runtime behaviour, the honest tier-E ceiling it never crosses.
- **`housecarl_skse_config_audit` — the form references your SKSE configs declare vs your real load order.**
  Reads the winning copy of every `.ini` / `.toml` / `.json` / `.yaml` config across the full depth of
  `Data\SKSE\Plugins`, extracts every form-shaped reference (a hex FormID paired with a plugin name in either
  order — the DSD/po3, SkyPatcher, and tilde forms — plus plugin-named folder gates), and resolves each to a
  verdict: **OK**, **PLUGIN MISSING**, **DANGLING** (plugin present but no such record), or **UNPARSEABLE**.
  The summary separates **BROKEN** (dangling / unparseable — actionable) from **INERT** (a plugin you don't
  have installed — usually optional support), so a genuinely broken patch is caught by houseCARL instead of by
  a silent in-game failure. Framework-agnostic: it checks reference *validity*, never what a reference is
  *for* (that's per-framework skill territory) or what the DLL *does* with it (the honest ceiling).

**Enhancement**

- **`housecarl_skse_inventory` gains `peek=` — a static peek inside a specific DLL's image.** With `filter=`
  naming a DLL, `peek=true` reports the DLL's imports and the config paths and plugin names it embeds —
  answering "what does this unfamiliar DLL touch" without loading it. Per-DLL by design (a whole-layer peek
  would read every image and drown signal in noise), so a bare `peek=true` fails loud asking for a filter.

**Fixes**

- **`check_errors` no longer false-flags a faction owner's required rank as a dangling reference.** A record
  owned by a faction at a required rank was misread as carrying a broken link; the rank is a valid part of the
  ownership structure, not a form reference, and is now recognized. (#207)
- **`bulk_create` / `create_record` now fill a dialogue branch's `Flags` (DNAM).** Mutagen omits a null
  optional subrecord, and the engine reads an absent DNAM as **top-level** — so a `DialogBranch` you never
  marked top-level was silently published to the player's dialogue menu: byte-valid, passing every check, wrong
  only once the game loaded it. The CK-parity auto-fill now seeds `Flags` (matching how it already handles
  `Category`), surfaced as an explicit op, and `validate_dialogue` warns when a branch carries no DNAM. (#212)

## 1.8.1 — 2026-07-16

A small read/query-surface patch: two refinements that let a whole-plugin audit and a record read land the
answer in one call instead of a workaround. No new tools or skills (still 43 tools / 13 skills).

- **`cross_plugin_query where=` gains `exists` / `missing` — presence filtering on whole fields.** The value
  operators (`=`, `>=`, `contains`, the bitwise `has`, …) test a *scalar* leaf, so "which records actually
  CARRY a script adapter / an effects list / conditions" meant a sweep-then-filter, one call per record
  type. `where=["VirtualMachineAdapter exists"]` now returns exactly the records that carry that field, and
  `missing` is its complement. "Present" means present **and non-empty** — a non-null substruct or a list
  with at least one element — so an empty list reads as absent, not carried. A mistyped field still fails
  loud, never a silent "0 matches". (#197)
- **A struct's lone FormLink now renders as its identity at `depth=2`.** Reading an NPC's `Perks` at depth 2
  showed each entry as a bare `[PerkPlacement]` with no perk FormID, so the links read as "not surfaced".
  Any struct that has no name-like identity but exactly one FormLink now surfaces it —
  `Perks[0] = [PerkPlacement] Perk=03AF81:Skyrim.esm` — matching what script properties already do with
  `Name=`. Two or more links stay opaque (ambiguous — not guessed). (#198)

## 1.8.0 — 2026-07-15

houseCARL gains two capability layers at once: a **keyless Nexus update-checking** stack — know which of
your installed files are actually out of date, at the exact-file level, trace a file to its mod by hash,
with a raw GraphQL backstop under it — and a **bulk / fleet data surface** — resolve many FormIDs to
identity, diff two plugins' versions of a record, and a batch of aggregation flags on the query, write, and
read surfaces, fronted by a new planning skill. **Six new tools (→ 43) and one new skill (→ 13).**

**Nexus update checking — four new tools and a wider `nexus_mod`**

- **`housecarl_update_status` — read MO2's own update cache, with no network.** MO2 already records, per
  mod, the newest file it last saw on Nexus; this reads that local cache (each mod's `meta.ini`) and reports
  every installed mod whose cached "newest" differs from what's installed — narrowing a whole-order update
  pass to just the candidates before a single network call — and prints each mod's `id#fileid` verify token
  for the live check below. It reports a *difference to verify*, never an asserted "a newer version exists"
  (the cache can lag or lead), and sets the mods with no fileid (FOMOD / manual installs) aside as their own
  manual-verify bucket instead of folding them into "fine".
- **`housecarl_nexus_check_updates` — batch, file-level "is this the current file?".** Pass each mod as
  `id#fileid` and it tells CURRENT from OUTDATED for the **exact file you installed**, not the mod's newest
  MAIN file — the distinction that matters on a multi-file page, where an old-version compatibility patch and
  the current main file share one mod id and a mod-level version compare lies. It resolves manager-only
  (`nxm`, "author disabled direct download") mods that the Nexus search collection excludes — reading them
  through their file data rather than stamping them "not found" — and calls out a genuinely hidden / deleted
  page, and an installed file that's since been pulled, as their own distinct, loud outcomes.
- **`housecarl_nexus_identify` — trace a file to its mod by MD5 hash.** Give it one or more file MD5 hashes
  (the fingerprint a mod manager matches an unknown download by) and it names the source mod, file, and
  version straight from Nexus — keyless — for a file whose origin you've lost.
- **`housecarl_nexus_graphql` — raw, read-only query over the keyless GraphQL.** The completeness backstop
  beneath the curated Nexus tools: when you need a field they don't surface yet (a mod's page tags, say),
  this passes a read-only query through the same public keyless API, so nothing on Nexus is permanently out
  of reach. Prefer the curated tools; this is the escape hatch, not the front door.
- **`housecarl_nexus_mod` reads more of a page.** `files=true` lists every uploaded file; `changelog=true`
  (with an optional `since=`) returns the per-version changelog and the delta between your version and the
  latest; and a mod's page tags now come through — so "what changed since my version, and what kind of mod
  is this?" is answered without a browser. All Nexus traffic now identifies houseCARL by name and version,
  per Nexus's Acceptable Use Policy.

**Bulk / fleet data surface — two new tools, plus query, write, and read flags**

The tool surface was shaped for one record at a time; heavy fan-out runs used it as a bulk data API and had
to improvise the aggregation themselves. This wave adds that aggregation as type-agnostic primitives —
coverage still inherited from the reflection layer, so there are no per-record-type tools.

- **`housecarl_resolve` — many FormIDs → identity, in one call.** Hand it a list of FormIDs and it returns
  each one's record type, EditorID, display name, and load-order winner, with a malformed entry isolated as
  its own per-item error instead of failing the batch. The bulk answer to "what *are* all these forms?".
- **`housecarl_diff_record` — a field-level diff between two plugins' versions of a record.** Point it at a
  FormID and two plugins (`plugin_a` vs `plugin_b`) and it returns only what differs between their two
  versions — either pole active in the load order or read off-order from a plugin sitting on disk — each
  delta self-labeled by the plugin it came from, so a patch rebuild reads the change instead of re-deriving
  it from two full reads and hand subtraction.
- **`housecarl_cross_plugin_query` gains aggregation.** `defined_in=` narrows a `plugins=` scope from every
  record a plugin *touches* (definitions plus overrides) to only the ones it *defines*; a list-valued
  `references=` runs N reverse-lookups in one scan (each hit labeled with which target it matched);
  `group_by=winner|type|defined_in` returns a count table over **all** matches instead of a capped list; and
  `winner_fields=` reads each match's field values from the true load-order winner — with a loud note when a
  `plugins=` scope is otherwise showing scoped-not-winner values, closing a subtle "these numbers don't
  match what I see in game" trap.
- **`resolve_names=` and `format="json"` across the read surfaces.** `resolve_names=true` annotates every
  FormLink in a read with its EditorID and name inline (display-only — the underlying wire token is
  untouched); `format="json"` returns the same outcomes as a machine-readable document with the accounting
  (truncation, no-value leaves) carried in-band, so a fan-out consumer parses the result instead of scraping
  the text.
- **Batch writes — `composes=` and `CopyFrom`.** A write op can now carry `composes=`: a list of
  build-from-parts elements applied in one operation (`Add` appends each, `ReplaceAll` replaces the whole
  modeled list — and `ReplaceAll composes=[]` clears it). And a new **`CopyFrom`** verb transplants a
  field's value from another plugin's version of the record — active or off-order, any field the reflection
  layer models — the reflection-generic generalization of copying an appearance or a stat block across
  plugins.

**New skill (→ 13)**

- **`bulk-record-jobs` — plan "many records → one structured deliverable" jobs.** Catalogues, link and
  recipe graphs, conflict surveys, patch rebuilds, and any fan-out that extracts structured data: this skill
  routes them onto the bulk primitives above (scoped queries, `group_by`, `resolve`, `diff_record`, batch
  writes) instead of per-record loops, carries the game-generic Creation-Kit conventions those jobs need
  (craft vs temper, what a workbench keyword means structurally), and pins one canonical deliverable schema
  so a fleet of subagents stops inventing eight different output shapes. Game-generic only — a specific mod's
  own conventions stay in that mod's skill.

**Finishing an unenabled plugin, and fixes**

- **A pre-enable finishing lane.** `housecarl_check_errors` and `housecarl_compact_plugin` now accept a
  plugin that isn't enabled yet, and `housecarl_read_plugin_file` locates a mod folder that isn't in your
  load order (a freshly-authored houseCARL patch, found by filename) — so you can sweep, compact, or read a
  just-authored plugin before enabling and sorting it in MO2.
- **SkyPatcher interpretation reads more INIs honestly.** A `skin=<donor NPC>` directive is now classified
  rather than throwing, and a bracketed `[Label]` line is treated as the inert grouping label it is, not a
  malformed patch.
- **New-patch naming is collision-safe and un-doubled.** The default patch stem is now `Patch` — dropping
  the doubled `houseCARL - houseCARL_Patch` — and it is checked against the active load order so a fresh
  patch can't collide with an existing plugin's name.
- **A container-read hint now names a knob that actually exists** (it had pointed at a parameter the tool
  doesn't take).

## 1.7.1 — 2026-07-13

A maintenance release: sharper, louder tool feedback and a write-lane fix. No new tools (still 37) or
skills (still 12).

**Query & read surface**

- **A `where=` filter that finds nothing now tells you *why*.** When a field-value predicate read no value
  on every scanned record, the note used to guess "likely a mistyped path" for *every* cause — so a perfectly
  valid field that simply happens to be unset everywhere read as "this field is unreadable." It now classifies
  the actual cause — a wrong/mistyped field, a container/list path, a read fault, or a valid-but-unset field —
  and names the matching next move (for example, that a dialogue topic's player-facing text lives on the DIAL
  `Name`, not the INFO `Prompt`).
- **Unknown tool parameters are now rejected instead of ignored.** A misspelled or unsupported parameter name
  fails loud, rather than being silently dropped and looking like it had no effect.
- **Clearer container/list rendering and biped-slot decode in reads**, and the `depth=` hint now appears only
  on the tools that actually support it.

**Write lane**

- **`housecarl_set_field` `SetAtIndex` composes modeled list elements correctly** — setting an element of a
  modeled list (rather than a plain scalar) no longer mis-applies.

## 1.7.0 — 2026-07-11

houseCARL learns to **see through more of the runtime layer than the record alone**: merge plugins together,
read and write the data baked inside a mesh (`.nif`), and read the entire SkyPatcher layer end to end — what
it does, where it conflicts, and what a record truly looks like after it replays. **Six new tools (→ 37)**;
the skill set is unchanged at 12. Plus a dialogue CK-parity push and a batch of write-lane fixes.

**Six new tools (→ 37)**

- **`housecarl_merge_plugins` — merge several plugins into one new plugin.** A RECORDS-level merge with a
  winner-first graft walk: it renumbers FormIDs **only on collision**, drops masters the merged set no longer
  needs, and swaps the donor mods out at the **MO2 layer** (their folders stay on disk, just disabled) — your
  originals are never rewritten. References it can't fold are reported, never silently dropped.
- **`housecarl_copy_npc_appearance` — copy an NPC's appearance into a standalone.** The composed payoff of the
  standalone-NPC-copy chain: lift a donor NPC's whole appearance — head parts, tints, and the FaceGen mesh and
  textures — into a fresh record that carries **no dependency on the donor's plugin**, auto-widening the file
  lane to the donor's defining plugin. The build behind a portable follower or a face moved between mods, in
  one call instead of a dozen papercut edits.
- **`housecarl_nif_inspect` — read the data values inside a Skyrim mesh (`.nif`).** Open the winning copy of a
  mesh and read what's baked inside it: shape names, the embedded skin / FaceTint texture paths, shader flags,
  alpha, and partitions. houseCARL's first look *inside* a NIF, and the diagnostic half of the dark-face bug —
  is the face mesh pointing at the wrong texture, or is a shape misnamed?
- **`housecarl_nif_set` — write a whitelisted value back into a mesh (`.nif`).** The write companion to
  `nif_inspect`: rewrite a wrong embedded texture path or rename a shape, gated to a whitelist of safe fields
  and verified two ways — an offset-immune block-content diff **plus** a semantic read-back — so a mesh is
  never quietly corrupted. The repair half of the dark-face fix, without leaving houseCARL for NifSkope.
- **`housecarl_skypatcher_layer` — inventory the entire SkyPatcher layer at once.** Every SkyPatcher INI across
  your load order resolved into one picture: apply-order union, VFS shadows, filename gates, and INI-vs-INI
  conflicts — plus the full **ITM triple** (intra-file dead writes, cross-INI duplicates, and true no-op writes
  that change nothing). Report-only: it tells you what the layer does, it never touches it.
- **`housecarl_skypatcher_read` — a record's true state after SkyPatcher.** Replays the whole SkyPatcher layer
  over a single record, in order, and reports what it actually looks like at runtime — the complete filter
  surface, stateful op-by-op, with tiered honesty on the operations it can't fully model. A runtime INI edit
  made as visible as a plugin override.

**Dialogue & authoring (CK parity)**

- **Authored dialogue now matches the Creation Kit down to the byte on quest aliases.** Beyond the
  INFO / DLVW / DLBR / QUST / DIAL fields 1.6.0 closed, a newly-authored quest alias now gets the flags (FNAM)
  and voice types (VTCK) the CK fills in — so a hand-built quest's aliases don't read as subtly wrong.
- **`housecarl_validate_dialogue` closes the matching residual.** It validates the DLVW / DLBR inputs and the
  quest ANAM / FNAM the CK-parity pass fills, and flags a live INFO that's missing its prompt / response text
  (CNAM / ENAM).
- **The SkyPatcher authoring reference is extended to the full Wave 0–2 grammar** and the 27-record-type
  operation→field map that underpins the two new SkyPatcher tools.

**Fixes**

- **Edit tools resolve the extended patch.** An `@editorid` self-reference, and an edit whose `into=` targets a
  patch you haven't enabled yet, now resolve correctly against the patch being extended.
- **In-place and forward-record flows hardened** against a batch of edge-case defects surfaced in live testing.

## 1.6.0 — 2026-07-06

houseCARL learns to **see the parts of your workspace it was blind to**: read a plugin that isn't in your
active load order (even one inside a disabled mod), inventory the SKSE-plugin (DLL) layer, and catch Papyrus
script properties a plugin declares but never fills. **Three new tools (→ 31) and one new skill (→ 12)** —
plus a substantial dialogue- and record-authoring push, and a batch of silent-wrong and fail-loud fixes.

**Three new tools (→ 31) — new visibility layers**

- **`housecarl_read_plugin_file` — read any plugin file's own records, even one that isn't active.** houseCARL
  builds its world from your active MO2 profile, so a plugin you've unchecked — or one sitting in a *disabled*
  mod folder — used to be invisible. This read-only tool opens a named plugin file directly (active or not, by
  filename or absolute path) and returns **that file's own version** of a record, enumerates the records it
  defines (optionally filtered by type or EditorID), or summarizes it by record type. Every result is loudly
  stamped **OUT-OF-LOAD-ORDER**, so a raw-file read is never mistaken for load-order truth; it has no
  winner/conflict semantics by construction, and it resolves FormLinks against the file's declared masters
  wherever they sit on disk — telling you if one is missing or inactive rather than guessing. This is the
  enabler for inspecting a donor mod *before* you enable it, with no MO2 enable/disable dance to read one file.
- **`housecarl_skse_inventory` — see the SKSE-plugin (DLL) layer.** A full-depth inventory of
  `Data\SKSE\Plugins`: every `.dll` and every config file (grouped by its derived subfolder — SkyPatcher,
  DynamicStringDistributor, OStim, … — never a hardcoded list), each resolved to its winning MO2 provider with
  the **full winner→loser conflict chain** (loose/BSA tagged), and each winning DLL's version metadata decoded
  **statically, without loading it** — name / author / version, Address-Library vs version-locked, target
  runtimes. The record layer has always been houseCARL's home; this is the first look at the binary layer beside
  it, and it's honest about its ceiling: it reads a DLL's declared metadata, never its behavior (a legacy DLL
  whose version is only set at runtime says exactly that; an unreadable PE is flagged, never guessed).
- **`housecarl_validate_scripts` — catch script properties left silently unbound.** A Papyrus script attached to
  a record (VMAD) can declare a property in its compiled `.pex` that the record never actually fills — a silent
  `None` at runtime that throws no error and just makes the script quietly misbehave. This read-only sweep
  compares each attached script's compiled property list against what the record binds and reports the gaps,
  correctly leaving **alias-bound** properties (filled by the quest at runtime, not on the record) alone so they
  aren't false-flagged.

**One new skill (→ 12)**

- **`skse-plugin-authoring` — author an SKSE plugin in C++ against CommonLibSSE-NG.** houseCARL's first skill
  that leaves the data layer for the code layer: it walks the full lifecycle of building an SKSE DLL — project
  scaffolding, the plugin entry points and messaging interface, Papyrus-native functions and hooks, and the
  CommonLibSSE-NG idioms — so Claude can help write a plugin, not just read the records around it. Pairs
  naturally with the new `skse_inventory` tool (see the DLL layer; author into it).

**Dialogue & record authoring**

- **Fill a whole modeled-struct field in one op (`compose-Set`).** `set_field` / `bulk_apply` can now set an
  entire sub-struct in a single operation instead of one leaf field at a time — the authoring ergonomics
  prerequisite behind composed multi-record flows (e.g. rebuilding an NPC's appearance subtree).
- **Clear a nullable field via `Remove`.** A nullable polymorphic field or a nullable sub-struct can now be
  cleared back to unset with `Remove` — for example, un-fragmenting an INFO whose script fragment you want gone,
  cleanly rather than by writing an empty stand-in.
- **`@editorid` same-call sibling references now work inside list fields.** An `Add` / `ReplaceAll` onto a
  FormLink **list** can reference a record created earlier in the same call by its EditorID, so a batch that
  creates records and wires them together no longer needs a second pass for the list-typed links.
- **Single-gender records just author cleanly.** Creating a record with only one half of a gendered FormLink set
  (a single-gender skin/armor) now materializes the un-set half as an empty link instead of crashing, and
  editing an existing single-gender record stays safe.

**Dialogue fixes (CK-parity byte tier + validator)**

- **A newly-authored dialogue record now matches what the Creation Kit writes.** `create_record` / `bulk_create`
  default-populate the byte-level fields the CK fills in on a fresh INFO / DLVW / DLBR / QUST / DIAL that a raw
  insert would leave blank — the class of "byte-valid but plays wrong / won't start" traps that make hand-built
  dialogue silently fail.
- **`housecarl_validate_dialogue` got sharper.** It no longer false-warns on the standard PlayerRef player-state
  gate (see the `check_errors` fix below — same engine-implicit whitelist), flags a `<Global=X>` text tag that
  names a global the owning quest doesn't carry (renders as `[…]` in game), and auto-flags a `.seq` left stale
  by an in-place edit.

**Fixes**

- **`housecarl_check_errors` no longer drowns in false PlayerRef errors.** The integrity sweep was reporting
  every reference to the engine-implicit PlayerRef (`000014`) and Player (`000007`) forms as a dangling
  reference — on a real load order that was hundreds of false positives that overflowed the response. Those
  hardcoded engine forms are now recognized and exempted (a precise two-form whitelist, not the whole reserved
  range, so a genuinely broken low reference still surfaces).
- **`Remove` on a FormLink is now correct in both directions.** Removing a *nullable* scalar FormLink clears it
  to an empty link (instead of throwing); removing a *required* FormLink that can't be legally emptied now fails
  loud with a clear message (instead of silently doing the wrong thing).
- **A failed BSA extraction says why.** When BSArch writes nothing, `housecarl_bsa_extract` now names the actual
  cause instead of reporting an empty success.

## 1.5.0 — 2026-07-02

houseCARL gains **plugin surgery**: ESL-compact a plugin with its FormID-keyed assets (facegen, voice, SEQ)
carried along automatically, and sweep the whole load order for record errors. **Two new tools (→ 28).**
Plus a crash fix for newly-authored dialogue topics, a compact in-place verify read-back, and a batch of
silent-failure and ergonomics fixes.

**Two new tools (→ 28) — plugin surgery arrives**

- **`housecarl_compact_plugin` — ESL-compact a plugin, records AND the files keyed to them.** Renumbers a
  plugin's own records into the ESL FormID window (`0x800`–`0xFFF`), sets the small-master flag, and repoints
  every internal reference — writing a **new** compacted file by default, with the original untouched; editing
  the original in place is opt-in and gated by the same consent handshake as the in-place write lane. What
  sets it apart from a manual compact: **the assets whose filenames encode a FormID move with the records** —
  facegen pairs (facegeom `.nif` + facetint `.dds`) and voice files (`.fuz`/`.lip`) are carried to the new
  FormID paths, and the plugin's `.seq` is regenerated (refresh-only — houseCARL updates a `.seq` that exists
  and warns if one is needed, it never invents one). Renumbering an NPC without renaming its facegen is how a
  compacted mod's faces go dark; the tool closes that whole failure class in one operation. If **other
  plugins** reference the records being renumbered, the tool identifies them by name and fails loud —
  repointing them is a separate opt-in, never a surprise edit.
- **`housecarl_check_errors` — load-order integrity sweep.** The data-layer twin of the Creation Kit's "Check
  For Errors" / xEdit's error check: for every plugin in scope (one, several, or the whole active order) it
  walks every record's FormLinks and reports **dangling references** (a link no active plugin defines),
  **missing masters** (a declared dependency not installed/enabled — the most common load-order break), and
  **parse failures** (records or whole plugins that couldn't be read). Read-only, and explicit about its
  boundary: it covers the reference/master/parse class, not navmesh or terrain spatial integrity.

**Write-lane fixes**

- **In-place verify read-back is now compact by default.** The forced post-write verify on an in-place edit
  used to deep-dump every touched record — on records already carrying big lists it overflowed the response
  budget and could read as "only some of your edits applied" when all of them had. It now renders one
  confirmation line per record (what landed, re-read clean), covering **all** touched records; the full
  field-by-field dump stays behind `full_readback=true`, now bounded so its truncation notice actually reaches
  you. Corruption detection is unchanged — every record is still deep re-read, only the output slimmed.
- **Silent write failures made loud.** A collection verb against an array-backed field now refuses with a
  clear message instead of crashing mid-write, and list elements typed as `IAssetLink` interface forms now
  coerce correctly on write.

**Ergonomics**

- **`housecarl_compile_script` names the real cause of a missing-import failure.** When a compile fails with
  errors dominated by unresolved symbols/types — the signature of an incomplete `import_dirs`, which can
  produce hundreds of errors that look like code bugs — the result now leads with a prominent "incomplete
  import_dirs, not a bug in the script" banner. The classifier is keyed on the compiler's actual error wording
  and gated on a supermajority, so a genuine typo is never mislabeled.
- **A near-miss plugin name now gets a "did you mean."** A `lookup=`/`plugins=`/FormID plugin name that isn't
  in the load order — an apostrophe slip, a typo, or the mod *folder* name passed for the plugin *filename* —
  now suggests the nearest real plugin(s) instead of a flat "not in the load order," across
  `housecarl_load_order_status`, `housecarl_cross_plugin_query`, and `housecarl_read_record`. No suggestion is
  offered unless a candidate genuinely clears the bar — a wrong "did you mean" is worse than none.
- **MO2 2.5.x instances are recognized.** `ModOrganizer.ini` files written in the spaced `key = value` form
  (MO2 2.5.x) now parse correctly.

**Dialogue fixes.** A dialogue topic (DIAL) carries its subtype in two places that must agree — the numeric
`Subtype` and a 4-character `SubtypeName` (SNAM) marker the game actually buckets topics by. houseCARL wrote
the number but left the marker blank, so a newly-authored topic crashed on load (community report #131, by
matashina).

- `housecarl_create_record` / `housecarl_bulk_create` — a new DIAL now gets its **SNAM marker auto-filled**
  from its `Subtype` (`Hello`→`HELO`, `Goodbye`→`GBYE`, a bare/`Custom` topic → `CUST`, …) and reported, so
  it's never silent; an explicit `SubtypeName` you set is never overridden. The subtype→marker table is
  sourced **by construction** from xEdit's DIAL definition (all ~100 subtypes) and CI-guarded against drift.
  A subtype with no modeled marker (an out-of-range value) fails loud instead of writing a blank marker.
- `housecarl_set_field` / `housecarl_bulk_apply` — changing an existing topic's `Subtype` without also setting
  `SubtypeName` now **syncs the marker** to match (both the new-patch and in-place lanes), so a subtype change
  isn't a silent in-game no-op.
- `housecarl_validate_dialogue` — a blank SNAM marker is now a reported issue that names the expected marker:
  an **error** on a newly-authored topic (the #131 crash), a **warning** on an override (where the base
  record's marker can still apply).

## 1.4.0 — 2026-06-24

houseCARL can now **edit an existing plugin in place** — including a mod it didn't author — instead of
only ever writing a separate patch, rounding out the write surface with the same fail-loud,
verify-what-you-touched discipline as the patch lane. Alongside it: three new tools (forward a named
plugin's record as an override, resolve a magic effect's carriers, author an empty trigger plugin), three
new bundled skills (→ **11**), a wider and sharper dialogue validator, a bitwise query predicate for
equip-slot and flag fields, and several silent-wrong-answer fixes. **Three new tools (→ 26), three new
skills (→ 11).** Carries further community contributions from **DrHeisen**.

**In-place write lane — edit, create, and remove records directly in an existing plugin**

- **houseCARL can now write straight into a plugin you point it at — including one it didn't author —
  instead of always emitting a separate patch.** The five write tools (`housecarl_set_field`,
  `housecarl_bulk_apply`, `housecarl_create_record`, `housecarl_bulk_create`, `housecarl_remove_record`)
  gain `target=`, `in_place=true`, and `acknowledge=`. With them houseCARL edits existing records, creates
  brand-new ones (flat, nested children like a dialogue line or a placed reference, or a whole cell), and
  removes records the file carries — rewriting the original plugin the way xEdit or the Creation Kit do on
  save (the author's master list and FormID counter preserved, every record it touched verified on
  read-back). The default new-patch lane is unchanged and stays the default.
- **Behavior change worth knowing:** the in-place lane edits your original file and keeps **no backup** — a
  deliberate departure from houseCARL's default "originals are never touched." It is strictly opt-in
  (`in_place=true`) and gated by a one-time consent handshake per plugin: the first in-place touch of a
  given file names the exact path and the no-undo trade-off and writes nothing until you re-call with
  `acknowledge=true`, then never asks again for that plugin (the consent is remembered across sessions and
  shared across edit / create / remove). Keep your own backup of anything you edit in place. Files edited
  this way are marked `editedInPlace` (never houseCARL-owned), so a later `into=` extend can't
  blind-overwrite your mod. A plugin whose own records use reserved sub-`0x800` FormIDs (vanilla / Creation
  Club) is refused in place — you override those, you don't edit them.

**New tools**

- **`housecarl_forward_record` — copy a named plugin's version of a record as an override.** The inverse of
  `set_field` / `bulk_apply`, and the data-layer equivalent of xEdit's "copy as override into": it copies a
  *named* earlier plugin's whole record verbatim into a patch so it wins again — re-assert one mod's version
  of a record over a later override, or name a master to revert a record to vanilla. Works for every record
  type, nested Cell / Placed / INFO families included. It refuses loudly (writing no file) on a bad source —
  one not in the load order, the output patch itself, a source that doesn't define the record, the same
  target named twice — and flags a forward whose version already wins as redundant.
- **`housecarl_effect_chain` — a magic effect's carriers and magnitudes in one call.** Point it at a
  MagicEffect (MGEF) and it resolves every spell, enchantment, potion, scroll, and ingredient across the
  load order that applies it, each with the magnitude / area / duration from the matching effect entry (as
  authored — conditions are not evaluated). It collapses the old "query references, then read each hit" loop
  across five record types into one read, and fails loud rather than returning a silent zero: a
  non-MagicEffect FormID errors naming the real type, an absent FormID errors, and a genuinely unused effect
  returns a clean, distinguishable zero.
- **`housecarl_create_plugin` — author an empty header-only "trigger" plugin.** Emits a valid plugin with a
  TES4 header and zero records — the clean primitive for "I just need `Foo.esp` to exist": a basename-bound
  SKSE config trigger (the CraftingCategories-style pattern where a config loads because `Foo.esp` is
  present), a placeholder ESL for FormID reservation, or a dummy master. Before, a trigger plugin had to
  carry a junk filler record that polluted the conflict tree. The name is used verbatim (the basename is
  load-bearing, so no auto-suffix) and a collision refuses loudly rather than renaming or overwriting;
  `esl=true` flags it a light master.

**Dialogue validation & authoring**

- **`housecarl_validate_dialogue` gained five new lint families** (all advisory — it warns, never blocks,
  never auto-fixes): text-encoding (a player-facing string carrying a non-ASCII character that would render
  as in-game mojibake, with the offending character and an ASCII substitute named); result-script fragment
  presence (how many of a topic's lines actually carry a script fragment, so you know whether to expect
  runtime behavior); SEQ staleness / coverage (a Start-Game-Enabled quest whose plugin has no `.seq`, a
  `.seq` that doesn't list it, or one older than the plugin — meaning the quest and all its dialogue
  silently never start on a fresh save — and it also tells you when a regen is *not* needed); and static
  condition (CTDA) well-formedness (dead run-on references, dead alias indices, dangling form / global
  parameters, GetIsID pointed at a placed reference instead of a base object).
- **Deep reads now show VMAD script-property values.** A `depth>=2` read of a script's Properties prints
  each property's value — the Object FormLink, the Data scalar, the alias — instead of stopping at the
  identity line, matching xEdit; a declared-but-unset Object shows a named `(null link)` rather than
  vanishing.
- **Condition form targets accept the flat `fields:` shorthand.** Composing a condition's data arm and
  setting its form-link-or-index target through the flat `fields:` map (e.g.
  `GetEquipped {ItemOrList: "0001F4:Skyrim.esm"}`) was wrongly refused at pre-flight; it now lands a target
  in both form and alias-index mode, byte-identical to the verbose path, across the whole FLOI
  condition-parameter class.
- **The `dialogue-authoring` skill gained substantial reference depth** — CK pages for decoding a CTDA
  condition (a ~40-function dialogue table), the DLBR branch entry point and its Exclusive-branch deadlock,
  and the quest stage / objective model; a set of authoring traps the flow model implies but the validator
  can't catch (Stop() resets a quest's stage, a monologue is several Responses in one line, CK conditions
  can't express (A AND B) OR (C AND D), GetStageDone vs GetStage); and write-side recipes for cloning a
  verified condition gate across many lines and writing a CK-refused INFO subtype.

**Querying & equip slots**

- **`housecarl_cross_plugin_query` gained a `has` bitwise predicate** for bitmask / flag fields:
  `where ... has Body` (or a bit value, decimal or `0x` hex) matches if that bit is set regardless of the
  others — so a multi-slot armor whose `BodyTemplate.FirstPersonFlags` carries body *plus* a modder slot is
  now findable, where exact `=` only matched a single-slot piece. For `[Flags]` enum fields, range operators
  now compare the numeric value (`>= 65536` no longer errors) and `=` / `!=` equate by resolved bits (so
  `= 16` matches a field that renders as the flag name). **Behavior change:** a query that relied on the old
  exact-string-or-error behavior for a `[Flags]` field may now return different results; non-flags enums are
  unchanged.
- **New `biped-slot-reference` skill** — the ergonomic layer over `has`: it turns a biped slot (a number
  like 52, a vanilla name like Body, or a community label like SOS / pelvis) into the `FirstPersonFlags` bit
  to query on, so finding every armor on a slot is a lookup instead of power-of-two mental math. Ships a
  verified slot 30–61 table (the named bits are non-contiguous — the trap a from-memory table gets wrong)
  and the multi-slot query pattern.

**Correctness fixes**

- **Localized fields on cleaned base-game masters read correctly again.** A localized master sitting in a
  folder with no strings of its own — the near-universal "Cleaned Base Game Masters" setup, where a cleaned
  DLC / Update `.esm` lives in a bare folder while its `.STRINGS` stay in the game-Data BSAs — was reading
  every localized field (Name, DESC, …) as **empty**, so `where Name contains …` silently zero-matched the
  DLC masters and a read showed a blank Name. houseCARL now points the strings lookup at the real game-Data
  folder when (and only when) the plugin's own folder carries no strings source. **Behavior change:**
  queries and reads against those masters can now return matches and content where they used to find
  nothing. As defense-in-depth, a genuinely unresolved localized string now renders the loud
  `(unresolved localized string)` note instead of a blank that looked like a real value.
- **`into=` resolves a renamed patch folder.** Extending your own houseCARL patch after you renamed its MO2
  mod folder for organization used to fail — `into=` demanded folder name, suffix, and `.esp` basename all
  match. It now resolves by plugin name (the folder holding `<stem>.esp`, whatever it's now called) then
  folder name, refusing loud only if two owned folders are genuinely ambiguous. The same fix was extended to
  the rider / asset write path behind `compile_script`, `decompile_script`, `bsa_repack`, `place_asset`, and
  `bulk_place_asset`, which had still carried the old three-way match. A foreign, un-owned plugin stays
  refused.

**New skills & reference depth**

- **New `oar-authoring` skill** *(DrHeisen)* — author or interpret Open Animation Replacer (OAR) configs:
  the runtime, condition-driven animation system (`config.json` / `user.json`) that supersedes DAR and still
  reads its legacy `_conditions.txt` folders. Ships a source-verified reference (the full schema, the
  ~120-condition roster, the authoritative `IsEquippedType` enum — which OAR deliberately diverges from the
  vanilla `GetEquippedItemType` enum — the DAR grammar, and the global INI) plus a playbook for the
  counter-intuitive parts: OAR ignores plugin load order and picks winners purely by `priority`; the
  top-level array is lowercase `conditions` while a nested `AND`/`OR` child array is capital-C `Conditions`;
  `user.json` is a full-document shadow of `config.json`; and an addon condition (Math / RaySense / IED /
  Detection / Dialogue) silently no-ops when its DLL is absent. It complements the distributor skills — it
  authors animation CONFIGS, while forms-to-NPCs is SPID, keywords-to-items is KID, and record fields is
  SkyPatcher.
- **New `tool-output-awareness` skill** *(DrHeisen)* — recognize the plugins and assets that generated tools
  produce (Reqtificator, ParallaxGen, DynDOLOD, Synthesis, TexGen, xLODGen, NPC Plugin Chooser 2) and keep
  their re-derived records and asset paths out of an authored patch, so you never bake a regenerable
  artifact into a hand patch that goes stale — or silently breaks — the next time the tool runs.
- **`papyrus-reference` now loads before any `.psc` read *or* edit** — including an edit that only reuses a
  call already in the file (a copied call is not a verified call; "the compiler will catch it" covers
  signatures, not semantics) — and bundles a new "silent-biters" reference of Papyrus traps that compile
  clean but misbehave at runtime (GetFormEx vs GetForm for the ESL range, SendModEvent handler arity,
  FormList.HasForm missing base NPCs, Utility.Wait in a paused-menu handler, and more).

## 1.3.0 — 2026-06-21

The biggest release since 1.0: a VFS-aware **asset layer** (read which copy of any file wins; place a file
as a winning override), end-to-end **dialogue authoring** (compose a whole conversation in one call, audit a
dialogue graph, write start-game-enabled `.seq` files), a Mutagen-native **script decompiler**, a much wider
and more honest **write pre-flight**, and a broad sweep of **crash-atomic / MO2-disk correctness**
hardening. Seven new tools, two new skills. Carries an outside code contribution from **AlmightyChan** (the
`create_record into=` upsert, #44/#45).

**VFS asset layer & FaceGen**

- **houseCARL now answers "which copy of a file actually wins?" the same way it answers it for records.** A new VFS-aware asset layer resolves any Data-relative path — mesh, texture, script, sound, interface file — against the active load order and reports the winning copy (the overwrite folder, a specific mod, Data, or inside a BSA), loose-vs-BSA aware. This is the file-layer counterpart to a record's load-order winner: before, houseCARL could tell you which plugin wins a record but had no way to tell you which mod or archive wins a given file path. Exposed through the new `housecarl_asset_status`, running against the real, live load order with zero file/archive handles held at rest — the same contract as the record resolver, so MO2/xEdit can move files freely.
- **You can now place a file as a winning override into a fresh houseCARL mod.** Two new tools write the asset side: `housecarl_place_asset` puts one file in place, and `housecarl_bulk_place_asset` puts many into a single mod folder in one call. The source can be a loose file, one entry pulled out of a BSA, or a whole BSA; the destination can be a raw asset path or — for an NPC's FaceGen — a FormID plus kind (mesh/tint), with the path computed from the FormKey. Before, houseCARL could read which copy of a file wins but could only tell you what to do by hand to make a different copy win. Writes are crash-atomic and non-destructive: originals are untouched, a fully-failed batch leaves no orphan folder, and a reused destination folder is never deleted. The tools are honest that "wrote it" is not "it wins" — every response reports the current winner and the MO2 enable-plus-sort step still required.
- **New `facegen-diagnostics` skill.** houseCARL's 7th shipped skill walks the dark / grey / black-face NPC bug end to end — it resolves the NPC to a FormKey and compares two independent precedence systems (which plugin wins the NPC record vs which mod or BSA wins the facegen `.nif`/`.dds` file), then either places the correct facegen as a winning override or forwards the matching appearance into a new plugin. Where the fix needs the Creation Kit, NifSkope, or RaceMenu it instructs the steps rather than faking them, and it gates every "done" behind an in-game verification handoff. It drives the new asset tools and ships with a 24-cause taxonomy and symptom table. (The asset tools themselves are framed as a general VFS capability — "which copy of any file wins" — with FaceGen as the headline use case rather than the framing.)

**Dialogue authoring & validation**

- **Author a whole dialogue conversation in one command.** `housecarl_create_record` gained optional parent/collection arguments, and a new `housecarl_bulk_create` allocates a parent and its children in a single all-or-nothing call — a DialogTopic with its INFO response lines nested under it, each with a fresh local `0x800+` FormKey. The add-target is found by construction over the parent's modeled child-collections (never per-record-type hand-wiring), and the unique / named / missing / ambiguous outcomes all fail loud. Before, the data layer could create flat records but had no way to allocate a brand-new child into a parent's collection, so a dialogue line under a topic was out of reach.
- **Same-call sibling references wire the conversation together.** Inside a `housecarl_bulk_create` call, a FormLink value of the form `@editorid` forward-references a record created earlier in the same call, resolved to that sibling's auto-allocated FormKey after allocation — so an INFO's Topic back-link and its PreviousDialog can point at sibling records that don't exist until the call runs. The mechanism is generic across any FormLink on any created record, and the sibling token is accepted only as a singular Set on a FormLink leaf, in create context, for an editorid declared earlier; everywhere else (a later/self reference, a non-FormLink field, a value inside a list or dict, the edit-existing path) it rejects loud rather than silently substituting nothing.
- **New dialogue lines are checked for the audio and scripts they need to actually work.** A byte-valid INFO can still do nothing in game — no `.fuz` on disk plays silent, and a half-built or uncompiled result-script binding fires nothing. On a successful create, the response now folds in two on-disk checks. Voice coverage flags each created voiced response that has no audio, printing the exact `Sound\Voice` `.fuz`/`.lip` path to place it at (and naming the winning provider when audio is already present); when the path can't be computed (no Speaker, or an unresolvable voice type) it says so with a named reason instead of a false "fine". Result-script binding flags an INFO whose VirtualMachineAdapter is hollow or whose bound script class has no compiled `Scripts\<class>.pex` on disk, naming the missing path. Script-free lines are never nagged.
- **New tool `housecarl_validate_dialogue` audits an existing dialogue graph on demand.** Point it at a DialogTopic (DIAL) or Quest (QUST) FormID and it resolves the load-order winners and reports the wiring: whether the quest is set and resolves (unowned is a warning), whether a set branch resolves to a real DLBR (unset is normal), the INFO.LinkTo topic-to-topic chain with broken links flagged, and a dangling PNAM **only** when it is set-but-unresolvable — empty PNAM is never flagged, since vanilla topics legitimately leave it empty and select within a topic by Conditions. It reuses the voice and result-script checks over every live INFO (closing the edit-path audit gap the create-time checks left open) and always declares the parts it cannot check (CTDA/lip-sync, the dropped-INFO conflict boundary). Read-only.
- **New tool `housecarl_write_seq` makes start-game-enabled quests actually start.** Without a `Data\SEQ\<plugin>.seq` file, a plugin's Start-Game-Enabled quests — and any dialogue gated on them — silently never start. `housecarl_write_seq` is the data-layer equivalent of the CK's on-save SEQ generation or xEdit's "Create SEQ file": point it at a plugin and it writes the `.seq` its SGE quests need. The encoding (a flat array of little-endian master-index FormIDs, never the runtime `0xFE` form) was pinned empirically against all 145 real `.seq` files in a live load order, so the file is computed wholly at author time with no runtime bridge. It writes crash-atomically and non-destructively, defaults the `.seq` into the plugin's own houseCARL folder so there's one mod to enable, and a plugin with zero SGE quests writes nothing rather than an empty file.
- **New `dialogue-authoring` skill** ties the dialogue tools into a playbook for the five Creation-Kit bookkeeping jobs a byte-valid insert skips — the silent-failure class houseCARL refuses (a line that passes xEdit but skips them plays nothing in game). It encodes the counter-intuitive dialogue policy (PNAM is ~unused; Conditions, not list order, select the line; the winning topic silently drops any line it doesn't re-list), drives `housecarl_bulk_create` / `housecarl_create_record`, `housecarl_compile_script`, `housecarl_write_seq`, and `housecarl_validate_dialogue` through those jobs, then validates the result — and reads or audits existing dialogue (what a topic does, why a line won't fire, a dropped-line conflict).

**Script toolchain**

- **Decompile any compiled script back to reviewable source.** New tool `housecarl_decompile_script` reconstructs readable `.psc` source from a compiled `.pex` with no external decompiler or compiler involved (Mutagen-native) — measured at 100% structuring (one named irreducible) and 98.80% byte-exact recompile round-trips across all 10,189 provable script pairs in a 3,400-plugin load order. Before, the only way to read what a shipped `.pex` actually does was an outside tool or guesswork. Inherent PEX losses are stated where you see them (parameter defaults are baked at call sites; comments and layout are gone), anything it can't prove fails loudly in the output (raw bytecode in the `.psc`, counted in the result) rather than rendering a silent wrong answer, and it never overwrites an existing file. BSA-packed scripts compose with `housecarl_bsa_extract` first.
- **Compiling against a mod's extended script copy now works.** When you pass `import_dirs` to `housecarl_compile_script`, your folders now outrank the vanilla auto-import (order is own folder, then your `import_dirs`, then vanilla last). Before, a vanilla copy of an extended source (SKSE's `Actor.psc` / `Game.psc` / `Form.psc` especially) shadowed the extended one — the CK compiler takes the first match — so any call to an extended function failed "not a function or does not exist" even when you had explicitly pointed at the right folder. Explicit now beats implicit, matching the game's runtime; calls passing no `import_dirs` behave exactly as before.
- **Reliability hardening across the script and BSA bridge.** The decompiler's optimizer-origin hint now also fires on statement-level `JMPT` (a flow pattern the CK compiler provably never emits), flagging a wider class of Caprica-optimized scripts — while the description keeps the honest floor: detection is pattern-based, two named flow-canonical files still stay silent, and the note's absence does **not** prove CK origin. The BSArch bridge no longer false-succeeds: `housecarl_bsa_extract` now judges success by this-run provenance (a new path, or a changed size/mtime vs a pre-run snapshot) instead of "a folder entry exists afterward" (which the ownership marker alone satisfied, so a failed run looked successful); packing refuses loud on a stale leftover scratch rather than moving it over the target; `housecarl_bsa_list` errors on any parse failure (a declared-vs-listed count mismatch is reported, not papered over); archive paths are fully normalized; and an unknown `format=` token refuses and names the legal set.

**Write pre-flight (records, fields, collections)**

- **More record shapes are composable end-to-end — edits that route through a polymorphic field validate and write where they used to be rejected.** Several common fields are polymorphic (they take one of a set of "arms" depending on what's there). Writes to a standalone polymorphic field (an NPC's Level or Sound, a dialogue script fragment, a Condition's data) used to be rejected by pre-flight because it couldn't see fields that exist only on one arm, or it over-rejected a field present on several write-identical arms as a "conflicting shape". Pre-flight now descends into the arms and admits exactly what the engine can write, and you can select a polymorphic sub-arm inside a nested compose (e.g. giving a Condition its data shape), which previously had no way to be expressed.
- **Bad collection-element edits now fail at the gate with a clear message, not a cryptic crash mid-write.** When you Add / Set / ReplaceAll / Merge / Remove an element of a list or dictionary field (a keyword on an NPC, a LinkTo on a dialogue response, a faction entry, a skill weight), houseCARL now checks the element up front — that a required value or dict key/list index is present, that a malformed FormID or unparseable value is caught, and that a key or index has the right shape. Before, these slipped past pre-flight and threw an unnamed exception deep in apply, which houseCARL surfaced as the alarming "pre-flight accepted it but apply threw — a real inconsistency", pointing you at an internal bug when the real problem was a fixable input. The check is by-construction across every collection field, so the gate rejects exactly what apply would have thrown on.
- **Malformed writes fail by name before touching disk.** Clearing a FormLink with a zero value (`00000000` or `0`) now clears the link instead of throwing "malformed FormKey" at write time (and a real FormID is never mistaken for a clear); a composed record left missing a required arm now fails with a named `NullArmSerializeException` saying what's missing instead of a bare null-reference crash; and bracketing a gendered field at its end now points you at the right `.Male`/`.Female` form rather than suggesting list verbs that don't apply. In every case the staged write is all-or-nothing — your originals and the in-progress output are untouched when a write is refused.
- **Expected, fixable write errors now read as fixable input, not internal inconsistencies.** A class of errors pre-flight legitimately cannot catch — an out-of-range list index, adding a dict key that already exists, removing a value/key that isn't there, navigating into an absent collection — used to be wrapped in the same "real inconsistency" alarm as genuine engine bugs. These now render cleanly with actionable guidance while still refusing the whole call and writing no file; genuine gate/apply drift still gets the loud wrapper, and malformed pre-existing source data is now called out as its own category rather than blamed on your input. **Behavior change worth noting:** Remove of an absent value or key is now a surfaced rejection rather than a silent no-op — a script that relied on "remove X if present" being a safe no-op will now have the whole call refused when X is absent.
- **Gendered fields are now editable through the same `[0]`/`[1]` form the reader shows you.** Fields holding a male/female pair (an armor's WorldModel, for example) display in a read as `[0]` and `[1]`, but feeding that exact form back used to be both unreadable and unwritable — only the longer `.Male`/`.Female` path worked. Now `[0]` (male) and `[1]` (female) are a true read-and-write alias, and a write to a not-yet-present arm is materialized and written through correctly rather than silently dropped.
- **Create GlobalVariable, GameSetting, and AI-package Data inputs — previously un-authorable.** GlobalVariable and GameSetting sit under an abstract group, so `create_record` refused them outright; it now creates the concrete shape you ask for (`GlobalFloat`, `GameSettingFloat`, and the rest), with the arms discovered from Mutagen's own type hierarchy and a bare "Global"/"GameSetting" request failing loud with the real choices. Separately, `Package.Data` — the one struct-valued dictionary Mutagen models, holding an AI package's typed inputs (travel/escort target, sandbox/patrol location, literals, object list, dialogue topic) and the last package piece houseCARL could read but not write — is now composable, with a duplicate-key add refused by name ("use Set to overwrite") rather than a raw library error.
- **Polymorphic base types are no longer offered as a legal arm of themselves.** A concrete base type (an AI-package Data entry, a Condition, a VMAD script property) was incorrectly listed as an arm of itself — and composing `Package.Data` by its own name silently wrote a degenerate empty entry, the worst failure class. The gate now rejects composing a base by its own name and filters it out of the legal-arms list, and the bundled `mutagen-reference` schema no longer self-lists those bases (a display fix, no change to which arms are actually composable).
- **Conflict diffs tell an identical-to-winner override apart from a field the plugin simply doesn't carry.** The winner-relative conflict view used to show only differences, so an override that restates a field identically to the winner (an ITM edit) looked the same as a plugin that doesn't touch that field at all — and a not-carried field rendered as a confusing phantom "(absent)" delta. The diff now reports an agreed-with-winner count so an ITM restate is detectable, and renders a not-carried nullable field as "ABSENT here (winner has X)". Per-field presence is reliable for nullable fields; the tool never claims a presence signal it can't prove.

**Robustness & MO2-disk correctness**

- **Every write is now crash-atomic — a power loss or crash mid-save can never leave a torn plugin.** All final-swap writes (the `.esp` patch, the BSA repack, the config save) now commit through one shared primitive that uses the Win32 atomic content-swap when the target exists and an atomic rename for a fresh file. Before, these used `File.Move(overwrite)`, which is not crash-atomic — it can unlink the destination before the rename commits. After, a crash leaves either the complete old file or the complete new file, never a missing or half-written one, and a cross-volume swap refuses loud rather than silently degrading to a non-atomic copy.
- **Re-running a write replaces the patch's own record in place instead of piling up duplicates** *(AlmightyChan — #44/#45)*. Re-running `create_record into=` an existing patch now replaces the patch's own same-EditorID record fresh at the same FormKey. Before, every re-run appended a duplicate, FormIDs crept upward, and external references went stale. The replace is never silent (flagged as same FormID kept, prior contents discarded), an attempt to clobber a carried override from the original plugin refuses loud and points you at `set_field`/`bulk_apply`, and leftover duplicate copies from the old bug refuse loud naming every copy's FormKey.
- **Concurrent tool calls can no longer collide on the same output plugin or cross-commit each other's bytes.** The whole resolve-stage-commit of a write is now serialized behind a write gate, and output-path allocation runs under the same lock. Before, the MCP SDK dispatches tool calls concurrently with no mutual exclusion, so two writes defaulting to the same plugin name could allocate the same folder and cross-commit (one call's success message shipping the other's bytes), and concurrent `into=` extends could silently lose the first call's edits. An instance switch can no longer tear a write in flight.
- **Plugins in MO2's overwrite folder now resolve, and a copy there correctly wins on top of the load order.** Plugins living in MO2's overwrite folder — where tool outputs land (Synthesis patches, xEdit "new file", Wrye Bash) — are now resolved, beating every mod (MO2's own rule) with enabled mods next and the game Data folder as the lowest fallback. Before, these were unresolvable and the warning misdiagnosed them as a stale-profile problem a re-sort can't fix. The lazy-mtime contract is unchanged: a plugin in overwrite changes the winning path once the profile files change, which MO2 writes on refresh.
- **A refused write no longer leaves behind an empty orphan folder.** When a write is refused at pre-flight ("NO patch written"), houseCARL now removes the empty folder and `meta.ini` it had created instead of accreting `_001`/`_002` folders on every retry. The deletion is content-checked — it only removes a folder holding nothing but our own `meta.ini` and an empty staging dir, never a reused `into=` folder — and the same cleanup covers failed rider tools (`bsa_repack` / `compile_script` / `decompile_script`), keeping (and naming) any folder that holds real output.
- **Your saved MO2 instance and tool paths can no longer be silently wiped, and a corrupt config is recovered loudly.** The user config now writes atomically (temp + rename) and guards the whole read-modify-write under a cross-process mutex, so the CLI plugin and desktop app sharing the file can't clobber each other. Before, a non-atomic write plus a corrupt file silently parsing as blank meant the next update wrote blank-plus-one-field back with `ok=true`, wiping your saved instance and tool paths. Now a corrupt file is backed up to `.corrupt.bak` and reported (a RECOVERED line on `set_mo2_instance`/`set_tool_path`, and at boot). Never silently blank.
- **Reads and writes now answer from a single consistent snapshot, and freshness no longer misses backups or restores.** The write path captures one index view up front and answers every edit's resolve/fetch/excluded-check off it (before, it re-resolved per edit, so a freshness rebuild landing mid-loop could resolve two edits of one call against two different builds — a silently mixed patch). Freshness detection was hardened too: it compares profile/ini mtimes by value rather than wall-clock, so MO2's "Restore Backup" (an older mtime) is no longer invisible; SetInstance stamps its baseline before the read; the status line is snapshotted under one lock; and a concurrent read's refresh defers rather than rebuilds under an in-flight write. The promise that an answer reflects current MO2 state holds without a daemon.

**Ergonomics & setup**

- **Load-order status now names the MO2 instance and reads any profile without switching to it.** The status header shows the resolved instance path, the default view lists the other profiles available, and `profile=<name>` inspects an inactive profile's mods and plugins read-only, leaving the active profile untouched. (Instance-mode only; a `profile=` read refuses loudly in explicit-paths mode, an unknown name lists the real profiles, and never-opened stray profile folders are skipped so they can't render as an all-zero phantom.)
- **The Papyrus compiler and BSA tools auto-detect their game directory and the real Steam install.** houseCARL looks for `PapyrusCompiler.exe` under the load order's game directory, and for the common MO2 "Stock Game" layout — where the load order points at a copy with no Creation Kit — it also locates the real Steam install (App 489830) where the CK and vanilla script sources live, with no new dependencies. A genuinely missing dependency now names exactly where it looked, and tool paths are locked so they survive an instance switch. (`housecarl_set_tool_path` becomes a fallback rather than a requirement.)
- **`housecarl_compile_script` takes an `output_dir=` so the compiled `.pex` lands where you choose.** The folder is treated as user-owned, so residue cleanup never deletes it, and deployability reporting is tight — only `<mods>\<modFolder>\Scripts` or `<data>\Scripts` counts as deployable, so a bare or nested path warns instead of falsely reporting a clean "done".
- **The setup installer pre-flights a locked, running server before it overwrites anything — and names the locked exe.** Re-running `houseCARL-Setup.exe` over a live install used to try to overwrite the running `housecarl-mcp.exe`, throw mid-copy, and leave a half-updated tree behind a generic "setup did not complete". Setup now checks for a locked server exe at every destination it would touch (both the Claude and Codex install locations) before any copy runs and refuses with actionable "fully quit Claude/Codex, then re-run" guidance — a clean first install is never blocked. A sharing-violation that slips past the pre-flight is caught with the same guidance, while an unrelated IOException (disk full, etc.) still fails honestly, and the refusal is worded precisely: "nothing was changed" only for a true pre-flight refusal.

**Display & schema honesty**

- **Display-honesty fixes across record schemas, Nexus text, and patch naming.** A read-only-projection leak was closed in the record-schema corpus: Mutagen concrete-class getters with no mutable twin (e.g. `SkyrimMultiModOverlay`, `MergedCellBlock`) were leaking into the catalog as the sole legal arm of their container and are now filtered to authorable arms only (losing no writable coverage — `CellBlock` even becomes a normally-composable struct — and caught by construction going forward via a new corpus guard). A cosmetic sweep fixed several rendering bugs: a dotted patch name like `My.Cool.Patch` was being clipped at the first dot (corrupting the plugin and MO2 folder name) and now strips only a trailing plugin extension; Nexus description truncation no longer splits an emoji/CJK glyph in half; double-encoded HTML entities decode correctly; and several stale tool descriptions/comments were corrected to match actual behavior.
- **The `mutagen-reference` skill now documents field addressing and per-op support.** It spells out the bracket/dot path grammar for reaching a field, a list element, or a dict entry, and which write verbs (Set / Add / Remove / ReplaceAll / SetAtIndex / Merge) each field shape accepts — so a write is composed from the reference rather than guessed.

## 1.2.3 — 2026-06-11

Opens the script-property write surface, adds a write-and-verify loop, and hardens tool-argument handling
and setup — carrying houseCARL's first outside code contributions (thanks, **WraithFallen**). No change to
the tool set.

- **Script-property (VMAD) writes work** *(WraithFallen — #35/#38)*: paths and composes that go through a
  polymorphic field's arms — setting a script property's target object, editing a quest alias's script
  fields, adding a `ScriptObjectProperty` to a script's property list — now validate against the arm's own
  schema and write end-to-end. Before, the write pre-flight couldn't see fields that exist only on one arm
  of a polymorphic type, so those edits were rejected; reads already worked. The surface is generic over
  every polymorphic family — no per-type wiring — and the cases an arm can't support still fail with a
  named reason.
- **Malformed tool arguments coerce or fail by name** *(#36, string-encoded-array case by WraithFallen)*:
  Claude Code's client sometimes sends an array argument as a plain string or as a JSON-array-in-a-string
  (`"[\"A.esp\"]"`); both shapes now bind as the array they spell. A missing required argument refuses by
  name, an uncoercible shape fails with a named reason, and an unexpected error inside any tool now returns
  a named error — never the SDK's generic text.
- **Write-and-verify in one step:** the write tools gain an opt-in `full_readback=` that returns every
  record the write touched or created — in full, read back off the *written file* — so a patch can be
  verified before it's ever enabled in MO2.
- **Honest answer for a plugin that isn't in the load order:** a `plugin=` read naming a plugin that isn't
  in the current order now gets its own named error saying exactly that, instead of the false "does not
  define this record".
- **Consistent answers while the load order changes:** each logical operation now reads from one captured
  index snapshot, so an MO2 change landing mid-query can no longer tear a result (winner, touching list,
  and counters always come from the same view).
- **Setup is self-contained and pre-flights the runtimes:** `houseCARL-Setup.exe` no longer needs .NET
  installed to run, and it checks for *both* required .NET runtimes up front with a specific fix message.
  The install docs are corrected accordingly — installing the ASP.NET Core Runtime does **not** include the
  base .NET runtime.
- **Authoring skills load for reading, not just writing:** the SkyPatcher / SPID / KID skills now also fire
  when *interpreting or auditing* an existing INI — "what does this `_DISTR.ini` do", "is this NPC
  affected", "why isn't this line applying" — so those answers come from the bundled grammar references
  instead of memory.

## 1.2.2 — 2026-06-10

Fixes four issues surfaced auditing a Requiem load order — all in reads and writes, no change to the tool
set.

- **New records get valid FormIDs:** creating a record in a patch that was first written by a bulk apply
  could allocate FormIDs starting at `000000` — the null range the game and other tools reject. houseCARL
  now floors every new-record allocation at `0x800` (the user range Bethesda reserves) from every write
  path, and persists a floored high-water mark into the patch so later edits and removals never regress it.
  Patches that already carry a `000000` record stay readable and editable — nothing is auto-renumbered,
  which would break references.
- **Conflict diffs compare real content:** the conflict tree's "what differs between these overrides"
  comparison looked only at top-level field counts, so two overrides that changed the *contents* of a list
  or struct without changing its length could be reported as identical. The diff now walks the record's
  full depth — list elements compared order-insensitively, sub-structs and nested values compared by value
  — so a genuine deep difference is no longer missed, and the output stays honest when a record is too
  large to fully expand.
- **One unreadable record no longer breaks a whole query:** a single record Mutagen can't parse — for
  example a malformed perk an upstream ESP ships — used to abort an *entire* `housecarl_cross_plugin_query`
  that scans references, returning nothing. houseCARL now isolates the offending record, scans past it, and
  reports how many records were skipped and why, so the rest of the results come through.
- **Form-targeted conditions read correctly:** a condition that points at a form — `HasPerk`,
  `HasMagicEffect`, `GetInFaction`, and the like — used to render a placeholder instead of the form's
  FormID when read. houseCARL now resolves the target through its link, so those condition payloads show
  their real FormID.

## 1.2.1 — 2026-06-08

Adds value-based record querying and a fuller Nexus lookup, and fixes several read and write rough edges.

- **Query by field value:** `housecarl_cross_plugin_query` gains a `where=` filter that matches records
  by a field's *value*, not just by record type or plugin — e.g. `where="MagicSkill = Destruction"` or
  `where="BasicStats.Damage >= 50"`. Operators are `=`, `!=`, `>`, `>=`, `<`, `<=`, and `contains`, and
  multiple `where=` conditions are ANDed. It works on any field you can read (by construction — the
  filterable set is the readable set); a path that can't resolve fails loud rather than silently matching
  nothing.
- **Full Nexus descriptions:** `housecarl_nexus_mod` takes an opt-in `description=true` that returns a
  mod's full Nexus page write-up — cleaned from the page markup to plain text — instead of only the short
  catalogue summary.
- **Write into an active patch:** writing into a patch that is itself active in the load order no longer
  fails with a file-lock error — houseCARL releases every mapped handle on the target before it saves.
- **Deep reads of condition-bearing records:** a deep read (`depth` 5+) of a record that carries
  conditions — a perk, spell, or magic effect — no longer floods the output with .NET reflection
  internals; the descent now stops at the modeled record content, so the real values stay visible.
- **Scoped queries show the scoped record:** under a `plugins=` scope, `housecarl_cross_plugin_query`
  now renders each match from that plugin's own record body rather than the global load-order winner.

## 1.2.0 — 2026-06-07

houseCARL reads Nexus Mods directly, and gains a community-contributed Papyrus performance reviewer.

- **Nexus Mods lookups:** two keyless, read-only tools — `housecarl_nexus_search` (search the Skyrim SE
  catalogue) and `housecarl_nexus_mod` (one mod's version, requirements, and *true* latest release — its
  newest MAIN file, since a mod's own version header can lag) — answer Nexus questions directly through
  the public Nexus catalogue API: no browser, no
  account, no API key. Read-only — houseCARL finds and informs; downloading stays your mod manager's
  "Mod Manager Download" handoff. Offline-tolerant: with no connection it says so plainly and every
  local capability keeps working.
- **`papyrus-optimization` skill:** a bundled Papyrus performance reviewer — classify each part of a
  `.psc` as broken / suboptimal / clean, explain what makes it heavy, and give the fix (event-driven,
  caching, states, native offload). houseCARL's first community-contributed skill, by DrHeisen.

## 1.1.3 — 2026-06-07

Hardens houseCARL against a malformed plugin that could otherwise make every command fail.

- **Resilient load-order indexing:** a single record Mutagen can't parse — for example a malformed package
  data-input count that an upstream ESP ships and the game engine ignores — used to make *every* houseCARL
  command fail with a Mutagen error, because the whole-load-order index is built up front and one bad record
  threw the entire build. houseCARL now isolates the offending plugin: it is excluded from the session and
  reported in `housecarl_load_order_status` (with the reason why), while every other plugin stays fully
  readable. Fix or remove the upstream plugin to restore access to it.

## 1.1.2 — 2026-06-06

Fixes a silent lookup failure in the Papyrus reference skill, and ships the corrected third-party credits.

- **Papyrus reference lookup fix:** the `papyrus-reference` skill documented its function-index grep with a
  format that no longer matched the shipped index, so a lookup written from the docs matched zero lines even
  for functions that are present — silently reporting a real function as "not in the corpus", the exact
  failure the skill exists to prevent. The doc now matches the compact index, uses a full-quoted-token match,
  and adds a self-check that validates the search against a known-present token before trusting an empty result.
- **Corrected attribution:** the bundled third-party notices now credit the distributor-grammar authors by
  name — Zzyxzz (SkyPatcher) and powerofthree (SPID + KID) — and list the KID-authoring skill.

## 1.1.1 — 2026-06-06

houseCARL now points you at your logs — completing the external-tool bridge.

- **Log folders in status:** `housecarl_load_order_status` now surfaces the resolved Papyrus script-log and
  SKSE crash-log folders, so houseCARL knows where to read them when you ask about a Papyrus error or a
  crash. Set a folder explicitly with `housecarl_set_tool_path` (`papyrus_logs` / `crash_logs`); when one is
  unset, houseCARL auto-detects the default location and says so, or tells you exactly how to point it at
  yours. Logs are the one bridge dependency with no wrapping tool — you Read the `.log` files directly.

## 1.1.0 — 2026-06-06

houseCARL now drives the external modding toolchain, not just the data layer.

- **Tool bridge:** `housecarl_set_tool_path` registers — and auto-detects — the external tools houseCARL
  wraps. When a tool a command needs isn't set, houseCARL fails loud with the exact path it wants, rather
  than silently doing nothing.
- **Papyrus compile:** `housecarl_compile_script` compiles a `.psc` through the Creation Kit's
  `PapyrusCompiler.exe`. Compiler warnings are non-fatal, and the recompile is non-destructive — the
  existing `.pex` is overwritten only when the compile succeeds.
- **BSA archives:** `housecarl_bsa_list`, `housecarl_bsa_extract`, and `housecarl_bsa_repack` wrap BSArch
  to inspect, extract from, and repack `.bsa` archives. Repack is non-destructive — the target archive is
  replaced only when the pack succeeds.

## 1.0.1 — 2026-06-05

- **Descendable reads:** `housecarl_read_record` / `housecarl_batch_record_detail` gain a `depth`
  parameter. `depth=1` (default) is unchanged; `depth>=2` enumerates the contents of lists,
  dictionaries, and sub-structs — each element shown with its index and an identity (e.g.
  `VirtualMachineAdapter.Scripts[0].Properties[5] = [ScriptObjectProperty] Name=...`) — so nested
  elements and their indices are visible in one call instead of probing each `[i]` by hand.
- **Bracket-grammar discoverability:** reading a collection with a dot-index (e.g. `Aliases.0`) now
  returns an actionable hint to use brackets (`Aliases[0]`); bracket indexing is documented in the
  read/write tool descriptions.

## 1.0.0 — 2026-06-03

Initial release.

- Local MCP server (stdio) with [Mutagen](https://github.com/Mutagen-Modding/Mutagen) kept warm in
  memory. Claude Code launches it — no port, no window, no manual start.
- **Reads:** the true load-order winner for any record, plus the full conflict tree on request; batch
  record detail; cross-plugin queries.
- **Writes:** set / add / remove fields, leveled-list and container edits, condition-target
  re-targeting — emitted as a **new** MO2 mod folder (`houseCARL - <name>`), originals untouched.
  Create brand-new records; remove records and individual entries; unused masters cleaned automatically.
- **Reflection-driven coverage:** every record type Mutagen models is readable and writable by
  construction — not a hand-maintained subset.
- **MO2 integration:** the instance is chosen via a folder picker at enable time; the active profile and
  load order are read statically from the instance's profile files and refresh automatically on the next
  tool call (MO2 need not be running).
- **Bundled skills:** `mutagen-reference` (record schemas), `papyrus-reference` (Papyrus + SKSE
  signatures), `skypatcher-authoring`, `spid-authoring`, and `kid-authoring`.
