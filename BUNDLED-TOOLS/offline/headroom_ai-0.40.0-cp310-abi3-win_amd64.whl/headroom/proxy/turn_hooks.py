"""Turn hooks — observe and optionally re-drive a single model turn.

A *turn hook* wraps the proxy's buffered upstream call: it sees the outbound
request and the model's response, and may call the model again (via
``call_model``) to return a *replacement* response — transparently to the client.
That covers a range of turn-level behaviors an extension might want: resolving an
injected tool call, enforcing a guardrail, retrying on a bad response, serving a
cached answer, or running a small model→proxy→model loop before handing back the
final answer.

Hooks are registered by opt-in proxy extensions (``proxy/extensions.py``). This
module is **inert unless a hook is registered**: the runner helpers return their
input unchanged, so with no hooks the proxy behaves exactly as if this module did
not exist. Hooks must never raise — a failing hook is logged and skipped so it
cannot take the proxy down.

Stability: the ``TurnHook`` protocol and the registry/runner functions are part
of the extension surface (see ``proxy/extensions.py``); signature changes follow
the same deprecation policy.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

log = logging.getLogger(__name__)

# Re-drive the model with a message list; returns the provider's response JSON.
# The exact message/response shapes are provider-native (Anthropic / OpenAI /
# Google), matching whatever the surrounding handler already works with.
CallModel = Callable[[list[dict[str, Any]]], Awaitable[dict[str, Any]]]


@dataclass
class TurnContext:
    """The request side of one model turn, as the proxy forwards it upstream.

    ``tools`` and ``messages`` are the live objects the handler is about to send
    (or just sent); a hook's ``on_request`` may mutate them in place.
    """

    provider: str  # "anthropic" | "openai" | "google" | ...
    model: str
    messages: list[dict[str, Any]]
    tools: Any = None  # provider-native tools value (list, or None)
    config: Any = None
    # The handler's live request tags and provider-native counters let the hook
    # runner attribute savings with the exact same tokenizer as the canonical
    # RequestOutcome. Optional defaults preserve the public extension API.
    tags: dict[str, Any] = field(default_factory=dict)
    count_messages: Callable[[list[dict[str, Any]]], int] | None = None
    count_tools: Callable[[Any], int] | None = None
    # Outbound headers a request hook wants on the provider request, name ->
    # value. The handler merges them through :func:`merge_provider_headers`:
    # only allow-listed names are honoured, and ``anthropic-beta`` is merged as
    # a token set behind the client's own value rather than overwritten. On the
    # gateway contract the merged map is the response's ``headers`` object.
    provider_headers: dict[str, str] = field(default_factory=dict)

    def record_savings(
        self,
        source: str,
        *,
        tokens: int = 0,
        usd: float = 0.0,
        realized: bool = True,
        estimated: bool = False,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Attribute savings without changing the request's headline totals."""
        from headroom.proxy.savings_attribution import record_savings

        record_savings(
            self.tags,
            source,
            tokens=tokens,
            usd=usd,
            realized=realized,
            estimated=estimated,
            details=details,
        )


@runtime_checkable
class TurnHook(Protocol):
    """A registered turn observer. Both methods are optional (a hook may define
    either); missing methods are simply skipped."""

    name: str

    # Optional: set True if this hook's ``on_request`` needs no later re-drive
    # (a fold-only hook). Such hooks run on streaming turns too; hooks that may
    # re-drive in ``on_response`` leave it unset and run buffered-only. Absent ⇒
    # False (conservative). See :func:`run_request_hooks`.
    stream_safe: bool

    # Optional: run order among registered hooks, lowest first (stable for
    # ties; absent ⇒ DEFAULT_HOOK_PRIORITY). Convention: routers that change
    # ``ctx.model`` 10-49, message folds 50-99, tool-catalog shaping that is
    # gated on the final model (deferral) 200+. Registration order is
    # entry-point discovery order, which an operator does not control, so a
    # hook whose correctness depends on running after another must say so.
    priority: int

    def on_request(self, ctx: TurnContext) -> None:
        """Inspect / mutate ``ctx`` (e.g. ``ctx.tools``) before it goes upstream."""

    async def on_response(
        self, ctx: TurnContext, response: dict[str, Any], call_model: CallModel
    ) -> dict[str, Any] | None:
        """Return a replacement response, or ``None`` to leave it unchanged.

        May ``await call_model(messages)`` to re-drive the model (e.g. to resolve
        an injected tool call), looping as needed before returning the final."""


_hooks: list[TurnHook] = []

DEFAULT_HOOK_PRIORITY = 100

#: Provider header names a hook may request through ``TurnContext.provider_headers``.
PROVIDER_HEADER_ALLOWLIST: frozenset[str] = frozenset({"anthropic-beta"})


def _priority(hook: Any) -> int:
    try:
        return int(getattr(hook, "priority", DEFAULT_HOOK_PRIORITY))
    except (TypeError, ValueError):
        return DEFAULT_HOOK_PRIORITY


def register_turn_hook(hook: TurnHook) -> None:
    """Register a hook. Called by an extension's ``install(app, config)``."""
    _hooks.append(hook)
    log.info(
        "registered turn hook: %s (priority %d)",
        getattr(hook, "name", type(hook).__name__),
        _priority(hook),
    )


def registered_turn_hooks() -> list[TurnHook]:
    """Registered hooks in run order: ``priority`` ascending, registration
    order for ties."""
    return sorted(_hooks, key=_priority)


def merge_provider_headers(
    client_headers: dict[str, str] | None, requested: dict[str, str] | None
) -> dict[str, str]:
    """Reduce hook-requested provider headers to what the handler may set.

    Names outside :data:`PROVIDER_HEADER_ALLOWLIST` are dropped (debug log).
    ``anthropic-beta`` merges as a token set: the client's tokens first, the
    hook's appended, deduplicated — a hook may add a beta the feature needs
    but never strip one the client asked for. Other allow-listed names are set
    verbatim. Returns only the headers to set; an empty map means "nothing".
    """
    out: dict[str, str] = {}
    if not isinstance(requested, dict) or not requested:
        return out
    client = {str(k).strip().lower(): v for k, v in (client_headers or {}).items()}
    for name, value in requested.items():
        key = str(name).strip().lower()
        if key not in PROVIDER_HEADER_ALLOWLIST:
            log.debug("turn hook requested header %r outside the allowlist; dropped", name)
            continue
        if not isinstance(value, str) or not value.strip():
            continue
        if key == "anthropic-beta":
            from headroom.proxy.beta_header_merge import merge_anthropic_beta

            tokens = [t.strip() for t in value.split(",") if t.strip()]
            out[key] = merge_anthropic_beta(client.get(key) or None, tokens)
        else:
            out[key] = value
    return out


def clear_turn_hooks() -> None:
    """Test/reset helper."""
    _hooks.clear()


def run_request_hooks(ctx: TurnContext, *, stream_safe_only: bool = False) -> None:
    """Run each hook's ``on_request``. Inert when none registered; never raises.

    ``on_request`` mutates the outbound request before the upstream send, so it is
    safe on a streamed turn *as long as the hook needs no later re-drive*. A hook
    that may re-drive the model in ``on_response`` (e.g. defer a tool, then reload
    it when the model asks) can't run on a stream — the bytes are already flowing,
    there's nothing to re-drive. So on streaming turns the handler passes
    ``stream_safe_only=True`` and only hooks that opt in via a truthy ``stream_safe``
    attribute run; fold-only hooks (which never re-drive) set it and thus keep
    working on streamed OpenAI-compatible traffic. Default off ⇒ conservative:
    a hook is treated as buffered-only unless it declares itself stream-safe.
    """
    for hook in registered_turn_hooks():
        if stream_safe_only and not getattr(hook, "stream_safe", False):
            continue
        fn = getattr(hook, "on_request", None)
        if fn is None:
            continue
        before_messages = before_tools = None
        try:
            if ctx.count_messages is not None:
                before_messages = ctx.count_messages(ctx.messages)
            if ctx.count_tools is not None:
                before_tools = ctx.count_tools(ctx.tools)
            fn(ctx)
            message_saved = (
                max(0, before_messages - ctx.count_messages(ctx.messages))
                if before_messages is not None and ctx.count_messages is not None
                else 0
            )
            tool_saved = (
                max(0, before_tools - ctx.count_tools(ctx.tools))
                if before_tools is not None and ctx.count_tools is not None
                else 0
            )
            if message_saved or tool_saved:
                ctx.record_savings(
                    getattr(hook, "savings_source", getattr(hook, "name", type(hook).__name__)),
                    tokens=message_saved + tool_saved,
                    details={
                        "message_tokens_saved": message_saved,
                        "tool_tokens_saved": tool_saved,
                    },
                )
        except Exception:  # a hook must never break the proxy
            log.exception("turn hook %r on_request failed", getattr(hook, "name", hook))


async def run_response_hooks(
    ctx: TurnContext, response: dict[str, Any], call_model: CallModel
) -> dict[str, Any]:
    """Run every hook's ``on_response``, chaining any replacements.

    Returns the (possibly replaced) response. Inert when no hooks are registered
    (returns ``response`` unchanged); a failing hook is logged and skipped.
    """
    current = response
    for hook in registered_turn_hooks():
        fn = getattr(hook, "on_response", None)
        if fn is None:
            continue
        try:
            replacement = await fn(ctx, current, call_model)
        except Exception:
            log.exception("turn hook %r on_response failed", getattr(hook, "name", hook))
            continue
        if replacement is not None:
            current = replacement
    return current
